export default async function run(page, ui) {
  const res = {};
  res.errs = [];
  page.on('pageerror', e => res.errs.push(String(e)));
  res.serviceworker = await page.evaluate(async () => {
    const regs = await navigator.serviceWorker.getRegistrations();
    return regs.length;
  });
  // unregister SW then reload
  res.unreg = await page.evaluate(async () => {
    const regs = await navigator.serviceWorker.getRegistrations();
    for (const r of regs) await r.unregister();
    return regs.length;
  });
  await page.reload({ waitUntil: 'load' });
  await page.waitForTimeout(2000);
  res.afterReload = await page.evaluate(() => typeof window.setAuthMode);
  return res;
}
