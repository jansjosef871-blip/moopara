export default async function run(page, ui) {
  return await page.evaluate(() => {
    // Check the ACTUAL first script tag in the served DOM vs what the static file has
    const s = document.querySelectorAll('script')[0];
    const r = { outer: s.outerHTML.slice(0, 150), parent: s.parentElement.tagName, prevSibling: s.previousElementSibling ? s.previousElementSibling.tagName + '.' + (s.previousElementSibling.id || s.previousElementSibling.className) : 'none' };
    // Check the LAST element of body
    const last = document.body.children[document.body.children.length - 1];
    r.lastBodyChild = last.tagName + (last.id ? '#' + last.id : '') + (last.className ? '.' + last.className : '');
    // Check for unclosed template/style swallowing script
    r.scriptsCount = document.querySelectorAll('script').length;
    r.templates = document.querySelectorAll('template').length;
    return r;
  });
}
