export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push('PE: ' + String(e).slice(0, 250)));
  await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 60000 });
  await page.setViewportSize({ width: 1280, height: 720 });
  await page.waitForTimeout(5000);
  const r = {};
  r.domReady = await page.evaluate(() => JSON.stringify({ tabReg: !!document.getElementById('tab-register'), ready: document.readyState }));
  const em = 'v12' + Date.now() + '@mail.com';

  // REGISTER
  await page.evaluate(() => document.getElementById('tab-register').click());
  await page.waitForTimeout(600);
  await page.evaluate(([e]) => {
    const f = document.getElementById('auth-form'); if (f) f.noValidate = true;
    document.getElementById('auth-name').value = 'V12 Test';
    document.getElementById('auth-email').value = e;
    document.getElementById('auth-pass').value = '123456';
  }, [em]);
  await page.evaluate(() => document.getElementById('auth-btn-text').click());
  await page.waitForTimeout(2500);
  r.dashboard = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));

  // NO API BUTTON ON DASHBOARD
  r.dashApiBtn = await page.evaluate(() => !!document.querySelector('#user-dashboard [data-act="menu-api"]'));

  // DRAWER: deposit → personal tab (user-specific IBAN)
  await page.evaluate(() => document.getElementById('menu-open-btn').click());
  await page.waitForTimeout(500);
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-deposit"]').click());
  await page.waitForTimeout(500);
  r.depositOpen = await page.evaluate(() => !document.getElementById('deposit-modal').classList.contains('hidden'));
  // modal fit check: does it overflow viewport?
  r.modalFits = await page.evaluate(() => {
    const b = document.querySelector('#deposit-modal .modal-box');
    const rect = b.getBoundingClientRect();
    return rect.height <= window.innerHeight;
  });
  r.modalScrollable = await page.evaluate(() => {
    const b = document.querySelector('#deposit-modal .modal-box');
    return b.scrollHeight > b.clientHeight; // content scrollable within box
  });
  await page.evaluate(() => document.querySelector('[data-act="dep-tab-personal"]').click());
  await page.waitForTimeout(400);
  r.personalTab = await page.evaluate(() => !document.getElementById('dep-pane-personal').classList.contains('hidden'));
  r.personalIban = await page.evaluate(() => document.getElementById('dep-personal-iban')?.innerText.slice(0, 30));
  r.personalTrc = await page.evaluate(() => (document.getElementById('dep-personal-trc')?.innerText || '').slice(0, 12));
  // CLOSE via ✕ — the reported bug
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]').click());
  await page.waitForTimeout(400);
  r.depositClosed = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));

  // Transfer modal open + close
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-withdraw"]').click());
  await page.waitForTimeout(500);
  r.withdrawOpen = await page.evaluate(() => !document.getElementById('withdraw-modal').classList.contains('hidden'));
  await page.evaluate(() => document.querySelector('[data-act="close-withdraw-modal"]').click());
  await page.waitForTimeout(400);
  r.withdrawClosed = await page.evaluate(() => document.getElementById('withdraw-modal').classList.contains('hidden'));

  // ESC closes any modal
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-bills"]').click());
  await page.waitForTimeout(400);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  r.billClosedByEsc = await page.evaluate(() => document.getElementById('bill-modal').classList.contains('hidden'));

  // CARD: free virtual flow
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-card"]').click());
  await page.waitForTimeout(500);
  r.cardView = await page.evaluate(() => !document.getElementById('card-control-view').classList.contains('hidden'));
  r.freeBanner = await page.evaluate(() => document.getElementById('cc-free-banner')?.style.display);

  // API VIEW title check
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-api"]').click());
  await page.waitForTimeout(500);
  r.apiTitle = await page.evaluate(() => document.querySelector('#api-integration-view h3')?.innerText);
  await page.evaluate(() => document.querySelector('[data-act="drawer-close"]').click());
  await page.waitForTimeout(400);
  await page.screenshot({ path: 'v12-check.png' });
  r.errors = errors;
  return r;
}
