export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/yonetim-atmaca-2026', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1500);
  out.adminLoaded = await page.evaluate(() => ({ hasLogin: !!document.getElementById('loginDiv'), title: document.title }));
  await page.fill('#u', 'atmaca');
  await page.fill('#p', 'admin2026!');
  await page.evaluate(() => giris());
  await page.waitForTimeout(2000);
  await page.evaluate(() => sekme('settings'));
  await page.waitForTimeout(400);
  out.adminTg = await page.evaluate(() => ({
    tokenField: !!document.getElementById('sTgToken'),
    chatField: !!document.getElementById('sTgChat'),
    testBtn: !!document.querySelector('button[onclick="testTelegram()"]'),
    holderField: !!document.getElementById('sHolder'),
    panelHead: (document.getElementById('icerik') || {}).innerText?.slice(0, 80)
  }));
  await page.screenshot({ path: 'admin-settings.png' });
  // PWA button on auth screen
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2500);
  out.pwa = await page.evaluate(() => {
    const btn = document.getElementById('pwa-install-btn');
    return { btnExists: !!btn, btnDisplay: btn ? getComputedStyle(btn).display : 'no-el', rowInDom: !!document.getElementById('pwa-install-row') };
  });
  return out;
}
