export default async function run(page, ui) {
  // Do a full manual navigation bypassing cache completely, on a fresh context
  const res = {};
  await page.route('**/app.js*', route => route.continue({ headers: { ...route.request().headers(), 'Cache-Control': 'no-cache' } }));
  await page.goto('about:blank');
  await page.goto('http://localhost:3000/?nocache=' + Date.now(), { waitUntil: 'networkidle' });
  await page.waitForTimeout(2500);
  res.setAuth = await page.evaluate(() => typeof window.setAuthMode);
  res.scpt = await page.evaluate(() => Array.from(document.scripts).map(s => ({ src: s.src, type: s.type })));
  res.errCount = res.errs && res.errs.length;
  return res;
}
