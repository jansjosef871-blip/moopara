export default async function run(page, ui) {
  const res = { errs: [] };
  page.on('pageerror', e => res.errs.push('PAGEERR: ' + String(e).slice(0, 300)));
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') res.errs.push(m.type() + ': ' + m.text().slice(0, 200)); });
  await page.goto('http://localhost:3000', { waitUntil: 'load' });
  await page.waitForTimeout(3000);
  res.setAuth = await page.evaluate(() => typeof window.setAuthMode);
  return res;
}
