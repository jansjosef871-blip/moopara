const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');
console.log('before len:', t.length);

// Patch 1: coin row green attribute
const old1 = `return '<div class="list-item">`;
const new1 = `return '<div class="list-item"' + (qty > 0 ? ' data-val="1"' : '') + '>`;
if (t.includes(old1)) {
  t = t.replace(old1, new1);
  console.log('green row: PATCHED');
} else {
  const j = t.indexOf('list-item');
  console.log('green row: NOT FOUND. ctx:', t.slice(j - 30, j + 60));
}

fs.writeFileSync(p, t);
console.log('after len:', t.length);
