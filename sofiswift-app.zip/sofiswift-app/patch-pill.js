const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');

// CC status pill update in updateDashboard
const old = `  const ccBrand = document.getElementById('cc-brand-badge'); if (ccBrand && currentUser.hasCard) ccBrand.innerText = currentUser.cardBrand;`;
const nw = old + `
  const ccPill = document.getElementById('cc-status-pill');
  if (ccPill) { ccPill.innerText = currentUser.hasCard ? currentUser.cardBrand + ' Aktif' : 'Kart Yok'; ccPill.className = 'status-pill ' + (currentUser.hasCard ? 'pill-active' : 'pill-locked'); }`;
if (t.includes(old)) { t = t.replace(old, nw); console.log('cc pill: PATCHED'); } else console.log('cc pill: NOT FOUND (append to badge block)');
fs.writeFileSync(p, t);
