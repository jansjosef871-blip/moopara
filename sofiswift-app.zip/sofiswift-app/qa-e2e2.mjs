export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(2000);
  await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=' + Math.random(), { cache: 'no-store' })).text();
    (0, eval)(t);
  });
  await page.evaluate(() => {
    setAuthMode(true);
    document.getElementById('auth-name').value = 'Canli Test';
    document.getElementById('auth-email').value = 'qa' + Date.now() + '@test.com';
    document.getElementById('auth-phone').value = '05551112233';
    document.getElementById('auth-pass').value = '1234';
    return sendOtpCode();
  });
  await page.waitForTimeout(4000);
  out.otpMsg = await page.evaluate(() => document.getElementById('auth-error').innerText);
  out.smsReallySent = out.otpMsg.includes('telefonunuza gönderildi');
  return out;
}
