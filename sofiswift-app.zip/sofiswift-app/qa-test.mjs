export default async function run(page, ui) {
  const report = {};
  report.manualExec = await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=m' + Math.random(), { cache: 'no-store' })).text();
    // capture whether top-level let survives: use eval in global scope
    try {
      (0, eval)(t);
      return {
        setAuthMode: typeof window.setAuthMode,
        directSetAuthMode: (typeof setAuthMode),
        kycOpts: document.querySelectorAll('#kyc-country option').length
      };
    } catch (e) { return 'ERR: ' + e.message.slice(0, 300); }
  });
  return report;
}
