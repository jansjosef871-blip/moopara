const fs = require('fs');
const p = 'public/app.js';
let t = fs.readFileSync(p, 'utf8');
const broken = 'return \'<div class="list-item"\' + (qty > 0 ? \' data-val="1"\' : \'\') + \'><div style=';
const fixed = 'return \'<div class="list-item"\' + (qty > 0 ? \' data-val="1"\' : \'\') + \'><div style=';
// The broken part: after the concat there is `<div style=` NOT inside quotes. Fix by quoting it:
const bad = '+ \'><div style=';
const good = '+ \'><div style=';
// find actual broken sequence: `+ '><div style=` where `><div style=` lost its quotes
const badSeq = '\'\') + \'><div style="display:flex;';  // expected good form
const brokenSeq = '\'\' + >\'<div style';  // unlikely
// Simply locate: `+ '>` followed directly by `<div style=` without opening quote
const re = /\+ '>'(?=<div style=)/;
if (re.test(t)) {
  t = t.replace(re, "+ '" > ' );
  console.log('already fine? no — replace needed');
}
// The real fix: find `+ '><div style="display:flex;` — that's correct form. The broken one is:
// `+ '>` + `<div style=` concatenated — search for `+ '>'<div style=`
const broken2 = "+ '>'<div style=";
if (t.includes(broken2)) {
  t = t.replace(broken2, "+ '><div style=");
  fs.writeFileSync(p, t);
  console.log('FIXED');
} else { console.log('broken2 not found'); }
