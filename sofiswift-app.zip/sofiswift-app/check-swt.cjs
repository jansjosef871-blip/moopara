const d = require('fs').readFileSync('public/app.js', 'utf8');
const i = d.indexOf('function switchDepositTab');
console.log(i === -1 ? 'NO switchDepositTab' : JSON.stringify(d.slice(i, i + 1500)));
