export default async function run(page, ui) {
  return await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=bisect', { cache: 'no-store' })).text();
    const lines = t.split('\n');
    // binary search on prefix that keeps parsing OK
    const parseOK = n => { try { new Function(lines.slice(0, n).join('\n')); return true; } catch (e) { return false; } };
    // find first n where a fresh script tag with prefix would still throw nothing...
    // instead: execute the whole file inside a try? No — top-level. Use a Function with only syntax check passed.
    // Real repro: script tag with the same text as a data URL
    const dataUrl = 'data:text/javascript;base64,' + btoa(unescape(encodeURIComponent(t)));
    const res = await new Promise(resolve => {
      const s = document.createElement('script');
      s.src = dataUrl;
      s.onload = () => resolve('loaded, setAuth=' + typeof window.setAuthMode);
      s.onerror = () => resolve('onerror');
      document.body.appendChild(s);
      setTimeout(() => resolve('timeout, setAuth=' + typeof window.setAuthMode), 3000);
    });
    return { res, lines: lines.length };
  });
}
