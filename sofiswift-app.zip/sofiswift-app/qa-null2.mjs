export default async function run(page, ui) {
  // Setup error trap FIRST, before any script runs
  await page.addInitScript(() => {
    window.__errs = [];
    window.addEventListener('error', e => window.__errs.push('ERR: ' + String(e.message) + ' @line ' + e.lineno + ':' + e.colno));
    window.addEventListener('unhandledrejection', e => window.__errs.push('REJ: ' + String(e.reason).slice(0, 200)));
    const orig = document.createElement.bind(document);
    document.createElement = function (tag) {
      const el = orig(tag);
      if (String(tag).toLowerCase() === 'script') {
        el.addEventListener('error', () => window.__errs.push('SCRIPT LOAD ERR: ' + el.src));
      }
      return el;
    };
  });
  await page.goto('http://localhost:3000', { waitUntil: 'load' });
  await page.waitForTimeout(2000);
  return await page.evaluate(() => ({ errs: JSON.parse(JSON.stringify(window.__errs || [])), setAuth: typeof window.setAuthMode }));
}
