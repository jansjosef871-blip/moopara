export default async function run(page, ui) {
  const out = {};
  // Auth screen: logo + PWA button
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2500);
  out.auth = await page.evaluate(() => ({
    logoImg: !!document.querySelector('.brand-logo[src="/logo.svg"]'),
    pwaBtn: !!document.getElementById('pwa-install-btn'),
    pwaVisible: (() => { const b = document.getElementById('pwa-install-btn'); return b ? getComputedStyle(b).display !== 'none' : false; })()
  }));
  await page.screenshot({ path: 'auth-logo.png' });
  // Admin secret path: Telegram fields
  await page.goto('http://localhost:3000/yonetim-atmaca-2026?v=' + Date.now(), { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2500);
  out.adminLoginVisible = await page.evaluate(() => !!document.getElementById('adm-user'));
  if (out.adminLoginVisible) {
    await page.evaluate(() => {
      document.getElementById('adm-user').value = 'atmaca';
      document.getElementById('adm-pass').value = 'admin2026!';
      return adminLogin();
    });
    await page.waitForTimeout(2500);
    out.adminTg = await page.evaluate(() => ({
      tokenField: !!document.getElementById('set-tg-token'),
      chatField: !!document.getElementById('set-tg-chat'),
      testBtn: !!document.querySelector('button[onclick="testTelegram()"]'),
      tokenVal: (document.getElementById('set-tg-token') || {}).value?.slice(0, 12)
    }));
    await page.screenshot({ path: 'admin-tg.png' });
  }
  return out;
}
