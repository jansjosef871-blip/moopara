# Görevler
1. Deposit modal ✕ kapatma butonu düzelt (close-deposit-modal data-act delegation'da çalışmıyor mu kontrol)
2. Kişisel IBAN'ı deposit modal'ına geri ekle
3. Papara benzeri kurumsal API entegrasyon bölümü ekle
4. Kart kontrol ile ana sayfa tasarımını uyumlu hale getir
