export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(2000);
  await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=' + Math.random(), { cache: 'no-store' })).text();
    (0, eval)(t);
  });
  // 1. OTP endpoint behaviour (no smsEdgeKey -> demoCode fallback)
  out.otp = await page.evaluate(async () => {
    const r = await fetch('/api/send-otp', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'qa' + Date.now() + '@t.com', phone: '05551112233' }) });
    return await r.json();
  });
  // 2. Full register flow with demo OTP from step 1
  const email = 'qa' + Date.now() + '@test.com';
  const otpResp = await page.evaluate(async (em) => {
    const r = await fetch('/api/send-otp', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: em, phone: '05551112233' }) });
    return await r.json();
  }, email);
  out.otpResp = otpResp;
  out.reg = await page.evaluate(async ({ em, code }) => {
    const r = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'QA User', email: em, password: '1234', phone: '05551112233', otpCode: code, isRegister: true }) });
    const d = await r.json();
    if (!r.ok) return { err: d.error };
    currentUser = d.user; appSettings = d.settings || appSettings;
    enterApp();
    return { ok: true, uid: currentUser.id, iban: currentUser.personalIban };
  }, { em: email, code: otpResp.demoCode });
  // 3. Deposit modal: personal IBAN + QR
  out.dep = await page.evaluate(() => {
    openModal('deposit-modal');
    document.querySelector('[data-act="dep-tab-personal"]').click();
    return {
      iban: document.getElementById('dep-personal-iban').innerText,
      holder: document.getElementById('dep-personal-holder').innerText,
      bank: document.getElementById('dep-personal-bank').innerText,
      hasQr: !!document.querySelector('#dep-personal-qr img')
    };
  });
  await page.waitForTimeout(1000);
  await page.screenshot({ path: 'final-live.png' });
  return out;
}
