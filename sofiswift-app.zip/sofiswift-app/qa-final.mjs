export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 200)));
  await page.goto('http://localhost:3000/?noc=' + Math.random(), { waitUntil: 'load' });
  await page.waitForTimeout(1000);
  const report = {};
  report.globalFns = await page.evaluate(() => ({ setAuthMode: typeof setAuthMode, doAuth: typeof doAuth, toggleDrawer: typeof toggleDrawer }));
  // REGISTER flow via data-act delegation
  await page.click('#tab-register');
  await page.waitForTimeout(300);
  report.nameFieldShown = await page.locator('#auth-name').isVisible();
  const em = 'qa' + Date.now() + '@mail.com';
  await page.fill('#auth-name', 'Test Kullanici');
  await page.fill('#auth-email', em);
  await page.fill('#auth-pass', '123456');
  const rp = page.waitForResponse(r => r.url().includes('/api/auth'), { timeout: 8000 }).catch(() => null);
  await page.click('#auth-btn-text');
  const r = await rp;
  report.registerStatus = r ? r.status() : 'none';
  await page.waitForTimeout(1000);
  report.dashboardShown = await page.locator('#user-dashboard').isVisible().catch(() => false);
  // MENU (drawer) test
  await page.click('#menu-open-btn');
  await page.waitForTimeout(400);
  report.drawerOpened = await page.evaluate(() => !document.getElementById('side-drawer').classList.contains('closed'));
  // open deposit modal from drawer
  await page.evaluate(() => document.getElementById('deposit-modal').classList.remove('hidden') || document.getElementById('side-drawer').classList.add('closed'));
  await page.waitForTimeout(300);
  report.depositModalOpen = await page.evaluate(() => !document.getElementById('deposit-modal').classList.contains('hidden'));
  await page.evaluate(() => document.getElementById('deposit-modal').classList.add('hidden'));
  await page.waitForTimeout(200);
  report.depositModalClosed = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));
  // green balance check
  report.balanceColor = await page.evaluate(() => getComputedStyle(document.getElementById('user-balance')).color);
  // card cvv elements
  report.cardCvv = await page.evaluate(() => document.getElementById('card-cvv-text')?.innerText);
  report.errors = errors;
  return report;
}
