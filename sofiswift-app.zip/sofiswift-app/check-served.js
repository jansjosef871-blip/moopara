const http = require('http');
http.get('http://localhost:3000/?noc=' + Date.now(), res => {
  let t = '';
  res.on('data', d => t += d);
  res.on('end', () => {
    console.log('served index len:', t.length);
    console.log('has user-dashboard:', t.includes('user-dashboard'));
    console.log('has api-integration-view:', t.includes('api-integration-view'));
    console.log('has dep-tab-personal:', t.includes('dep-tab-personal'));
    console.log('has cc-status-pill:', t.includes('cc-status-pill'));
    console.log('has actions.js:', t.includes('actions.js'));
    console.log('app.js ver:', (t.match(/app\.js\?v=([\d]+)/) || [])[1]);
  });
});
