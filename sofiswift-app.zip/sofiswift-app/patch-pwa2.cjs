const fs = require('fs');
let d = fs.readFileSync('public/app.js', 'utf8');

// 1) PWA helpers before enterApp
const anchor = 'function enterApp() {';
if (!d.includes(anchor)) { console.log('E1 FAIL'); process.exit(1); }
if (!d.includes('pwaPromptEvent')) {
  const pwaHelpers = `let pwaPromptEvent = null;
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); pwaPromptEvent = e; const b = document.getElementById('pwa-install-btn'); if (b) b.style.display = 'inline-block'; });
function installPwa() {
  if (pwaPromptEvent) { pwaPromptEvent.prompt(); pwaPromptEvent.userChoice.then(() => { pwaPromptEvent = null; const r = document.getElementById('pwa-install-row'); if (r) r.classList.add('hidden'); }); }
  else { alert('Uygulamayı yüklemek için tarayıcı menüsünden "Ana ekrana ekle / Uygulamayı yükle" seçeneğini kullanın.'); }
}
` + anchor;
  d = d.replace(anchor, pwaHelpers);
}

// 2) enterApp hides install row
const oldEnter = `function enterApp() {
  document.getElementById('auth-section').classList.add('hidden');`;
const newEnter = `function enterApp() {
  const pir = document.getElementById('pwa-install-row'); if (pir) pir.classList.add('hidden');
  document.getElementById('auth-section').classList.add('hidden');`;
if (d.includes(oldEnter)) d = d.replace(oldEnter, newEnter);

// 3) DOMContentLoaded: standalone check
const initAnchor = `document.addEventListener('DOMContentLoaded', () => {`;
if (d.includes(initAnchor) && !d.includes('isStandalonePwa()) { const r = document.getElementById')) {
  d = d.replace(initAnchor, initAnchor + `
  if (isStandalonePwa()) { const r = document.getElementById('pwa-install-row'); if (r) r.classList.add('hidden'); }`);
}

fs.writeFileSync('public/app.js', d);
console.log('app.js PWA OK');
