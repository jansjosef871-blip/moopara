const d = require('fs').readFileSync('public/app.js', 'utf8');
const i = d.indexOf("'dep-tab-personal': () =>");
console.log(JSON.stringify(d.slice(i + 260, i + 700)));
