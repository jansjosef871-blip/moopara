export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(2200);
  await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=' + Math.random(), { cache: 'no-store' })).text();
    (0, eval)(t);
  });
  // mevcut bir kullanıcıyla login (şifre 1234 olan son QA kullanıcısı)
  const users = await page.evaluate(async () => {
    // doğrudan DB'ye erişemiyoruz; son QA e-postalarını deneyemeyiz. Bunun yerine test kullanıcısı yaratmayı dene:
    return null;
  });
  // Real OTP went out; can't register headless. So verify UI logic with a stubbed currentUser:
  out.stub = await page.evaluate(() => {
    currentUser = { id: 2649012573, name: 'IBAN QA', personalIban: 'TR64 0001 0019 5900 2635 57', kycStatus: 'VERIFIED', hasCard: true, assets: { USDT: 10 }, transactions: [] };
    appSettings.officialBankIban = 'TR64 0001 0019 4952 1717 25';
    appSettings.officialBankName = 'ziraat bank';
    openModal('deposit-modal');
    document.querySelector('[data-act="dep-tab-personal"]').click();
    return {
      ibanShown: document.getElementById('dep-personal-iban').innerText,
      holder: document.getElementById('dep-personal-holder').innerText,
      bank: document.getElementById('dep-personal-bank').innerText,
      hasQr: !!document.querySelector('#dep-personal-qr img'),
      qrIsPoolIban: (document.querySelector('#dep-personal-qr img') || {}).src?.includes(encodeURIComponent('TR64 0001 0019 4952 1717 25')) || (document.querySelector('#dep-personal-qr img') || {}).src?.includes(encodeURIComponent('TR64 0001 0019 5900 2635 57'))
    };
  });
  await page.waitForTimeout(800);
  await page.screenshot({ path: 'iban-final.png' });
  return out;
}
