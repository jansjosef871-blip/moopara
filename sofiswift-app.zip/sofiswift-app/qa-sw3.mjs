export default async function run(page, ui) {
  const res = {};
  res.res = await page.evaluate(async () => {
    try {
      const s = document.createElement('script');
      s.src = '/app.js?v=zzz999';
      document.body.appendChild(s);
      await new Promise(r => setTimeout(r, 2000));
      // force error capture
      const errs = [];
      window.addEventListener('error', e => errs.push(e.message + ' @ ' + e.filename + ':' + e.lineno), { once: true });
      const s2 = document.createElement('script');
      s2.textContent = 'var x = ;';
      document.body.appendChild(s2);
      return { setAuth: typeof window.setAuthMode, errs, hasScript: !!document.querySelector('script[src*="zzz999"]'), sw: (await navigator.serviceWorker.getRegistrations()).length };
    } catch (e) { return 'ERR ' + e.message; }
  });
  return res;
}
