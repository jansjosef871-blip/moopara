export default async function run(page, ui) {
  const res = {};
  res.err = await page.evaluate(async () => {
    try {
      // fetch + inline insert with ALL forms
      const s1 = document.createElement('script');
      s1.src = '/app.js?v=form1';
      s1.onload = () => { res1 = typeof window.setAuthMode; };
      let res1 = 'pending';
      document.body.appendChild(s1);
      await new Promise(r => setTimeout(r, 2000));
      const s2 = document.createElement('script');
      s2.src = '/app.js?v=form2';
      s2.setAttribute('type', 'text/javascript');
      let res2 = 'pending';
      s2.onload = () => { res2 = typeof window.setAuthMode2 || typeof window.doAuth; };
      document.body.appendChild(s2);
      await new Promise(r => setTimeout(r, 2000));
      return { res1, res2 };
    } catch (e) { return 'ERR ' + e.message; }
  });
  return res;
}
