export default async function run(page, ui) {
  const res = {};
  await page.evaluate(async () => {
    const regs = await navigator.serviceWorker.getRegistrations();
    for (const r of regs) await r.unregister();
    if (window.caches) { const keys = await caches.keys(); for (const k of keys) await caches.delete(k); }
  });
  await page.goto('about:blank');
  await page.goto('http://localhost:3000', { waitUntil: 'load' });
  await page.waitForTimeout(1500);
  res.after = await page.evaluate(() => ({ sw: null, setAuth: typeof window.setAuthMode, scripts: Array.from(document.scripts).map(s=>s.src) }));
  res.sw = await page.evaluate(async () => (await navigator.serviceWorker.getRegistrations()).length);
  return res;
}
