export default async function run(page, ui) {
  const out = { steps: [] };
  // login
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  const authed = await page.evaluate(() => !document.getElementById('login-screen')?.classList.contains('hidden') === false);
  // try login via form
  const hasLogin = await page.evaluate(() => !!document.querySelector('#login-username'));
  if (hasLogin) {
    await page.fill('#login-username', 'demo');
    await page.fill('#login-password', 'demo1234');
    await page.click('button[type="submit"]');
    await page.waitForTimeout(1200);
  }
  out.loggedIn = await page.evaluate(() => typeof window.currentUser !== 'undefined' ? !!window.currentUser : 'unknown');
  // open deposit modal
  await page.evaluate(() => {
    const btn = [...document.querySelectorAll('[data-act]')].find(b => (b.dataset.act || '').includes('deposit') || /Para Yatır|Deposit/i.test(b.textContent));
    if (btn) btn.click();
  });
  await page.waitForTimeout(500);
  out.modalVisible = await page.evaluate(() => !document.getElementById('deposit-modal')?.classList.contains('hidden'));
  // tabs
  for (const t of ['dep-tab-personal', 'dep-tab-bank', 'dep-tab-crypto']) {
    await page.evaluate(id => { const el = document.getElementById(id); if (el) el.click(); }, t);
    await page.waitForTimeout(250);
    out.steps.push({ tab: t, personalPane: await page.evaluate(() => { const p = document.getElementById('dep-pane-personal'); return p ? getComputedStyle(p).display : 'missing'; }) });
  }
  // personal tab content
  await page.evaluate(() => document.getElementById('dep-tab-personal')?.click());
  await page.waitForTimeout(300);
  out.personal = await page.evaluate(() => ({
    iban: document.getElementById('dep-personal-iban')?.innerText,
    holder: document.getElementById('dep-personal-holder')?.innerText,
    trc: document.getElementById('dep-personal-trc')?.innerText?.slice(0, 12)
  }));
  // close button works?
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]')?.click());
  await page.waitForTimeout(300);
  out.closedAfterX = await page.evaluate(() => document.getElementById('deposit-modal')?.classList.contains('hidden'));
  await page.screenshot({ path: 'finish-deposit.png', fullPage: false });
  return JSON.stringify(out, null, 2);
}
