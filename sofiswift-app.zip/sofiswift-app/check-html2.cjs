require('http').get('http://127.0.0.1:3000/', r => {
  let d = ''; r.on('data', c => d += c);
  r.on('end', () => {
    const idx = d.indexOf('app.js');
    console.log('head len', d.length, 'hasAppJs', idx);
    const i2 = d.indexOf('<script');
    console.log(JSON.stringify(d.slice(d.length - 900)));
  });
});
