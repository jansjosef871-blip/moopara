const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');

// closeModal daha sağlam: hem hidden class hem display reset
const old = `function closeModal(id) { const el = document.getElementById(id); if (el) el.classList.add('hidden'); }`;
const nw = `function closeModal(id) { var el = document.getElementById(id); if (el) { el.classList.add('hidden'); el.style.display = ''; } }
function closeAllModals() { document.querySelectorAll('.modal-overlay').forEach(function(m) { m.classList.add('hidden'); }); }
function openModalSafe(id) { closeAllModals(); var el = document.getElementById(id); if (el) { el.classList.remove('hidden'); } }`;
if (t.includes(old)) { t = t.replace(old, nw); console.log('closeModal upgraded'); }
else console.log('closeModal not found');

// openModal'ı safe versiyona çevir (tek modal açık kalsın)
const oldOpen = `  const el = document.getElementById(id); if (el) el.classList.remove('hidden');
}`;
const newOpen = `  closeAllModals();
  var el = document.getElementById(id); if (el) { el.classList.remove('hidden'); }
}`;
if (t.includes(oldOpen)) { t = t.replace(oldOpen, newOpen); console.log('openModal safe'); }
else console.log('openModal pattern not found');

fs.writeFileSync(p, t);
