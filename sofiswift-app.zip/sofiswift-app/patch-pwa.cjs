const fs = require('fs');
let d = fs.readFileSync('public/app.js', 'utf8');

// 1) PWA install helpers before enterApp
const anchor = 'function enterApp() {';
const pwaHelpers = `let pwaPromptEvent = null;
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); pwaPromptEvent = e; const b = document.getElementById('pwa-install-btn'); if (b) b.style.display = 'inline-block'; });
function installPwa() {
  if (pwaPromptEvent) { pwaPromptEvent.prompt(); pwaPromptEvent.userChoice.then(() => { pwaPromptEvent = null; const r = document.getElementById('pwa-install-row'); if (r) r.classList.add('hidden'); }); }
  else { alert('Uygulamayı yüklemek için tarayıcı menüsünden "Ana ekrana ekle / Uygulamayı yükle" seçeneğini kullanın.'); }
}
` + anchor;
if (!d.includes(anchor)) { console.log('ANCHOR FAIL'); process.exit(1); }
d = d.replace(anchor, pwaHelpers);

// 2) enterApp hides install row (user logged in)
const oldEnter = `function enterApp() {
  document.getElementById('auth-section').classList.add('hidden');`;
const newEnter = `function enterApp() {
  const pir = document.getElementById('pwa-install-row'); if (pir) pir.classList.add('hidden');
  document.getElementById('auth-section').classList.add('hidden');`;
if (!d.includes(oldEnter)) { console.log('ENTER FAIL'); process.exit(1); }
d = d.replace(oldEnter, newEnter);

// 3) isStandalone hide: if app installed, hide install button at load
const initAnchor = "document.addEventListener('DOMContentLoaded', () => {";
const initAdd = `document.addEventListener('DOMContentLoaded', () => {
  if (isStandalonePwa()) { const r = document.getElementById('pwa-install-row'); if (r) r.classList.add('hidden'); }`;
if (!d.includes(initAnchor)) { console.log('INIT FAIL'); process.exit(1); }
d = d.replace(initAnchor, initAdd);

fs.writeFileSync('public/app.js', d);
console.log('PWA patches OK');
