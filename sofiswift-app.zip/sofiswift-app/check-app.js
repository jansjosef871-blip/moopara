const http = require('http');
http.get('http://localhost:3000/app.js?v=' + Date.now(), res => {
  let t = '';
  res.on('data', d => t += d);
  res.on('end', () => {
    console.log('app.js len:', t.length);
    console.log('has function setAuthMode:', t.includes('function setAuthMode'));
    console.log('has function doAuth:', t.includes('async function doAuth'));
    console.log('first 60:', JSON.stringify(t.slice(0, 60)));
  });
});
