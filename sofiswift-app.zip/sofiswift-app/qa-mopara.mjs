export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push('PE: ' + String(e).slice(0, 250)));
  await page.goto('http://localhost:3000/?cb=' + Date.now(), { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(4500);
  const r = {};
  const em = 'mop' + Date.now() + '@mail.com';
  r.fns = await page.evaluate(() => JSON.stringify({ enterApp: typeof enterApp, doAuth: typeof doAuth, setAuthMode: typeof setAuthMode }));
  // REGISTER
  await page.evaluate(() => document.getElementById('tab-register').click());
  await page.waitForTimeout(600);
  await page.evaluate(([e]) => {
    const f = document.getElementById('auth-form'); if (f) f.noValidate = true;
    document.getElementById('auth-name').value = 'MoPara User';
    document.getElementById('auth-email').value = e;
    document.getElementById('auth-pass').value = '123456';
  }, [em]);
  await page.evaluate(() => document.getElementById('auth-btn-text').click());
  await page.waitForTimeout(2500);
  r.dashboard = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));
  // Personal IBAN check
  await page.evaluate(() => document.getElementById('menu-open-btn').click());
  await page.waitForTimeout(500);
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-deposit"]').click());
  await page.waitForTimeout(600);
  await page.evaluate(() => document.querySelector('[data-act="dep-tab-personal"]').click());
  await page.waitForTimeout(400);
  r.personalIban = await page.evaluate(() => document.getElementById('dep-personal-iban').innerText.slice(0, 30));
  r.isPersonal = await page.evaluate(() => document.getElementById('dep-personal-iban').innerText.startsWith('US64'));
  r.personalTrc = await page.evaluate(() => (document.getElementById('dep-personal-trc').innerText || '').slice(0, 8));
  // Close X
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]').click());
  await page.waitForTimeout(500);
  r.depositClosed = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));
  // Free card
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-card"]').click());
  await page.waitForTimeout(500);
  r.freeBanner = await page.evaluate(() => document.getElementById('cc-free-banner')?.style.display);
  await page.evaluate(() => document.querySelector('#cc-payment-details [data-act="submit-card-order"]').click());
  await page.waitForTimeout(2500);
  r.freeCard = await page.evaluate(() => currentUser && currentUser.hasCard);
  r.brand = await page.evaluate(() => currentUser && currentUser.cardBrand);
  // API
  await page.evaluate(() => document.querySelector('#card-control-view [data-act="show-dashboard"]').click());
  await page.waitForTimeout(400);
  await page.evaluate(() => document.getElementById('menu-open-btn').click());
  await page.waitForTimeout(500);
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-api"]').click());
  await page.waitForTimeout(500);
  r.apiTitle = await page.evaluate(() => document.querySelector('#api-integration-view h3').innerText);
  r.errors = errors;
  return r;
}
