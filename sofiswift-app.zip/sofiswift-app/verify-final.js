const fs = require('fs');
const t = fs.readFileSync('C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js', 'utf8');
console.log('final check — len:', t.length);
console.log('setAuthMode:', t.includes('function setAuthMode'));
console.log('doAuth:', t.includes('async function doAuth'));
console.log('toggleDrawer fixed:', t.includes("d.classList.toggle('closed'"));
console.log('green coin rows:', t.includes('data-val'));
console.log('balance green logic:', t.includes("#10B981' : '#64748B"));
console.log('cvv display:', t.includes('card-cvv-text'));
