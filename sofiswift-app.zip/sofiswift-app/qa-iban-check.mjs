export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(2200);
  await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=' + Math.random(), { cache: 'no-store' })).text();
    (0, eval)(t);
  });
  // settings'teki havuz IBAN'ı ne?
  out.poolIban = await page.evaluate(async () => {
    const s = await (await fetch('/api/public-settings')).json();
    return { officialBankIban: s.officialBankIban, officialBankName: s.officialBankName, officialBankHolder: s.officialBankHolder };
  });
  // register sonra deposit kontrol
  const email = 'qa' + Date.now() + '@test.com';
  out.reg = await page.evaluate(async (em) => {
    const r = await fetch('/api/send-otp', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: em, phone: '05551112233' }) });
    const otp = await r.json();
    if (!otp.demoCode) return { note: 'gerçek SMS gitti, kayıt atlanır' };
    const r2 = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'IBAN QA', email: em, password: '1234', phone: '05551112233', otpCode: otp.demoCode, isRegister: true }) });
    const d2 = await r2.json();
    if (!r2.ok) return { err: d2.error };
    currentUser = d2.user; appSettings = d2.settings || appSettings;
    enterApp();
    return { ok: true, userIban: currentUser.personalIban };
  }, email);
  if (out.reg.ok) {
    out.dep = await page.evaluate(() => {
      openModal('deposit-modal');
      document.querySelector('[data-act="dep-tab-personal"]').click();
      return {
        ibanShown: document.getElementById('dep-personal-iban').innerText,
        bank: document.getElementById('dep-personal-bank').innerText,
        holder: document.getElementById('dep-personal-holder').innerText,
        hasQr: !!document.querySelector('#dep-personal-qr img')
      };
    });
  }
  return out;
}
