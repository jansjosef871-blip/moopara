export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push('PE: ' + String(e).slice(0, 300)));
  await page.goto('http://localhost:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForTimeout(3000);
  const r = {};
  r.domState = await page.evaluate(() => JSON.stringify({
    readyState: document.readyState,
    tabReg: !!document.getElementById('tab-register'),
    authSec: !!document.getElementById('auth-section'),
    totalElems: document.querySelectorAll('*').length,
    bodyLen: document.body.innerHTML.length
  }));
  r.errors = errors;
  return r;
}
