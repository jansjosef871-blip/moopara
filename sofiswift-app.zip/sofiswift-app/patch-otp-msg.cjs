const fs = require('fs');
let d = fs.readFileSync('public/app.js', 'utf8');
const oldStr = "    showAuthError('📝 ' + (d.demoCode || 'SMS'));\n    let left = 60;";
const newStr = "    if (d.sent) showAuthError('✅ SMS doğrulama kodu telefonunuza gönderildi.');\n    else showAuthError('⚠️ SMS servisi yapılandırılmamış (test kodu: ' + (d.demoCode || '—') + ') — canlıya almak için yönetici paneline SmsEdge API anahtarını girin.');\n    let left = 60;";
if (!d.includes(oldStr)) { console.log('NOT FOUND'); process.exit(1); }
d = d.replace(oldStr, newStr);
fs.writeFileSync('public/app.js', d);
console.log('patched');
