const d = require('fs').readFileSync('public/app.js', 'utf8');
const lines = d.split('\n');
// openModal starts line 100; show lines 100-115
console.log(lines.slice(99, 116).map((l, i) => (i + 100) + ': ' + l).join('\n'));
console.log('--- has my pq line? ---');
console.log('dep-personal-qr mentions:', (d.match(/dep-personal-qr/g) || []).length);
console.log('fillPersonalDeposit calls:', (d.match(/fillPersonalDeposit/g) || []).length);
