const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');

// 3-tab switchDepositTab
const oldFn = `function switchDepositTab(tab) {
  const isCrypto = (tab === 'crypto');
  document.getElementById('dep-pane-crypto').classList.toggle('hidden', !isCrypto);
  document.getElementById('dep-pane-bank').classList.toggle('hidden', isCrypto);
  const bC = document.getElementById('dep-tab-crypto'), bB = document.getElementById('dep-tab-bank');
  bC.style.background = isCrypto ? '#0F172A' : 'transparent'; bC.style.color = isCrypto ? '#FFFFFF' : '#475569';
  bB.style.background = !isCrypto ? '#0F172A' : 'transparent'; bB.style.color = !isCrypto ? '#FFFFFF' : '#475569';
}`;
const newFn = `function switchDepositTab(tab) {
  var panes = { crypto: 'dep-pane-crypto', bank: 'dep-pane-bank', personal: 'dep-pane-personal' };
  var tabs = { crypto: 'dep-tab-crypto', bank: 'dep-tab-bank', personal: 'dep-tab-personal' };
  Object.keys(panes).forEach(function(k) {
    var pane = document.getElementById(panes[k]);
    if (pane) { pane.classList.toggle('hidden', k !== tab); pane.style.display = (k === tab) ? 'flex' : 'none'; }
    var btn = document.getElementById(tabs[k]);
    if (btn) { btn.style.background = (k === tab) ? '#0F172A' : 'transparent'; btn.style.color = (k === tab) ? '#FFFFFF' : '#475569'; }
  });
}`;
if (t.includes(oldFn)) { t = t.replace(oldFn, newFn); console.log('switchDepositTab: PATCHED'); }
else console.log('switchDepositTab: NOT FOUND');

// Fill personal IBAN in openModal when deposit modal opens
const oldOpen = `    if (document.getElementById('dep-bank-iban')) document.getElementById('dep-bank-iban').innerText = activeIban;
  }`;
const newOpen = `    if (document.getElementById('dep-bank-iban')) document.getElementById('dep-bank-iban').innerText = activeIban;
    if (document.getElementById('dep-personal-iban')) {
      document.getElementById('dep-personal-iban').innerText = activeIban;
      document.getElementById('dep-personal-bank').innerText = appSettings.officialBankName || 'SofiSwift Corporate Bank';
      document.getElementById('dep-personal-holder').innerText = currentUser.name;
    }
  }`;
if (t.includes(oldOpen)) { t = t.replace(oldOpen, newOpen); console.log('personal iban fill: PATCHED'); }
else console.log('personal iban fill: NOT FOUND');

fs.writeFileSync(p, t);
