export default async function run(page, ui) {
  return await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=mime1', { cache: 'no-store' })).text();
    const results = {};
    // Is the trailing IIFE async — maybe it throws before defining? No, function decls hoist before any code runs.
    // Hypothesis: script runs in a DIFFERENT global?  Check by defining a probe var:
    const s = document.createElement('script');
    s.textContent = 'window.__probe1 = 42;';
    document.body.appendChild(s);
    results.probe1 = window.__probe1;
    // Now with the exact app.js text but prefixed by an error catcher:
    const wrapped = 'window.addEventListener("error",function(e){window.__werr=e.message+":"+e.lineno;});try{' + '\n' + t + '\n}catch(e){window.__werr="caught:"+e.message;}';
    const blob = new Blob([wrapped], { type: 'text/javascript' });
    const s2 = document.createElement('script');
    s2.src = URL.createObjectURL(blob);
    document.body.appendChild(s2);
    await new Promise(r => setTimeout(r, 2000));
    results.werr = window.__werr || 'none';
    results.setAuthAfter = typeof window.setAuthMode;
    results.probe2 = window.__probe1;
    return results;
  });
}
