export default async function run(page, ui) {
  const out = {};
  page.on('response', r => { if (r.url().includes('/api/auth')) out.authStatus = r.status(); });
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  const email = 'qa' + Date.now() + '@test.dev';
  const res = await page.evaluate(async ({ email }) => {
    const r = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'QA Tester', email, password: 'test1234', isRegister: true }) });
    const d = await r.json().catch(() => ({}));
    return { status: r.status, keys: Object.keys(d), err: d.error, user: d.user ? { id: d.user.id, iban: d.user.personalIban, trc: d.user.personalTrc20, name: d.user.name } : null };
  }, { email });
  out.api = res;
  return JSON.stringify(out, null, 2);
}
