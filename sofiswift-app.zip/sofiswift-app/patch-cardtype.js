const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');

// ccSelectType: ücretsiz sanal kart mantığı
const anchor = `function updateCardPreviewNetwork() {`;
const newFns = `var ccCardType = 'VIRTUAL';
function ccSelectType(type) {
  ccCardType = type;
  var isVirtual = type === 'VIRTUAL';
  var freeVirtual = isVirtual && !currentUser.hasCard;
  var banner = document.getElementById('cc-free-banner');
  var feeRow = document.getElementById('cc-fee-row');
  var payBox = document.getElementById('cc-payment-details');
  var feeText = document.getElementById('cc-fee-text');
  if (banner) banner.style.display = freeVirtual ? 'block' : 'none';
  if (feeRow) feeRow.style.display = freeVirtual ? 'none' : 'block';
  if (payBox && !freeVirtual) { /* leave as-is until gateway chosen */ }
  if (feeText) feeText.innerHTML = freeVirtual
    ? '<span style="color:#065F46; font-weight:800;">Ücretsiz — aktivasyon ücreti yok!</span>'
    : (isVirtual ? 'Sanal kart aktivasyon ücreti <b style="color:#005470;">$<span class="price-tag">20</span>.00 USD</b>'
                 : 'Plastik kart ücreti <b style="color:#005470;">$<span class="price-tag">20</span>.00 USD</b> + kargo (3-7 iş günü) — ATM ve POS\'larda kullanılabilir.');
  if (freeVirtual && payBox) {
    // Ücretsiz sanal kart: doğrudan talep butonu göster
    payBox.classList.remove('hidden');
    payBox.innerHTML = '<div style="text-align:center; padding:10px;"><div style="font-size:15px; font-weight:800; color:#065F46; margin-bottom:10px;">🎉 Ücretsiz Sanal Kartın Hazır</div><p style="font-size:12px; color:#64748B; margin-bottom:14px;">Aşağıya basarak sanal kartını anında oluştur — Apple Pay ve Google Pay\'e eklenebilir.</p><button type="button" data-act="submit-card-order" class="btn-main">Ücretsiz Kartımı Oluştur</button></div>';
  } else if (feeRow) {
    payBox.classList.add('hidden');
  }
}
` + anchor;
if (t.includes(anchor) && !t.includes('function ccSelectType')) {
  t = t.replace(anchor, newFns); console.log('ccSelectType ADDED');
} else console.log('ccSelectType: already present or anchor missing');

// submitCardControlOrder: ücretsiz sanal kart için API'ye free bayrağı
const oldSubmit = `async function submitCardControlOrder() {
  const paid = document.getElementById('cc-pay-amount').value;
  if (!paid || parseFloat(paid) <= 0) return alert('Enter the amount you sent (USD).');
  const r = await fetch('/api/buy-card', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, brand: document.getElementById('cc-brand-select').value, paidAmount: parseFloat(paid) }) });`;
const newSubmit = `async function submitCardControlOrder() {
  var freeVirtual = ccCardType === 'VIRTUAL' && !currentUser.hasCard;
  var paid = document.getElementById('cc-pay-amount') ? document.getElementById('cc-pay-amount').value : '';
  if (!freeVirtual && (!paid || parseFloat(paid) <= 0)) return alert('Enter the amount you sent (USD).');
  const r = await fetch('/api/buy-card', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, brand: document.getElementById('cc-brand-select').value, paidAmount: freeVirtual ? 0 : parseFloat(paid), cardType: ccCardType, free: freeVirtual }) });`;
if (t.includes(oldSubmit)) { t = t.replace(oldSubmit, newSubmit); console.log('submit PATCHED'); }
else console.log('submit NOT FOUND');

fs.writeFileSync(p, t);
