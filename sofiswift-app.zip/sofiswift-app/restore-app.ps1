$src = 'C:\Users\baran\OneDrive\Desktop\sofiswift-app\app-new-head.js'
$dst = 'C:\Users\baran\OneDrive\Desktop\sofiswift-app\public\app.js'
Write-Output ("source exists: " + (Test-Path $src))
if (Test-Path $src) {
  $s = [System.IO.File]::ReadAllText($src)
  Write-Output ("source len: " + $s.Length)
  Copy-Item $src $dst -Force
  $d = [System.IO.File]::ReadAllText($dst)
  Write-Output ("dest len after copy: " + $d.Length)
  Write-Output ("dest has setAuthMode: " + $d.Contains('function setAuthMode'))
}
