export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push('PE: ' + String(e).slice(0, 300)));
  page.on('console', m => { if (m.type() === 'error') errors.push('CE: ' + m.text().slice(0, 200)); });
  // Block cache completely via CDP
  const cdp = await page.context().newCDPSession(page);
  await cdp.send('Network.setCacheDisabled', { cacheDisabled: true });
  await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(2500);
  const r = {};
  const em = 'nc' + Date.now() + '@mail.com';

  r.fns = await page.evaluate(() => JSON.stringify({
    enterApp: typeof enterApp, doAuth: typeof doAuth, setAuthMode: typeof setAuthMode,
    toggleDrawer: typeof toggleDrawer, openModal: typeof openModal
  }));

  // REGISTER
  await page.evaluate(() => document.getElementById('tab-register').click());
  await page.waitForTimeout(600);
  await page.evaluate(([e]) => {
    const f = document.getElementById('auth-form'); if (f) f.noValidate = true;
    document.getElementById('auth-name').value = 'NoCache Test';
    document.getElementById('auth-email').value = e;
    document.getElementById('auth-pass').value = '123456';
  }, [em]);
  await page.evaluate(() => document.getElementById('auth-btn-text').click());
  await page.waitForTimeout(2500);
  r.dashboard = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));

  // DRAWER + DEPOSIT 3-TAB
  await page.evaluate(() => document.getElementById('menu-open-btn').click());
  await page.waitForTimeout(500);
  r.drawerOpen = await page.evaluate(() => !document.getElementById('side-drawer').classList.contains('closed'));
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-deposit"]').click());
  await page.waitForTimeout(500);
  r.depositOpen = await page.evaluate(() => !document.getElementById('deposit-modal').classList.contains('hidden'));
  await page.evaluate(() => document.querySelector('[data-act="dep-tab-personal"]').click());
  await page.waitForTimeout(400);
  r.personalTab = await page.evaluate(() => !document.getElementById('dep-pane-personal').classList.contains('hidden'));
  r.personalIban = await page.evaluate(() => (document.getElementById('dep-personal-iban')?.innerText || '').slice(0, 25));
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]').click());
  await page.waitForTimeout(300);
  r.depositClosed = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));

  // API VIEW
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-api"]').click());
  await page.waitForTimeout(500);
  r.apiView = await page.evaluate(() => !document.getElementById('api-integration-view').classList.contains('hidden'));
  await page.evaluate(() => document.querySelector('[data-act="generate-api-key"]').click());
  await page.waitForTimeout(300);
  r.apiKey = await page.evaluate(() => (document.getElementById('api-key-box')?.innerText || '').slice(0, 16));

  // CARD CONTROL
  await page.evaluate(() => document.querySelector('#api-integration-view [data-act="show-dashboard"]').click());
  await page.waitForTimeout(400);
  await page.evaluate(() => document.querySelector('#user-dashboard [data-act="menu-card"]').click());
  await page.waitForTimeout(500);
  r.cardView = await page.evaluate(() => !document.getElementById('card-control-view').classList.contains('hidden'));
  r.ccPill = await page.evaluate(() => document.getElementById('cc-status-pill')?.innerText);
  await page.screenshot({ path: 'final-nc.png' });

  r.errors = errors;
  return r;
}
