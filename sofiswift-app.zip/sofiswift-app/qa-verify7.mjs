export default async function run(page, ui) {
  const r = {};
  // Try direct navigation to a data: URL to confirm script execution works at all in this context
  r.evalDirect = await page.evaluate(() => { window.__x = 5; return window.__x; });
  // Try Function constructor
  r.funcCtor = await page.evaluate(() => { new Function('window.__y=6')(); return window.__y; });
  // try appendChild then read after a microtask
  r.microtask = await page.evaluate(async () => {
    const s = document.createElement('script');
    s.textContent = 'window.__z = 9;';
    document.body.appendChild(s);
    await Promise.resolve();
    await new Promise(r2 => setTimeout(r2, 100));
    return window.__z;
  });
  return r;
}
