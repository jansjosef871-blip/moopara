const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');

// 1. showMainView'e api view ekle
const oldView = `function showMainView(v) {
  const dash = document.getElementById('user-dashboard'), card = document.getElementById('card-control-view');
  if (dash) dash.classList.toggle('hidden', v !== 'dashboard');
  if (card) card.classList.toggle('hidden', v !== 'card');
  window.scrollTo(0, 0);
}`;
const newView = `function showMainView(v) {
  const dash = document.getElementById('user-dashboard'), card = document.getElementById('card-control-view'), api = document.getElementById('api-integration-view');
  if (dash) dash.classList.toggle('hidden', v !== 'dashboard');
  if (card) card.classList.toggle('hidden', v !== 'card');
  if (api) api.classList.toggle('hidden', v !== 'api');
  if (v === 'api') renderApiKey();
  window.scrollTo(0, 0);
}`;
if (t.includes(oldView)) { t = t.replace(oldView, newView); console.log('showMainView: PATCHED'); } else console.log('showMainView: NOT FOUND');

// 2. API key fonksiyonları ekle (openKycModal'dan önce)
const anchor = `function openKycModal() {`;
const apiFns = `function generateApiKey() {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let key = 'ss_live_';
  for (let i = 0; i < 32; i++) key += chars[Math.floor(Math.random() * chars.length)];
  appSettings.apiKey = key;
  renderApiKey();
  showBanner('Yeni API anahtarı oluşturuldu! Güvenli bir yerde saklayın.', false);
}
function renderApiKey() {
  const box = document.getElementById('api-key-box');
  if (box) box.innerText = appSettings.apiKey || 'API anahtarı oluşturulmadı — butona basarak oluşturun.';
}
function copyApiKey() {
  if (appSettings.apiKey) { navigator.clipboard.writeText(appSettings.apiKey); alert('API anahtarı kopyalandı!'); }
  else alert('Önce API anahtarı oluşturun.');
}

` + anchor;
if (t.includes(anchor)) { t = t.replace(anchor, apiFns); console.log('api fns: ADDED'); } else console.log('api fns anchor: NOT FOUND');

// 3. delegation'a yeni act'ler ekle (app.js içindeki ikinci delegation switch'te)
const oldCases = `      case 'menu-kyc': case 'open-kyc': toggleDrawer(false); openKycModal(); return;`;
const newCases = oldCases + `
      case 'menu-api': case 'open-api': toggleDrawer(false); showMainView('api'); return;
      case 'generate-api-key': generateApiKey(); return;
      case 'copy-api-key': copyApiKey(); return;
      case 'rotate-api-key': generateApiKey(); return;
      case 'dep-tab-crypto': switchDepositTab('crypto'); return;
      case 'dep-tab-bank': switchDepositTab('bank'); return;
      case 'dep-tab-personal': switchDepositTab('personal'); return;
      case 'copy-personal-iban': navigator.clipboard.writeText(document.getElementById('dep-personal-iban').innerText); alert('Kişisel IBAN kopyalandı!'); return;`;
if (t.includes(oldCases)) { t = t.replace(oldCases, newCases); console.log('delegation cases: PATCHED'); } else console.log('delegation cases: NOT FOUND');

// 4. Dashboard aksiyon satırına API butonu? — dashboard'daki 5 butonun yanına eklemek yerine drawer'da var. Kart kontrol başlığı ile dashboard uyumu için CSS zaten ortak (.card-visual, .panel kullanılıyor).

fs.writeFileSync(p, t);
console.log('done, len:', t.length);
