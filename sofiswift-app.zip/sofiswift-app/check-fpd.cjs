const d = require('fs').readFileSync('public/app.js', 'utf8');
const i = d.indexOf('function fillPersonalDeposit');
console.log(JSON.stringify(d.slice(i, i + 700)));
// also check how currentUser gets set in auth
const j = d.indexOf('function doAuth');
console.log('---doAuth---');
console.log(JSON.stringify(d.slice(j, j + 1300)));
