const fs = require('fs');
let t = fs.readFileSync('public/index.html', 'utf8');
const before = t.length;
t = t.replace(/onclick="closeModal\('([a-z-]+)'\)" class="close-btn"/g, 'data-act="close-$1" class="close-btn"');
t = t.replace(/onclick="copyAddress\(\)" class="btn-copy"/g, 'data-act="copy-addr" class="btn-copy"');
fs.writeFileSync('public/index.html', t);
console.log('replaced, size', before, '->', t.length);
