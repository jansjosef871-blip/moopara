const d = require('fs').readFileSync('public/app.js', 'utf8');
console.log('openModal count:', (d.match(/function openModal/g) || []).length);
// find which openModal actually gets hit: check there's no duplicated script concatenation
const idxs = [...d.matchAll(/function openModal/g)].map(m => d.slice(0, m.index).split('\n').length);
console.log('lines:', idxs);
const i = d.indexOf("'dep-tab-personal': () =>");
console.log(JSON.stringify(d.slice(i, i + 260)));
console.log('fillPersonalDeposit def at line', d.slice(0, d.indexOf('function fillPersonalDeposit')).split('\n').length);
