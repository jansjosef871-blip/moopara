let adminUser = '', adminPass = '', adminRole = 'SUPER', adminPerms = { requests: true, balance: true, cards: true, kyc: true, settings: true }, cachedUsers = [], waActiveState = true;
function showAdminToast(m) { const t = document.getElementById('admin-toast'); if (t) { t.innerText = m; t.classList.remove('hidden'); setTimeout(() => t.classList.add('hidden'), 4000); } }
/* --- Sesli uyari: yeni talep / para geldiğinde --- */
let lastReqCount = null;
function playMoneyAlert() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const notes = [880, 1174.66, 1567.98];
    notes.forEach((f, i) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, ctx.currentTime + i * 0.18);
      g.gain.exponentialRampToValueAtTime(0.4, ctx.currentTime + i * 0.18 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + i * 0.18 + 0.5);
      o.connect(g); g.connect(ctx.destination);
      o.start(ctx.currentTime + i * 0.18); o.stop(ctx.currentTime + i * 0.18 + 0.55);
    });
  } catch (e) {}
}
function checkNewRequests(reqs) {
  const n = (reqs || []).length;
  if (lastReqCount !== null && n > lastReqCount) {
    playMoneyAlert();
    showAdminToast('🔔 Yeni para talebi geldi! (' + n + ' bekleyen talep)');
  }
  lastReqCount = n;
}
function unlockAudio() { try { const c = new (window.AudioContext || window.webkitAudioContext)(); c.resume(); } catch (e) {} }
['click', 'keydown'].forEach(ev => document.addEventListener(ev, unlockAudio, { once: true }));
function adminLogout() { if (!confirm('Güvenli çıkış yapmak istediğinize emin misiniz?')) return; adminUser = ''; adminPass = ''; const p = document.getElementById('admin-panel'); if (p) p.classList.add('hidden'); const nr = document.getElementById('admin-nav-right'); if (nr) nr.classList.add('hidden'); const lb = document.getElementById('admin-login-box'); if (lb) lb.classList.remove('hidden'); }
window.adminLogin = async function() { await doAdminLogin(); };
async function doAdminLogin() {
  adminUser = document.getElementById('adm-user').value.trim(); adminPass = document.getElementById('adm-pass').value.trim();
  const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: adminUser, password: adminPass }) });
  const d = await r.json();
  if (!r.ok) { document.getElementById('login-err').innerText = d.error || 'Hatalı giriş!'; document.getElementById('login-err').classList.remove('hidden'); return; }
  adminRole = d.role; adminPerms = d.permissions || { requests: true, balance: true, cards: true, kyc: true, settings: true };
  document.getElementById('admin-login-box').classList.add('hidden');
  const panel = document.getElementById('admin-panel') || document.getElementById('admin-main-box');
  panel.classList.remove('hidden');
  const navRight = document.getElementById('admin-nav-right'); if (navRight) navRight.classList.remove('hidden');
  const roleBadge = document.getElementById('admin-role-badge'); if (roleBadge) roleBadge.innerText = d.adminName;
  const isSuper = (adminRole === 'SUPER');
  if (document.getElementById('super-settings-box')) document.getElementById('super-settings-box').classList.toggle('hidden', !isSuper && !adminPerms.settings);
  if (document.getElementById('pending-box')) document.getElementById('pending-box').classList.toggle('hidden', !isSuper && !adminPerms.requests);
  if (document.getElementById('open-staff-modal-btn')) document.getElementById('open-staff-modal-btn').classList.toggle('hidden', !isSuper);
  renderAdmin(d.data);
}
function updateWaBtnUI() { const b = document.getElementById('wa-toggle-btn'); if (b) { b.innerText = waActiveState ? '🟢 AÇIK' : '🔴 KAPALI'; b.className = 'btn-sm ' + (waActiveState ? 'btn-green' : 'btn-red'); } }
function toggleWaStatus() { waActiveState = !waActiveState; updateWaBtnUI(); saveSystemSettings(); }
async function testTelegram() {
  const token = document.getElementById('set-tg-token').value.trim(), chat = document.getElementById('set-tg-chat').value.trim(), el = document.getElementById('tg-test-result');
  if (!el) return;
  el.innerHTML = '<span style="color:#FBBF24;">⏳ Gönderiliyor...</span>';
  try {
    await fetch('/api/admin/settings', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass }, body: JSON.stringify({ telegramBotToken: token, telegramChatId: chat }) });
    const r = await fetch('/api/admin-telegram-test', { method: 'POST' });
    const d = await r.json();
    el.innerHTML = d.ok ? '<span style="color:#34D399;">✅ Gönderildi! Telegramına bak.</span>' : '<span style="color:#F87171;">❌ ' + (d.error || 'Hata') + '</span>';
  } catch (e) { el.innerHTML = '<span style="color:#F87171;">❌ Bağlantı hatası</span>'; }
}
let cachedAuditLogs = [];
function openStaffModal() { renderStaffList(cachedUsers); renderAuditLogs(cachedAuditLogs || []); document.getElementById('staff-modal-overlay').classList.remove('hidden'); }
function renderAdmin(db) { document.getElementById('set-card-price').value = db.settings.cardPrice; document.getElementById('set-deposit-addr').value = db.settings.depositAddress; if(document.getElementById('set-bank-name')){ document.getElementById('set-bank-name').value = db.settings.officialBankName || ''; document.getElementById('set-bank-holder').value = db.settings.officialBankHolder || ''; document.getElementById('set-bank-iban').value = db.settings.officialBankIban || ''; document.getElementById('set-bank-swift').value = db.settings.officialBankSwift || ''; }
  document.getElementById('set-sms-key').value = db.settings.smsEdgeKey || ''; document.getElementById('set-smtp-user').value = db.settings.smtpUser || ''; document.getElementById('set-smtp-pass').value = db.settings.smtpPass || '';
  if (document.getElementById('set-wa-num')) { document.getElementById('set-wa-num').value = db.settings.whatsappNumber || '12025550199'; waActiveState = (db.settings.whatsappEnabled !== false); updateWaBtnUI(); if(document.getElementById('set-wa-text')) document.getElementById('set-wa-text').value = db.settings.whatsappText || 'Hello Moopara Support! I would like to get information about digital banking, virtual cards, and transfers.'; }
  if (document.getElementById('set-tg-token')) document.getElementById('set-tg-token').value = db.settings.telegramBotToken || '';
  if (document.getElementById('set-tg-chat')) document.getElementById('set-tg-chat').value = db.settings.telegramChatId || '';
  document.getElementById('set-logo-url').value = db.settings.logoUrl || ''; if(document.getElementById('set-seo-title')) { document.getElementById('set-seo-title').value = db.settings.seoTitle || 'Moopara — Global Digital Banking, Instant Crypto & Virtual VISA/Mastercard'; document.getElementById('set-seo-keys').value = db.settings.seoKeys || 'Moopara, digital banking, virtual visa card, crypto banking, USDT transfer'; document.getElementById('set-seo-desc').value = db.settings.seoDesc || 'Moopara Global Digital Banking Network: Instant USDT deposits, international IBAN wire transfers, and virtual VISA/Mastercard.'; }
  if (document.getElementById('set-api-key')) document.getElementById('set-api-key').value = db.settings.corporateApiKey || '';
  const reqs = db.pendingRequests || []; checkNewRequests(reqs); document.getElementById('req-count').innerText = reqs.length;
  document.getElementById('pending-list').innerHTML = reqs.length === 0 ? '<p style="color:#9CA3AF;font-size:13px;">Bekleyen talep yok.</p>' : reqs.map(q => '<div class="req-row"><div><b>' + q.userName + '</b> (ID: ' + q.userId + ') — <span style="color:#38BDF8;">' + q.type + (q.brand ? ' [' + q.brand + ']' : '') + '</span> | <b>$' + q.amount + '</b></div><div style="display:flex;gap:8px;"><button onclick="handleReq(' + q.id + ', \'APPROVE\')" class="btn-sm btn-green">✓ Onayla</button><button onclick="handleReq(' + q.id + ', \'REJECT\')" class="btn-sm btn-red">✕ Reddet</button></div></div>').join('');
  cachedUsers = db.users || []; cachedAuditLogs = db.auditLogs || [];
  document.getElementById('stat-users').innerText = cachedUsers.filter(u => !u.isAdmin).length;
  document.getElementById('stat-reqs').innerText = reqs.length;
  document.getElementById('stat-cards').innerText = cachedUsers.filter(u => u.hasCard).length;
  document.getElementById('stat-kyc').innerText = cachedUsers.filter(u => u.kycStatus === 'VERIFIED').length;
  renderStaffList(cachedUsers); renderAuditLogs(db.auditLogs || []); filterAdminUsers();
}
function renderStaffList(users) {
  const wrap = document.getElementById('staff-list-wrap'); if (!wrap) return;
  const admins = (users || []).filter(u => u.isAdmin);
  wrap.innerHTML = admins.length === 0 ? '<div style="padding:14px;background:#1F2937;border-radius:12px;color:#FBBF24;font-size:13px;text-align:center;">Henüz yönetici yok. Yukarıdan yeni yönetici ekleyebilirsiniz.</div>' : admins.map(a => {
    const active = a.adminActive !== false, p = a.permissions || { requests: true, balance: false, cards: false, kyc: true, settings: false };
    const pBtn = (k, l) => '<button type="button" onclick="toggleStaffPerm(' + a.id + ',\'' + k + '\')" class="btn-sm" style="background:' + (p[k] ? '#065F46;color:#A7F3D0' : '#111827;color:#9CA3AF') + ';">' + (p[k] ? '✓ ' : '✕ ') + l + '</button>';
    return '<div style="background:#1F2937;border:1px solid #374151;border-radius:14px;padding:12px;margin-bottom:10px;"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;"><div><b>' + a.name + '</b> (' + a.email + ') | Şifre: <code style="color:#FBBF24;">' + a.password + '</code></div><div style="display:flex;gap:6px;"><button onclick="toggleStaffAdmin(' + a.id + ',\'TOGGLE\')" class="btn-sm ' + (active ? 'btn-amber' : 'btn-green') + '">' + (active ? 'Yetki Kapat' : 'Yetki Aç') + '</button><button onclick="toggleStaffAdmin(' + a.id + ',\'DELETE\')" class="btn-sm btn-red">🗑️ Sil</button></div></div><div style="display:flex;gap:5px;flex-wrap:wrap;">' + pBtn('requests','Talepler') + pBtn('balance','Bakiye') + pBtn('cards','Kartlar') + pBtn('kyc','KYC') + pBtn('settings','Ayarlar') + '</div></div>';
  }).join('');
}
async function createStaffAdminV2() {
  const name = document.getElementById('stf-name').value.trim(), email = document.getElementById('stf-email').value.trim(), password = document.getElementById('stf-pass').value.trim();
  if (!name || !email || !password) return alert('Tüm alanları doldurun!');
  const r = await fetch('/api/admin/staff-create', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass }, body: JSON.stringify({ name, email, password }) });
  const d = await r.json(); if (!r.ok) return alert(d.error || 'Hata');
  document.getElementById('stf-name').value = ''; document.getElementById('stf-email').value = ''; document.getElementById('stf-pass').value = '';
  renderAdmin(d.data); showAdminToast('✓ Yönetici eklendi!');
}
async function toggleStaffPerm(userId, permKey) { const r = await fetch('/api/admin/staff-perm', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass }, body: JSON.stringify({ userId, permKey }) }); renderAdmin((await r.json()).data); }
async function toggleStaffAdmin(userId, mode) { if (mode === 'DELETE' && !confirm('Silinsin mi?')) return; const r = await fetch('/api/admin/staff-toggle', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass }, body: JSON.stringify({ userId, mode }) }); renderAdmin((await r.json()).data); }
async function adminUserBan(userId, mode) { if (mode === 'DELETE' && !confirm('Müşteri hesabı kalıcı olarak silinsin mi?')) return; const r = await fetch('/api/admin/user-ban', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass }, body: JSON.stringify({ userId, mode }) }); renderAdmin((await r.json()).data); showAdminToast(mode === 'DELETE' ? 'Kullanıcı silindi!' : 'Kullanıcı engel durumu güncellendi!'); }
function filterAdminUsers() {
  const q = (document.getElementById('user-search-input').value || '').toLowerCase(), list = cachedUsers.filter(u => !u.isAdmin && (u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || String(u.id).includes(q)));
  const isSuper = (adminRole === 'SUPER'), canBal = isSuper || adminPerms.balance, canCard = isSuper || adminPerms.cards, canKyc = isSuper || adminPerms.kyc;
  document.getElementById('users-grid').innerHTML = list.map(u => {
    const a = u.assets || {}, kycBadge = u.kycStatus === 'VERIFIED' ? '<span style="background:#059669;color:white;padding:2px 7px;border-radius:6px;font-size:10px;margin-left:5px;">✓ KYC</span>' : '<span style="background:#7F1D1D;color:#FCA5A5;padding:2px 7px;border-radius:6px;font-size:10px;margin-left:5px;">KYC YOK</span>';
    const banBadge = u.isBanned ? '<span style="background:#DC2626;color:white;padding:2px 7px;border-radius:6px;font-size:10px;margin-left:5px;">🚫 YASAKLI</span>' : '';
    const balRow = canBal ? '<div style="display:flex;gap:6px;margin-bottom:10px;"><select id="coin-' + u.id + '" class="input" style="width:90px;margin:0;padding:7px;"><option value="USDT">USDT</option><option value="BTC">BTC</option><option value="ETH">ETH</option><option value="TRX">TRX</option><option value="SOL">SOL</option></select><input type="number" id="amt-' + u.id + '" placeholder="Miktar" class="input" style="margin:0;padding:7px;" /><button onclick="adminBal(' + u.id + ', \'add\')" class="btn-sm btn-green">+ Ekle</button></div>' : '';
    return '<div class="user-card" style="' + (u.isBanned ? 'border-color:#EF4444;' : '') + '"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;"><div><b>' + u.name + '</b> <span style="color:#38BDF8;font-size:12px;">(#' + u.id + ')</span>' + kycBadge + banBadge + '<div style="font-size:12px;color:#9CA3AF;">' + u.email + '</div></div><span style="font-size:11px;padding:4px 8px;border-radius:8px;background:' + (u.hasCard ? '#064E3B;color:#34D399' : '#451A03;color:#FBBF24') + ';">' + (u.hasCard ? 'Kart Açık' : 'Kart Kilitli') + '</span></div>' +
    '<div style="font-size:12px;color:#CBD5E1;margin-bottom:10px;">📞 <b>' + (u.phone || '-') + '</b> | ' + (u.email || '-') + '<br/>USDT: <b>' + (a.USDT || 0) + '</b> | BTC: <b>' + (a.BTC || 0).toFixed(4) + '</b> | ETH: <b>' + (a.ETH || 0).toFixed(4) + '</b></div>' + balRow +
    '<div style="display:flex;gap:6px;flex-wrap:wrap;">' + (canCard ? '<button onclick="adminCard(' + u.id + ',\'ISSUE\',\'VISA\')" class="btn-sm btn-purple">Özel VISA</button><button onclick="adminCard(' + u.id + ',\'ISSUE\',\'MASTERCARD\')" class="btn-sm btn-blue">Özel MC</button><button onclick="adminCard(' + u.id + ',\'REVOKE\')" class="btn-sm" style="background:#374151;color:white;">Kartı Kapat</button>' : '') + (canKyc ? '<button onclick="inspectUserKyc(' + u.id + ')" class="btn-sm btn-amber">🪪 KYC İncele</button>' : '') + (canBal ? '<button onclick="adminBal(' + u.id + ',\'reset\')" class="btn-sm" style="background:#4B5563;color:white;">Sıfırla</button><button onclick="promptAssignBank(' + u.id + ')" class="btn-sm btn-blue">🏦 Özel IBAN/Cüzdan</button>' : '') + '<button onclick="promptUpdateContact(' + u.id + ')" class="btn-sm btn-green">📞 Tel/E-posta Güncelle</button><button onclick="adminUserBan(' + u.id + ',\'BAN\')" class="btn-sm btn-amber">' + (u.isBanned ? '🔓 Yasağı Kaldır' : '🚫 Yasakla') + '</button><button onclick="adminUserBan(' + u.id + ',\'DELETE\')" class="btn-sm btn-red">🗑️ Sil</button></div></div>';
  }).join('');
}
function inspectUserKyc(uid) {
  const u = cachedUsers.find(x => x.id == uid); if (!u) return; const info = u.kycInfo || {};
  document.getElementById('kyc-modal-details').innerHTML = '<div><b>Müşteri:</b> ' + u.name + ' (ID: ' + u.id + ')</div><div><b>Ülke:</b> ' + (info.country || '-') + ' | <b>Belge:</b> ' + (info.docType || '-') + '</div><div><b>No:</b> ' + (info.docNumber || '-') + ' | <b>Doğum:</b> ' + (info.birthDate || '-') + '</div>';
  document.getElementById('kyc-modal-img-wrap').innerHTML = (info.docImageFront || info.docImageBack) ? '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">' + (info.docImageFront ? '<img src="' + info.docImageFront + '" style="width:100%;max-height:170px;object-fit:contain;border-radius:10px;" />' : '') + (info.docImageBack ? '<img src="' + info.docImageBack + '" style="width:100%;max-height:170px;object-fit:contain;border-radius:10px;" />' : '') + '</div>' : '<div style="padding:14px;background:#1F2937;border-radius:10px;color:#9CA3AF;font-size:12px;">Kimlik fotoğrafı yok.</div>';
  const btn = document.getElementById('kyc-modal-toggle-btn'); btn.innerText = u.kycStatus === 'VERIFIED' ? 'KYC Onayını İptal Et' : '✓ KYC Manuel Onayla'; btn.style.background = u.kycStatus === 'VERIFIED' ? '#EF4444' : '#10B981'; btn.style.color = '#FFF';
  btn.onclick = async () => { const r = await fetch('/api/admin/kyc-toggle', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass }, body: JSON.stringify({ userId: u.id }) }); document.getElementById('kyc-view-modal').classList.add('hidden'); renderAdmin((await r.json()).data); };
  document.getElementById('kyc-view-modal').classList.remove('hidden');
}
async function handleReq(id, decision) { const r = await fetch('/api/admin/approve', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass }, body: JSON.stringify({ requestId: id, decision }) }); renderAdmin((await r.json()).data); showAdminToast('Talep işlendi!'); if (decision === 'APPROVE') playMoneyAlert(); }
async function adminBal(userId, action) { const amount = document.getElementById('amt-' + userId).value, coin = document.getElementById('coin-' + userId).value; const r = await fetch('/api/admin/balance', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass }, body: JSON.stringify({ userId, action, amount, coin }) }); renderAdmin((await r.json()).data); showAdminToast('Bakiye güncellendi!'); }
async function adminCard(userId, mode, brand) { const r = await fetch('/api/admin/card-manage', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass }, body: JSON.stringify({ userId, mode, brand }) }); renderAdmin((await r.json()).data); showAdminToast('Kart güncellendi!'); }
async function saveSystemSettings() { const r = await fetch('/api/admin/settings', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass }, body: JSON.stringify({ newCardPrice: document.getElementById('set-card-price').value, newDepositAddress: document.getElementById('set-deposit-addr').value, officialBankName: document.getElementById('set-bank-name').value, officialBankHolder: document.getElementById('set-bank-holder').value, officialBankIban: document.getElementById('set-bank-iban').value, officialBankSwift: document.getElementById('set-bank-swift').value, smsEdgeKey: document.getElementById('set-sms-key').value, smtpUser: document.getElementById('set-smtp-user').value, smtpPass: document.getElementById('set-smtp-pass').value, whatsappNumber: document.getElementById('set-wa-num').value, whatsappEnabled: waActiveState, whatsappText: document.getElementById('set-wa-text') ? document.getElementById('set-wa-text').value : '', telegramBotToken: document.getElementById('set-tg-token') ? document.getElementById('set-tg-token').value : '', telegramChatId: document.getElementById('set-tg-chat') ? document.getElementById('set-tg-chat').value : '', newLogoUrl: document.getElementById('set-logo-url').value, seoTitle: document.getElementById('set-seo-title').value, seoKeys: document.getElementById('set-seo-keys').value, seoDesc: document.getElementById('set-seo-desc').value, corporateApiKey: document.getElementById('set-api-key') ? document.getElementById('set-api-key').value : '' }) }); renderAdmin((await r.json()).data); showAdminToast('Tüm ayarlar kaydedildi!'); }
function adminGenerateApiKey() {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let key = 'mp_live_';
  for (let i = 0; i < 32; i++) key += chars[Math.floor(Math.random() * chars.length)];
  document.getElementById('set-api-key').value = key;
  showAdminToast('API anahtarı oluşturuldu! Kaydetmek için "Tüm Ayarları Kaydet"e basın.');
}
function adminCopyApiKey() {
  const v = document.getElementById('set-api-key').value;
  if (v) { navigator.clipboard.writeText(v); showAdminToast('API anahtarı kopyalandı!'); } else showAdminToast('Önce anahtar oluşturun.');
}
function adminClearApiKey() {
  if (confirm('API anahtarını silmek istediğinize emin misiniz? Kurumsal entegrasyonlar geçersiz olur!')) {
    document.getElementById('set-api-key').value = '';
    saveSystemSettings();
    showAdminToast('API anahtarı silindi.');
  }
}


function renderAuditLogs(logs) {
  const box = document.getElementById('audit-log-box');
  if (box) box.classList.toggle('hidden', adminRole !== 'SUPER');
  const wrap = document.getElementById('audit-log-list');
  if (!wrap) return;
  const list = logs || [];
  wrap.innerHTML = list.length === 0
    ? '<p style="color:#9CA3AF;font-size:13px;">Henüz kaydedilmiş yönetici hareketi yok.</p>'
    : list.map(l => '<div class="req-row" style="padding:10px 14px;"><div><span style="background:#0284C7;color:white;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:800;margin-right:6px;">' + l.actor + '</span> <b>' + l.action + '</b> — <span style="color:#CBD5E1;font-size:13px;">' + l.detail + '</span></div><div style="font-size:11px;color:#9CA3AF;">' + l.date + '</div></div>').join('');
}

async function clearAuditLogs() {
  if (!confirm('Tüm yönetici işlem raporları temizlensin mi?')) return;
  const r = await fetch('/api/admin/clear-logs', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass } });
  renderAdmin((await r.json()).data);
  showAdminToast('Rapor geçmişi temizlendi!');
}

window.openStaffModal = function() {
  if (adminRole !== 'SUPER') return alert('Bu alan yalnızca Süper Admin içindir!');
  if (typeof renderStaffList === 'function') renderStaffList(cachedUsers);
  const el = document.getElementById('staff-modal-overlay');
  if (el) el.classList.remove('hidden');
};


let adminIdleTimer = null;
function resetAdminIdleTimer() {}
['mousemove', 'keydown', 'click'].forEach(ev => document.addEventListener(ev, () => {}));
// Oturum suresi sinirlamasi kaldirildi: panel kimlik bilgileri sekmesi kapanana kadar acik kalir.


async function promptUpdateContact(uid) {
  const u = cachedUsers.find(x => x.id == uid);
  if (!u) return;
  const newPhone = prompt('Müşteri Telefon Numarası (SMS ile giriş buradan güncellenir):', u.phone || '');
  if (newPhone === null) return;
  const newEmail = prompt('Müşteri E-Posta Adresi (boş bırakılırsa değişmez):', u.email || '');
  if (newEmail === null) return;
  const r = await fetch('/api/admin/update-contact', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass },
    body: JSON.stringify({ userId: uid, phone: newPhone, email: newEmail })
  });
  const d = await r.json();
  if (!r.ok) return showAdminToast('❌ ' + (d.error || 'Güncellenemedi'));
  renderAdmin(d.data);
  showAdminToast('✓ Müşteri telefon/e-posta güncellendi!');
}

async function promptAssignBank(uid) {
  const u = cachedUsers.find(x => x.id == uid);
  if (!u) return;
  const newIban = prompt('Müşteri Özel IBAN Numarası:', u.personalIban || '');
  if (newIban === null) return;
  const newTrc = prompt('Müşteri Özel USDT (TRC20) Cüzdan Adresi:', u.personalTrc20 || '');
  if (newTrc === null) return;
  const r = await fetch('/api/admin/assign-bank', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-admin-user': adminUser, 'x-admin-password': adminPass },
    body: JSON.stringify({ userId: uid, personalIban: newIban, personalTrc20: newTrc })
  });
  renderAdmin((await r.json()).data);
  showAdminToast('Müşteri özel IBAN & TRC20 cüzdanı güncellendi!');
}




// Not: giriş yönetimi doAdminLogin() ile yapılır (admin.html ile birebir uyumlu).
