$dst = 'C:\Users\baran\OneDrive\Desktop\sofiswift-app\public\app.js'
Copy-Item 'C:\Users\baran\OneDrive\Desktop\sofiswift-app\public\app.js.bak' $dst -Force
$d = [System.IO.File]::ReadAllText($dst)
Write-Output ("restored len: " + $d.Length)
Write-Output ("has setAuthMode: " + $d.Contains('function setAuthMode'))
Write-Output ("has delegation switch: " + $d.Contains('menu-deposit'))
# toggleDrawer fix
$old = "function toggleDrawer(open) { document.getElementById('drawer-backdrop').classList.toggle('hidden', !open); document.getElementById('side-drawer').classList.toggle('open', open); }"
$new = "function toggleDrawer(open) { document.getElementById('drawer-backdrop').classList.toggle('hidden', !open); var d = document.getElementById('side-drawer'); d.classList.toggle('closed', !open); d.classList.toggle('open', !!open); }"
if ($d.Contains($old)) {
  $d = $d.Replace($old, $new)
  [System.IO.File]::WriteAllText($dst, $d)
  Write-Output 'toggleDrawer FIXED'
} else { Write-Output 'toggleDrawer pattern check:'; $i = $d.IndexOf('function toggleDrawer'); Write-Output $d.Substring($i, 230) }
