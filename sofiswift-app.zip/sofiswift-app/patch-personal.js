const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');

// Personal tab should ALWAYS show user's own IBAN (fallback to official only if missing)
const oldOpen = `    if (document.getElementById('dep-personal-iban')) {
      document.getElementById('dep-personal-iban').innerText = activeIban;
      document.getElementById('dep-personal-bank').innerText = appSettings.officialBankName || 'SofiSwift Corporate Bank';
      document.getElementById('dep-personal-holder').innerText = currentUser.name;
    }`;
const newOpen = `    if (document.getElementById('dep-personal-iban')) {
      var myIban = currentUser.personalIban || activeIban;
      document.getElementById('dep-personal-iban').innerText = myIban;
      document.getElementById('dep-personal-bank').innerText = appSettings.officialBankName || 'SofiSwift Corporate Bank';
      document.getElementById('dep-personal-holder').innerText = currentUser.name;
      var myTrc = document.getElementById('dep-personal-trc');
      if (myTrc) myTrc.innerText = currentUser.personalTrc20 || '';
    }`;
if (t.includes(oldOpen)) { t = t.replace(oldOpen, newOpen); console.log('personal iban: user-own PATCHED'); }
else console.log('personal iban fill NOT FOUND');

// Deposit modal QR should use personal TRC20 if exists (user-specific deposit)
const oldTrc = `    const isCustomTrc = currentUser.personalTrc20 && !currentUser.personalTrc20.startsWith('TTZ');
    const activeTrc = isCustomTrc ? currentUser.personalTrc20 : appSettings.depositAddress;`;
const newTrc = `    const activeTrc = currentUser.personalTrc20 || appSettings.depositAddress;`;
if (t.includes(oldTrc)) { t = t.replace(oldTrc, newTrc); console.log('trc20 user-specific PATCHED'); }
else console.log('trc20 pattern NOT FOUND');

// IBAN bank pane also user-specific
const oldIbanSel = `    const isCustomIban = currentUser.personalIban && !currentUser.personalIban.startsWith('US64 SOFI');
    const activeIban = isCustomIban ? currentUser.personalIban : (appSettings.officialBankIban || 'US89 SOFI 0001 9988 7766 55');`;
const newIbanSel = `    const activeIban = currentUser.personalIban || (appSettings.officialBankIban || 'US89 SOFI 0001 9988 7766 55');`;
if (t.includes(oldIbanSel)) { t = t.replace(oldIbanSel, newIbanSel); console.log('iban user-specific PATCHED'); }
else console.log('iban pattern NOT FOUND');

fs.writeFileSync(p, t);
