export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  // login if needed
  const hasLogin = await page.evaluate(() => !!document.querySelector('#login-username'));
  if (hasLogin) {
    await page.fill('#login-username', 'demo');
    await page.fill('#login-password', 'demo1234');
    await page.click('button[type="submit"]');
    await page.waitForTimeout(1200);
  }
  // open deposit modal via menu button if present
  await page.evaluate(() => {
    const btn = [...document.querySelectorAll('[data-act]')].find(b => ['menu-deposit', 'open-deposit'].includes(b.dataset.act));
    if (btn) btn.click();
  });
  await page.waitForTimeout(500);
  out.modalOpen = await page.evaluate(() => !document.getElementById('deposit-modal')?.classList.contains('hidden'));
  out.tabs = {};
  for (const t of ['personal', 'bank', 'crypto']) {
    await page.evaluate(tab => document.querySelector('[data-act="dep-tab-' + tab + '"]')?.click(), t);
    await page.waitForTimeout(250);
    out.tabs[t] = await page.evaluate(tab => {
      const pane = document.getElementById('dep-pane-' + tab);
      const btn = document.querySelector('[data-act="dep-tab-' + tab + '"]');
      return pane ? { display: getComputedStyle(pane).display, hidden: pane.classList.contains('hidden'), btnActive: btn ? btn.style.background !== 'transparent' : null } : 'missing';
    }, t);
  }
  await page.evaluate(() => document.querySelector('[data-act="dep-tab-personal"]')?.click());
  await page.waitForTimeout(300);
  out.personal = await page.evaluate(() => ({
    iban: document.getElementById('dep-personal-iban')?.innerText,
    holder: document.getElementById('dep-personal-holder')?.innerText,
    bank: document.getElementById('dep-personal-bank')?.innerText,
    trc: document.getElementById('dep-personal-trc')?.innerText?.slice(0, 14)
  }));
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]')?.click());
  await page.waitForTimeout(300);
  out.closedAfterX = await page.evaluate(() => document.getElementById('deposit-modal')?.classList.contains('hidden'));
  await page.screenshot({ path: 'finish-final.png' });
  return JSON.stringify(out, null, 2);
}
