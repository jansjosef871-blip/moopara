export default async function run(page, ui) {
  const out = {};
  // Auth screen first
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2500);
  out.pwa = await page.evaluate(() => {
    const btn = document.getElementById('pwa-install-btn');
    return { btnExists: !!btn, btnVisible: btn ? getComputedStyle(btn).display : 'no-el', rowText: (document.getElementById('pwa-install-row') || {}).innerText?.slice(0, 60) };
  });
  // Admin — direct navigation
  await page.goto('http://localhost:3000/admin.html', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1500);
  out.adminLoaded = await page.evaluate(() => ({ hasLogin: !!document.getElementById('loginDiv'), title: document.title }));
  await page.evaluate(() => { document.getElementById('u').value = 'atmaca'; document.getElementById('p').value = 'admin2026!'; giris(); });
  await page.waitForTimeout(1500);
  await page.evaluate(() => sekme('settings'));
  await page.waitForTimeout(400);
  out.adminTg = await page.evaluate(() => ({
    tokenField: !!document.getElementById('sTgToken'),
    chatField: !!document.getElementById('sTgChat'),
    testBtn: !!document.querySelector('button[onclick="testTelegram()"]'),
    holderField: !!document.getElementById('sHolder'),
    text: document.getElementById('icerik').innerText.slice(0, 100)
  }));
  await page.screenshot({ path: 'admin-settings.png' });
  return out;
}
