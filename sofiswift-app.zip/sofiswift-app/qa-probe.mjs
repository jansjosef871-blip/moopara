export default async function run(page, ui) {
  const res = {};
  res.scriptText = await page.evaluate(() => Array.from(document.scripts).map(s => ({ src: s.src, textLen: (s.textContent||'').length })));
  res.contentType = await page.evaluate(async () => { const r = await fetch('/app.js?v=30000001'); return r.headers.get('content-type') + ' len ' + (await r.text()).length; });
  res.winKeys = await page.evaluate(() => ['setAuthMode','doAuth','openModal','updateDashboard','sendOtpCode'].map(k => k + ':' + typeof window[k]).join(','));
  res.declaredFns = await page.evaluate(() => Object.keys(window).filter(k => k.toLowerCase().includes('auth')).slice(0, 20).join(','));
  return res;
}
