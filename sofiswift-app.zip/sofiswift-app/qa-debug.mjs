export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 200)));
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type().toUpperCase() + ': ' + m.text().slice(0, 150)); });
  await page.goto('http://localhost:3000/', { waitUntil: 'load' });
  await page.waitForTimeout(1500);
  const report = {};
  report.scripts = await page.evaluate(() => [...document.querySelectorAll('script[src]')].map(s => s.src.split('/').pop()));
  report.actionsLoaded = await page.evaluate(() => !!document.querySelector('script[src*="actions.js"]'));
  // Click register tab and inspect
  await page.click('#tab-register');
  await page.waitForTimeout(500);
  report.afterRegisterClick = await page.evaluate(() => ({
    nameFieldClass: document.getElementById('name-field').className,
    nameVisible: getComputedStyle(document.getElementById('name-field')).display,
    title: document.getElementById('auth-title').innerText,
    regActive: document.getElementById('tab-register').classList.contains('active')
  }));
  return { report, errors };
}
