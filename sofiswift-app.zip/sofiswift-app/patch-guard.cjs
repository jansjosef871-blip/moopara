const fs = require('fs');
let d = fs.readFileSync('public/app.js', 'utf8');
d = d.replace("function fillPersonalDeposit() {\n  const ib =", "function fillPersonalDeposit() {\n  if (!currentUser) return;\n  const ib =");
fs.writeFileSync('public/app.js', d);
console.log('guard added');
