export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(2200);
  await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=' + Math.random(), { cache: 'no-store' })).text();
    (0, eval)(t);
  });

  // 1. PWA install button visible on auth screen?
  out.pwaBtn = await page.evaluate(() => {
    const row = document.getElementById('pwa-install-row');
    return { exists: !!row, hiddenByStandalone: row ? row.classList.contains('hidden') : null };
  });

  // 2. Register user (demo OTP path — but smsEdge key set, so sent:true; we need the code. Use admin action? No: intercept DB? Use the server's pendingOtps via register with wrong code first, then... Simplest: create user directly via /api/auth with otp bypass is not possible. Instead check bill providers + admin API via direct server calls after registering through the OTP we can't read.
  // Workaround: temp-disable? No — verify real OTP path is the point. Instead test admin + bill UI logic directly.
  out.billProviders = await page.evaluate(() => {
    const sel = document.getElementById('bill-provider');
    return { total: sel.options.length, groups: sel.optgroups ? sel.optgroups.length : sel.querySelectorAll('optgroup').length, hasTurkcell: !!sel.querySelector('option[value="Türkcell"]'), hasTtMobil: !!sel.querySelector('option[value="Türk Telekom Mobil"]'), hasIski: !!sel.querySelector('option[value="İSKİ"]') };
  });

  // 3. Admin: create API key
  out.adminLogin = await page.evaluate(async () => {
    const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'atmaca', password: 'admin2026!', totpCode: '' }) });
    return { status: r.status };
  });
  out.apiCreate = await page.evaluate(async () => {
    const r = await fetch('/api/admin-panel-action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'api-create', siteName: 'ShopA Test', siteUrl: 'https://shopa.example.com', contactEmail: 'info@shopa.example.com' }) });
    return await r.json();
  });
  out.apiList = await page.evaluate(async () => {
    const r = await fetch('/api/admin-panel-full');
    const d = await r.json();
    return (d.corporateMembers || []).map(m => ({ name: m.companyName, url: m.website, admin: m.createdBy === 'admin', keyPrefix: m.apiKey.slice(0, 12) }));
  });
  // 4. Use the created key on the public payment API
  out.payWithKey = await page.evaluate(async (k) => {
    const r = await fetch('/api/v1/payments', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + k }, body: JSON.stringify({ amount: 25, orderId: 'ORD-1' }) });
    return { status: r.status, body: await r.json() };
  }, out.apiCreate.apiKey);
  await page.screenshot({ path: 'features-check.png' });
  return out;
}
