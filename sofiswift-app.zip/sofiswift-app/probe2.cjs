const d = require('fs').readFileSync('served-admin.html', 'utf8');
// find second occurrence of set-bank-name (in JS)
const first = d.indexOf('set-bank-name');
const second = d.indexOf('set-bank-name', first + 1);
console.log('1st:', first, '2nd:', second);
console.log(JSON.stringify(d.slice(second - 300, second + 250)));
