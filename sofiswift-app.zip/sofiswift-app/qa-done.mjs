export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push('PE: ' + String(e).slice(0, 200)));
  await page.goto('http://localhost:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForTimeout(3000);
  const r = {};
  const em = 'done' + Date.now() + '@mail.com';

  // REGISTER
  await page.evaluate(() => document.getElementById('tab-register').click());
  await page.waitForTimeout(600);
  r.nameShown = await page.evaluate(() => !document.getElementById('name-field').classList.contains('hidden'));
  await page.evaluate(([e]) => {
    const f = document.getElementById('auth-form'); if (f) f.noValidate = true;
    document.getElementById('auth-name').value = 'Son Kontrol';
    document.getElementById('auth-email').value = e;
    document.getElementById('auth-pass').value = '123456';
  }, [em]);
  await page.evaluate(() => document.getElementById('auth-btn-text').click());
  await page.waitForTimeout(2500);
  r.dashboard = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));
  r.balanceColor = await page.evaluate(() => getComputedStyle(document.getElementById('user-balance')).color);

  // DRAWER + DEPOSIT 3-TAB
  await page.evaluate(() => document.getElementById('menu-open-btn').click());
  await page.waitForTimeout(500);
  r.drawerOpen = await page.evaluate(() => !document.getElementById('side-drawer').classList.contains('closed'));
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-deposit"]').click());
  await page.waitForTimeout(500);
  r.depositOpen = await page.evaluate(() => !document.getElementById('deposit-modal').classList.contains('hidden'));
  await page.evaluate(() => document.querySelector('[data-act="dep-tab-personal"]').click());
  await page.waitForTimeout(400);
  r.personalTab = await page.evaluate(() => !document.getElementById('dep-pane-personal').classList.contains('hidden'));
  r.personalIban = await page.evaluate(() => (document.getElementById('dep-personal-iban')?.innerText || '').slice(0, 25));
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]').click());
  await page.waitForTimeout(300);
  r.depositClosed = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));

  // API VIEW (Papara benzeri)
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-api"]').click());
  await page.waitForTimeout(500);
  r.apiView = await page.evaluate(() => !document.getElementById('api-integration-view').classList.contains('hidden'));
  await page.evaluate(() => document.querySelector('[data-act="generate-api-key"]').click());
  await page.waitForTimeout(300);
  r.apiKey = await page.evaluate(() => (document.getElementById('api-key-box')?.innerText || '').slice(0, 16));

  // CARD CONTROL (tasarım uyumu)
  await page.evaluate(() => document.querySelector('#api-integration-view [data-act="show-dashboard"]').click());
  await page.waitForTimeout(400);
  await page.evaluate(() => document.querySelector('#user-dashboard [data-act="menu-card"]').click());
  await page.waitForTimeout(500);
  r.cardView = await page.evaluate(() => !document.getElementById('card-control-view').classList.contains('hidden'));
  r.ccPill = await page.evaluate(() => document.getElementById('cc-status-pill')?.innerText);
  r.chipOnDash = await page.evaluate(() => !!document.querySelector('#user-dashboard .card-chip'));
  r.chipOnCard = await page.evaluate(() => !!document.querySelector('#card-control-view .card-chip'));

  // Close drawer + screenshot of card control
  await page.evaluate(() => document.querySelector('[data-act="drawer-close"]').click());
  await page.waitForTimeout(400);
  await page.screenshot({ path: 'card-control.png' });
  // Dashboard screenshot
  await page.evaluate(() => document.querySelector('#card-control-view [data-act="show-dashboard"]').click());
  await page.waitForTimeout(400);
  await page.screenshot({ path: 'dashboard-final.png' });

  r.errors = errors;
  return r;
}
