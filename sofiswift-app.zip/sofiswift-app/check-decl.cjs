const d = require('fs').readFileSync('public/app.js', 'utf8');
// Is there a SECOND top-level `let currentUser` declaration? That would shadow in eval scope.
const decls = [...d.matchAll(/^let currentUser/gm)].map(m => d.slice(0, m.index).split('\n').length);
console.log('let currentUser decls:', decls);
// check var vs let; also check for '(0,eval)' shadowing: let/const in eval create new scope for... no, direct eval in global creates global let? Actually indirect eval creates vars in global object only for var.
console.log('uses let:', d.startsWith('let currentUser'));
