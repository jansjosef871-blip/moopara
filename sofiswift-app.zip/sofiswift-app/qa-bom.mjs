export default async function run(page, ui) {
  return await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=bomtest')).text();
    const results = {};
    try { new Function(t); results.newFunction = 'ok'; } catch (e) { results.newFunction = e.message; }
    results.firstCodes = [...t.slice(0, 5)].map(c => c.charCodeAt(0)).join(',');
    // Check strict-mode issue: top-level let redeclare?
    try { window.eval('function __probe(){};' + t); results.evalDirect = typeof window.setAuthMode; } catch (e) { results.evalDirect = 'ERR ' + e.message; }
    return results;
  });
}
