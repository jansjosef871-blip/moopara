const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');
const bad = "ATM ve POS ve ATM'lerde kullanılabilir.";
const good = 'ATM ve POS harcamalarinda kullanilabilir.';
if (t.includes(bad)) { t = t.replace(bad, good); fs.writeFileSync(p, t); console.log('FIXED'); }
else console.log('not found');
