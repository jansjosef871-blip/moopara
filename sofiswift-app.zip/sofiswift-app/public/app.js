﻿/* moopara — mobil cüzdan uygulaması (TR/EN/RU) */
var currentUser = null, isRegisterMode = false;
var appSettings = { cardPrice: 20, depositAddress: 'TX9aK8pL2mQ7vR4wN1zB6cJ3yH5fD8sG0e' };
var prices = { USDT: 1, USDC: 1, BTC: 91500, ETH: 3120, SOL: 210, TRX: 0.25, XRP: 1.15, BNB: 620, ADA: 0.75, AVAX: 38 };
let fxRates = { USD: 34.20, EUR: 36.80 };
let lang = localStorage.getItem('mp_lang') || 'tr';

const COINS = [
  { sym: 'USDT', name: 'Tether USD', bg: '#10B981', txt: '₮' },
  { sym: 'BTC', name: 'Bitcoin', bg: '#F59E0B', txt: '₿' },
  { sym: 'ETH', name: 'Ethereum', bg: '#6366F1', txt: 'Ξ' },
  { sym: 'SOL', name: 'Solana', bg: '#14B8A6', txt: 'S' },
  { sym: 'TRX', name: 'TRON', bg: '#EF444', txt: 'T' },
  { sym: 'XRP', name: 'Ripple', bg: '#0EA5E9', txt: 'X' }
];
const ALL_COUNTRIES = ["Turkey","United States","Georgia","Germany","United Kingdom","France","Netherlands","Switzerland","United Arab Emirates","Saudi Arabia","Qatar","Azerbaijan","Russia","Ukraine","Kazakhstan","Uzbekistan","Turkmenistan","Kyrgyzstan","Tajikistan","Albania","Algeria","Andorra","Angola","Argentina","Armenia","Australia","Austria","Bahrain","Bangladesh","Belarus","Belgium","Bosnia and Herzegovina","Brazil","Bulgaria","Canada","Chile","China","Colombia","Croatia","Cyprus","Czech Republic","Denmark","Egypt","Estonia","Finland","Greece","Hungary","Iceland","India","Indonesia","Iran","Iraq","Ireland","Israel","Italy","Japan","Jordan","Kenya","Kuwait","Latvia","Lebanon","Libya","Lithuania","Luxembourg","Malaysia","Malta","Mexico","Moldova","Monaco","Montenegro","Morocco","New Zealand","Nigeria","North Macedonia","Norway","Oman","Pakistan","Palestine","Peru","Philippines","Poland","Portugal","Romania","Serbia","Singapore","Slovakia","Slovenia","South Africa","South Korea","Spain","Sweden","Syria","Taiwan","Thailand","Tunisia","Vietnam","Yemen"];

/* ================= DİL SÖZLÜĞÜ ================= */
const T = {
  tr: {
    welcome: 'Dijital cüzdanına hoş geldin', desc: 'TL, USD ve EUR hesapların, sanal kartın ve kripto cüzdanın — tek uygulamada.',
    login: 'Giriş Yap', register: 'Kayıt Ol', name: 'Ad Soyad', phone: 'Telefon Numarası', email: 'E-Posta (opsiyonel)', pass: 'Şifre', otp: 'SMS Doğrulama Kodu', sendCode: 'Kod Gönder',
    secureLogin: 'Güvenli Giriş', createAcc: 'Hesabımı Oluştur',
    hello: 'Hoş geldin', balance: 'Toplam Bakiye', subBal: 'TL · USD · EUR hesapları',
    deposit: 'Yatır', send: 'Gönder', myCard: 'Kartım', fx: 'Döviz',
    accounts: 'Döviz Hesapları', crypto: 'Kripto Portföy', txs: 'Son İşlemler', home: 'Ana Sayfa', card: 'Kart', menu: 'Menü',
    msMain: 'Ana İşlemler', msOther: 'Diğer', miDeposit: 'Para Yatır', miWithdraw: 'Para Gönder / Çek', miFx: 'Döviz Al / Sat', miSwap: 'Kripto Dönüştür', miBills: 'Fatura Öde', miCard: 'Kart Kontrol', miLoan: 'Kredi Talebi', miKyc: 'Kimlik Doğrulama', miLang: 'Dil / Language / Язык', miLogout: 'Çıkış Yap',
    noTx: 'Henüz işlem yok.',
    dmTitle: 'Para Yatır', dpAmount: 'Tutar (USD / USDT)', dpSubmit: 'Yatırım Bildirimi Gönder', copy: 'Kopyala',
    smTitle: '💸 Para Gönder', smTarget: 'Alıcı (ID / E-posta / Telefon)', smAmount: 'Tutar', smNote: 'Not (opsiyonel)', smSubmit: 'Hemen Gönder',
    wmTitle: 'Para Çek', wmMethod: 'Yöntem', wmIban: 'Banka (IBAN / SWIFT)', wmInternal: 'moopara Anında Transfer (ID)', wmCrypto: 'Kripto Cüzdan (USDT TRC20)', wmBank: 'Banka Adı', wmHolder: 'Hesap Sahibi', wmNum: 'IBAN / Hesap No', wmSwift: 'SWIFT (opsiyonel)', wmTarget: 'Alıcı ID / Cüzdan Adresi', wmAmount: 'Tutar ($ USD)', wmSubmit: 'Gönder',
    fxmTitle: '💱 Döviz Al / Sat', fxmFrom: 'Hangi hesaptan', fxmTo: 'Hangi hesaba', fxmAmount: 'Tutar', fxmSubmit: 'Dönüştür',
    bmTitle: '🧾 Fatura Öde', bmProvider: 'Kurum', bmSub: 'Abone No', bmAmount: 'Tutar (₺)', bmSubmit: 'Öde',
    kmTitle: '🪙 Kripto Dönüştür', kmSpend: 'Harcanacak USDT ($)', kmRecv: 'Alınacak Kripto', kmSubmit: 'Dönüştür',
    lmTitle: '📄 Kredi Talebi', lmAmount: 'Talep Tutarı ($)', lmTerm: 'Vade (ay)', lmSubmit: 'Başvuruyu Gönder',
    ymTitle: '🛡️ Kimlik Doğrulama (KYC)', ymCountry: 'Ülke', ymDocType: 'Belge Türü', ymDocNum: 'Belge No', ymBirth: 'Doğum Tarihi', ymFront: 'Ön Yüz Fotoğrafı', ymBack: 'Arka Yüz Fotoğrafı', ymSubmit: 'Doğrula',
    lgmTitle: '🌐 Dil seçimi',
    ccvTitle: 'Kart Kontrol', ccvSettings: 'Kart Ayarları', ccvOnline: 'Online Alışveriş', ccvContactless: 'Temassız Ödeme', ccvIntl: 'Yurt Dışı Harcamalar', ccvApply: 'Kart Başvurusu', ccvBtn: 'Ücretsiz Kart Al',
    curTRY: 'Türk Lirası', curUSD: 'Dolar', curEUR: 'Euro', inTRY: 'TL karşılığı',
    okCopy: '✓ Kopyalandı', needLogin: 'Önce giriş yapın.'
  },
  en: {
    welcome: 'Welcome to your digital wallet', desc: 'TRY, USD and EUR accounts, your virtual card and crypto wallet — all in one app.',
    login: 'Sign In', register: 'Sign Up', name: 'Full Name', phone: 'Phone Number', email: 'E-mail (optional)', pass: 'Password', otp: 'SMS Verification Code', sendCode: 'Send Code',
    secureLogin: 'Secure Sign In', createAcc: 'Create My Account',
    hello: 'Welcome', balance: 'Total Balance', subBal: 'TRY · USD · EUR accounts',
    deposit: 'Deposit', send: 'Send', myCard: 'My Card', fx: 'Currency',
    accounts: 'Currency Accounts', crypto: 'Crypto Portfolio', txs: 'Recent Transactions', home: 'Home', card: 'Card', menu: 'Menu',
    msMain: 'Main Actions', msOther: 'Other', miDeposit: 'Deposit Money', miWithdraw: 'Send / Withdraw', miFx: 'Buy / Sell Currency', miSwap: 'Convert Crypto', miBills: 'Pay Bills', miCard: 'Card Control', miLoan: 'Loan Request', miKyc: 'Identity Verification', miLang: 'Language / Dil / Язык', miLogout: 'Sign Out',
    noTx: 'No transactions yet.',
    dmTitle: 'Deposit', dpAmount: 'Amount (USD / USDT)', dpSubmit: 'Submit Deposit Notice', copy: 'Copy',
    smTitle: '💸 Send Money', smTarget: 'Recipient (ID / E-mail / Phone)', smAmount: 'Amount', smNote: 'Note (optional)', smSubmit: 'Send Now',
    wmTitle: 'Withdraw', wmMethod: 'Method', wmIban: 'Bank (IBAN / SWIFT)', wmInternal: 'moopara Instant Transfer (ID)', wmCrypto: 'Crypto Wallet (USDT TRC20)', wmBank: 'Bank Name', wmHolder: 'Account Holder', wmNum: 'IBAN / Account No', wmSwift: 'SWIFT (optional)', wmTarget: 'Recipient ID / Wallet Address', wmAmount: 'Amount ($ USD)', wmSubmit: 'Send',
    fxmTitle: '💱 Buy / Sell Currency', fxmFrom: 'From account', fxmTo: 'To account', fxmAmount: 'Amount', fxmSubmit: 'Convert',
    bmTitle: '🧾 Pay Bills', bmProvider: 'Provider', bmSub: 'Subscriber No', bmAmount: 'Amount (₺)', bmSubmit: 'Pay',
    kmTitle: '🪙 Convert Crypto', kmSpend: 'Spend USDT ($)', kmRecv: 'Receive Crypto', kmSubmit: 'Convert',
    lmTitle: '📄 Loan Request', lmAmount: 'Requested Amount ($)', lmTerm: 'Term (months)', lmSubmit: 'Submit Application',
    ymTitle: '🛡️ Identity Verification (KYC)', ymCountry: 'Country', ymDocType: 'Document Type', ymDocNum: 'Document No', ymBirth: 'Date of Birth', ymFront: 'Front Side Photo', ymBack: 'Back Side Photo', ymSubmit: 'Verify',
    lgmTitle: '🌐 Select language',
    ccvTitle: 'Card Control', ccvSettings: 'Card Settings', ccvOnline: 'Online Shopping', ccvContactless: 'Contactless Payment', ccvIntl: 'International Spending', ccvApply: 'Card Application', ccvBtn: 'Get Free Card',
    curTRY: 'Turkish Lira', curUSD: 'US Dollar', curEUR: 'Euro', inTRY: 'in TRY',
    okCopy: '✓ Copied', needLogin: 'Please sign in first.'
  },
  ru: {
    welcome: 'Добро пожаловать в ваш цифровой кошелёк', desc: 'Счета в TL, USD и EUR, виртуальная карта и криптокошелёк — в одном приложении.',
    login: 'Войти', register: 'Регистрация', name: 'Имя и фамилия', phone: 'Номер телефона', email: 'E-mail (необязательно)', pass: 'Пароль', otp: 'Код из SMS', sendCode: 'Отправить код',
    secureLogin: 'Безопасный вход', createAcc: 'Создать аккаунт',
    hello: 'Добро пожаловать', balance: 'Общий баланс', subBal: 'Счета TL · USD · EUR',
    deposit: 'Пополнить', send: 'Отправить', myCard: 'Карта', fx: 'Валюта',
    accounts: 'Валютные счета', crypto: 'Криптопортфель', txs: 'Последние операции', home: 'Главная', card: 'Карта', menu: 'Меню',
    msMain: 'Основные операции', msOther: 'Другое', miDeposit: 'Пополнить счёт', miWithdraw: 'Отправить / Вывести', miFx: 'Купить / Продать валюту', miSwap: 'Обмен крипты', miBills: 'Оплатить счета', miCard: 'Управление картой', miLoan: 'Заявка на кредит', miKyc: 'Верификация личности', miLang: 'Язык / Dil / Language', miLogout: 'Выйти',
    noTx: 'Операций пока нет.',
    dmTitle: 'Пополнение', dpAmount: 'Сумма (USD / USDT)', dpSubmit: 'Отправить уведомление', copy: 'Копировать',
    smTitle: '💸 Отправить деньги', smTarget: 'Получатель (ID / E-mail / Телефон)', smAmount: 'Сумма', smNote: 'Примечание (необязательно)', smSubmit: 'Отправить',
    wmTitle: 'Вывод средств', wmMethod: 'Способ', wmIban: 'Банк (IBAN / SWIFT)', wmInternal: 'moopara мгновенный перевод (ID)', wmCrypto: 'Криптокошелёк (USDT TRC20)', wmBank: 'Название банка', wmHolder: 'Владелец счёта', wmNum: 'IBAN / Номер счёта', wmSwift: 'SWIFT (необязательно)', wmTarget: 'ID получателя / адрес кошелька', wmAmount: 'Сумма ($ USD)', wmSubmit: 'Отправить',
    fxmTitle: '💱 Купить / Продать валюту', fxmFrom: 'Со счёта', fxmTo: 'На счёт', fxmAmount: 'Сумма', fxmSubmit: 'Конвертировать',
    bmTitle: '🧾 Оплата счетов', bmProvider: 'Организация', bmSub: 'Номер абонента', bmAmount: 'Сумма (₺)', bmSubmit: 'Оплатить',
    kmTitle: '🪙 Обмен криптовалюты', kmSpend: 'Списать USDT ($)', kmRecv: 'Получить криптовалюту', kmSubmit: 'Конвертировать',
    lmTitle: '📄 Заявка на кредит', lmAmount: 'Запрашиваемая сумма ($)', lmTerm: 'Срок (месяцев)', lmSubmit: 'Отправить заявку',
    ymTitle: '🛡️ Верификация личности (KYC)', ymCountry: 'Страна', ymDocType: 'Тип документа', ymDocNum: 'Номер документа', ymBirth: 'Дата рождения', ymFront: 'Фото лицевой стороны', ymBack: 'Фото обратной стороны', ymSubmit: 'Подтвердить',
    lgmTitle: '🌐 Выбор языка',
    ccvTitle: 'Управление картой', ccvSettings: 'Настройки карты', ccvOnline: 'Онлайн-покупки', ccvContactless: 'Бесконтактная оплата', ccvIntl: 'Расходы за рубежом', ccvApply: 'Заявка на карту', ccvBtn: 'Получить бесплатную карту',
    curTRY: 'Турецкая лира', curUSD: 'Доллар США', curEUR: 'Евро', inTRY: 'в TL',
    okCopy: '✓ Скопировано', needLogin: 'Сначала войдите в систему.'
  }
};
function tr(key) { return (T[lang] && T[lang][key]) || T.tr[key] || key; }

const CUR_META = {
  TRY: { name: 'curTRY', sym: '₺', bg: '#E30A17', flag: '🇹🇷' },
  USD: { name: 'curUSD', sym: '$', bg: '#0EA5E9', flag: '🇺🇸' },
  EUR: { name: 'curEUR', sym: '€', bg: '#2563EB', flag: '🇪🇺' }
};
function fmtCur(v, cur) {
  const sym = (CUR_META[cur] || {}).sym || '';
  return sym + Number(v || 0).toLocaleString(lang === 'tr' ? 'tr-TR' : 'en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/* ================= TEMEL UI ================= */
function openModal(id) {
  if (id === 'deposit-modal' && currentUser) {
    const isCustomTrc = currentUser.personalTrc20 && !currentUser.personalTrc20.startsWith('TTZ');
    const activeTrc = isCustomTrc ? currentUser.personalTrc20 : appSettings.depositAddress;
    const wBox = document.getElementById('deposit-wallet-box'); if (wBox) wBox.innerText = activeTrc;
    setQr('dep-qr-box', activeTrc);
    const isCustomIban = currentUser.personalIban && !currentUser.personalIban.startsWith('US64 SOFI');
    const activeIban = isCustomIban ? currentUser.personalIban : (appSettings.officialBankIban || 'US89 MOOP 0001 998 776 55');
    if (document.getElementById('dep-personal-bank')) document.getElementById('dep-personal-bank').innerText = appSettings.officialBankName || 'Moopara Corporate Bank';
    if (document.getElementById('dep-personal-holder')) document.getElementById('dep-personal-holder').innerText = currentUser.fullName || currentUser.name || '-';
    const iEl = document.getElementById('dep-personal-iban'); if (iEl) iEl.innerText = activeIban;
  }
  if (id === 'fx-modal') updateFxRateInfo();
  const el = document.getElementById(id); if (el) el.classList.remove('hidden');
}
function closeModal(id) { const el = document.getElementById(id); if (el) el.classList.add('hidden'); }
function fillPersonalDeposit() {
  if (!currentUser) return;
  const ib = (currentUser.personalIban && !currentUser.personalIban.startsWith('US64 SOFI')) ? currentUser.personalIban : (appSettings.officialBankIban || 'US89 SOFI 0001 9988 7766 55');
  const pq = document.getElementById('dep-personal-qr');
  if (pq) pq.innerHTML = '<img src="/api/qr?text=' + encodeURIComponent(ib) + '" alt="QR" style="width:150px;height:150px;border-radius:12px;border:1px solid #E2E8F0;padding:6px;background:white;" />';
  const iE = document.getElementById('dep-personal-iban'); if (iE) iE.innerText = ib;
  const hE = document.getElementById('dep-personal-holder'); if (hE) hE.innerText = currentUser.fullName || currentUser.name || '-';
  const bE = document.getElementById('dep-personal-bank'); if (bE) bE.innerText = appSettings.officialBankName || 'Moopara Corporate Bank';
}
function toggleMenu(open) {
  document.getElementById('menu-backdrop').classList.toggle('hidden', !open);
  document.getElementById('menu-sheet').classList.toggle('hidden', !open);
}
function showBanner(msg, isErr) {
  const b = document.getElementById('alert-box'); if (!b || !msg) return;
  b.innerText = msg; b.className = 'banner ' + (isErr ? 'banner-err' : 'banner-ok'); b.classList.remove('hidden');
  setTimeout(() => b.classList.add('hidden'), 6000);
}
function showMainView(v) {
  const dash = document.getElementById('user-dashboard'), card = document.getElementById('card-control-view');
  if (dash) dash.classList.toggle('hidden', v !== 'dashboard');
  if (card) card.classList.toggle('hidden', v !== 'card');
  window.scrollTo(0, 0);
}
function setQr(boxId, text) {
  const b = document.getElementById(boxId);
  if (b) b.innerHTML = '<img src="/api/qr?text=' + encodeURIComponent(text) + '" style="width:150px;height:150px;border-radius:12px;border:1px solid #E2E8F0;padding:6px;background:white;" />';
}
function copyText(txt) { navigator.clipboard.writeText(txt); showBanner(tr('okCopy'), false); }
function copyAddress() {
  const txt = document.getElementById('deposit-wallet-box') ? document.getElementById('deposit-wallet-box').innerText : appSettings.depositAddress;
  copyText(txt);
}

/* ================= DİL ================= */
function applyLang() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-lang]').forEach(b => b.classList.toggle('on', b.dataset.lang === lang && b.classList.contains('lang-btn')));
  const set = (id, key) => { const el = document.getElementById(id); if (el && T[lang] && T[lang][key] !== undefined) el.innerText = T[lang][key]; };
  set('auth-title', 'welcome'); set('auth-desc', 'desc'); set('lbl-name', 'name'); set('lbl-phone', 'phone');
  set('lbl-email', 'email'); set('lbl-pass', 'pass'); set('lbl-otp', 'otp');
  set('auth-btn-text', isRegisterMode ? 'createAcc' : 'secureLogin');
  set('tab-login', 'login'); set('tab-register', 'register');
  document.getElementById('send-otp-btn').innerText = tr('sendCode');
  set('head-greet', 'hello'); set('lbl-balance', 'balance'); set('bal-sub', 'subBal');
  set('q-deposit', 'deposit'); set('q-send', 'send'); set('q-card', 'myCard'); set('q-fx', 'fx');
  set('sec-accounts', 'accounts'); set('sec-crypto', 'crypto'); set('sec-tx', 'txs');
  set('tb-home', 'home'); set('tb-fx', 'fx'); set('tb-card', 'card'); set('tb-menu', 'menu');
  set('ms-main', 'msMain'); set('ms-other', 'msOther');
  set('mi-deposit', 'miDeposit'); set('mi-withdraw', 'miWithdraw'); set('mi-fx', 'miFx'); set('mi-swap', 'miSwap');
  set('mi-bills', 'miBills'); set('mi-card', 'miCard'); set('mi-loan', 'miLoan'); set('mi-kyc', 'miKyc'); set('mi-logout', 'miLogout');
  set('dm-title', 'dmTitle'); set('dp-amount', 'dpAmount'); set('dp-submit', 'dpSubmit'); set('dp-personal-title', ''); 
  set('sm-title', 'smTitle'); set('sm-target', 'smTarget'); set('sm-amount', 'smAmount'); set('sm-note', 'smNote'); set('sm-submit', 'smSubmit');
  set('wm-title', 'wmTitle'); set('wm-method', 'wmMethod'); set('wm-iban', 'wmIban'); set('wm-internal', 'wmInternal'); set('wm-crypto', 'wmCrypto');
  set('wm-bank', 'wmBank'); set('wm-holder', 'wmHolder'); set('wm-num', 'wmNum'); set('wm-swift', 'wmSwift'); set('wm-target', 'wmTarget'); set('wm-amount', 'wmAmount'); set('wm-submit', 'wmSubmit');
  set('fxm-title', 'fxmTitle'); set('fxm-from', 'fxmFrom'); set('fxm-to', 'fxmTo'); set('fxm-amount', 'fxmAmount'); set('fxm-submit', 'fxmSubmit');
  set('bm-title', 'bmTitle'); set('bm-provider', 'bmProvider'); set('bm-sub', 'bmSub'); set('bm-amount', 'bmAmount'); set('bm-submit', 'bmSubmit');
  set('km-title', 'kmTitle'); set('km-spend', 'kmSpend'); set('km-recv', 'kmRecv'); set('km-submit', 'kmSubmit');
  set('lm-title', 'lmTitle'); set('lm-amount', 'lmAmount'); set('lm-term', 'lmTerm'); set('lm-submit', 'lmSubmit');
  set('ym-title', 'ymTitle'); set('ym-country', 'ymCountry'); set('ym-doctype', 'ymDocType'); set('ym-docnum', 'ymDocNum');
  set('ym-birth', 'ymBirth'); set('ym-front', 'ymFront'); set('ym-back', 'ymBack'); set('ym-submit', 'ymSubmit');
  set('lgm-title', 'lgmTitle');
  set('ccv-title', 'ccvTitle'); set('ccv-settings', 'ccvSettings'); set('ccv-online', 'ccvOnline');
  set('ccv-contactless', 'ccvContactless'); set('ccv-intl', 'ccvIntl'); set('ccv-apply', 'ccvApply'); set('ccv-btn', 'ccvBtn');
  document.querySelectorAll('.btn-copy').forEach(b => b.innerText = tr('copy'));
  const miLang = document.getElementById('mi-lang'); if (miLang) miLang.innerText = tr('miLang');
  updateDashboard();
}
function setLang(l) { lang = l; localStorage.setItem('mp_lang', l); applyLang(); closeModal('lang-modal'); }

/* ================= AUTH ================= */
function setAuthMode(register) {
  isRegisterMode = register;
  document.getElementById('tab-login').classList.toggle('active', !register);
  document.getElementById('tab-register').classList.toggle('active', register);
  document.getElementById('name-field').classList.toggle('hidden', !register);
  document.getElementById('otp-field').classList.toggle('hidden', !register);
  document.getElementById('auth-title').innerText = register ? (lang === 'ru' ? 'Откройте бесплатный счёт' : lang === 'en' ? 'Open a free account' : 'Ücretsiz Hesap Aç') : tr('welcome');
  document.getElementById('auth-btn-text').innerText = register ? tr('createAcc') : tr('secureLogin');
  document.getElementById('auth-pass').setAttribute('autocomplete', register ? 'new-password' : 'current-password');
  document.getElementById('auth-error').classList.add('hidden');
}
function showAuthError(msg) { const err = document.getElementById('auth-error'); err.innerText = msg; err.classList.remove('hidden'); }
function setAuthLoading(loading) { const btn = document.getElementById('auth-btn-text'); btn.disabled = loading; btn.classList.toggle('loading', loading); }

async function sendOtpCode() {
  const phone = document.getElementById('auth-phone').value.trim();
  const email = document.getElementById('auth-email').value.trim() || phone;
  if (!phone || phone.replace(/[^0-9]/g, '').length < 10) return showAuthError(lang === 'ru' ? 'Введите действительный номер телефона.' : lang === 'en' ? 'Please enter a valid phone number.' : 'Lütfen geçerli bir telefon numarası girin.');
  const btn = document.getElementById('send-otp-btn');
  btn.disabled = true; btn.innerText = '...';
  try {
    const r = await fetch('/api/send-otp', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, phone }) });
    const d = await r.json();
    if (!r.ok) { showAuthError(d.error || 'Error'); return; }
    if (d.sent) showAuthError('✅ SMS doğrulama kodu telefonunuza gönderildi.');
    else showAuthError('⚠️ SMS servisi yapılandırılmamış (test kodu: ' + (d.demoCode || '—') + ') — canlıya almak için yönetici paneline SmsEdge API anahtarını girin.');
    let left = 60; const t = setInterval(() => { left--; btn.innerText = left + ' sn'; if (left <= 0) { clearInterval(t); btn.disabled = false; btn.innerText = tr('sendCode'); } }, 1000);
  } catch (e) { showAuthError('Connection error'); btn.disabled = false; }
}
async function doAuth(e) {
  if (e) e.preventDefault();
  const name = document.getElementById('auth-name').value.trim();
  const phone = document.getElementById('auth-phone').value.trim();
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-pass').value;
  const otpCode = document.getElementById('auth-otp').value.trim();
  const passInput = document.getElementById('auth-pass'), phoneInput = document.getElementById('auth-phone');
  passInput.classList.remove('error'); phoneInput.classList.remove('error');
  if (!phone || phone.replace(/[^0-9]/g, '').length < 10) { showAuthError(lang === 'ru' ? 'Введите действительный номер телефона.' : lang === 'en' ? 'Please enter a valid phone number.' : 'Lütfen geçerli bir telefon numarası girin.'); phoneInput.classList.add('error'); phoneInput.focus(); return; }
  if (!password || password.length < 4) { showAuthError(lang === 'ru' ? 'Пароль минимум 4 символа.' : lang === 'en' ? 'Password must be at least 4 characters.' : 'Şifre en az 4 karakter olmalıdır.'); passInput.classList.add('error'); passInput.focus(); return; }
  if (isRegisterMode && !name) { showAuthError(lang === 'ru' ? 'Введите имя и фамилию.' : lang === 'en' ? 'Please enter your full name.' : 'Lütfen ad ve soyadınızı girin.'); document.getElementById('auth-name').focus(); return; }
  if (isRegisterMode && (!otpCode || otpCode.length !== 6)) { showAuthError(lang === 'ru' ? 'Введите 6-значный код из SMS.' : lang === 'en' ? 'Enter the 6-digit SMS code.' : 'Telefonunuza gönderilen 6 haneli SMS kodunu girin.'); document.getElementById('auth-otp').focus(); return; }
  setAuthLoading(true);
  try {
    const r = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, email: email || phone, phone, password, otpCode, isRegister: isRegisterMode }) });
    const d = await r.json();
    if (!r.ok) { showAuthError(d.error || 'Error'); return; }
    currentUser = d.user; appSettings = d.settings || appSettings; prices = d.prices || prices;
    localStorage.setItem('mp_user', JSON.stringify({ id: currentUser.id, password }));
    enterApp();
  } catch (e) { showAuthError(lang === 'en' ? 'Connection error. Please try again.' : 'Bağlantı hatası. Lütfen tekrar deneyin.'); }
  finally { setAuthLoading(false); }
}
let pwaPromptEvent = null;
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); pwaPromptEvent = e; const b = document.getElementById('pwa-install-btn'); if (b) b.style.display = 'inline-block'; });
function installPwa() {
  if (pwaPromptEvent) { pwaPromptEvent.prompt(); pwaPromptEvent.userChoice.then(() => { pwaPromptEvent = null; const r = document.getElementById('pwa-install-row'); if (r) r.classList.add('hidden'); }); }
  else { alert('Uygulamayı yüklemek için tarayıcı menüsünden "Ana ekrana ekle / Uygulamayı yükle" seçeneğini kullanın.'); }
}
function enterApp() {
  const pir = document.getElementById('pwa-install-row'); if (pir) pir.classList.add('hidden');
  document.getElementById('auth-section').classList.add('hidden');
  document.getElementById('user-dashboard').classList.remove('hidden');
  document.querySelectorAll('.price-tag').forEach(el => el.innerText = appSettings.cardPrice);
  updateDashboard();
}
function logout() {
  currentUser = null; isRegisterMode = false;
  localStorage.removeItem('mp_user');
  document.getElementById('user-dashboard').classList.add('hidden');
  const card = document.getElementById('card-control-view'); if (card) card.classList.add('hidden');
  toggleMenu(false);
  setAuthMode(false);
  document.getElementById('auth-section').classList.remove('hidden');
}

/* ================= DASHBOARD ================= */
function totalTry() {
  if (!currentUser) return 0;
  const a = currentUser.assets || {};
  let t = (a.TRY || 0) + (a.USD || 0) * fxRates.USD + (a.EUR || 0) * fxRates.EUR;
  COINS.forEach(c => { t += (a[c.sym] || 0) * (prices[c.sym] || 0) * fxRates.USD; });
  return t;
}
function updateDashboard() {
  if (!currentUser) return;
  const a = currentUser.assets || {};
  const sym = { tr: '₺', ru: '₺', en: '₺' }[lang] || '₺';
  document.getElementById('user-balance').innerText = sym + totalTry().toLocaleString(lang === 'tr' ? 'tr-TR' : 'en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const nm = currentUser.name || 'm';
  document.getElementById('head-name').innerText = nm;
  document.getElementById('head-avatar').innerText = nm[0].toUpperCase();
  document.getElementById('menu-user-name').innerText = nm;
  document.getElementById('menu-user-id').innerText = 'ID: ' + currentUser.id;
  document.getElementById('menu-avatar').innerText = nm[0].toUpperCase();

  // Döviz hesapları
  const fx = document.getElementById('fx-accounts');
  if (fx) fx.innerHTML = ['TRY', 'USD', 'EUR'].map(cur => {
    const m = CUR_META[cur];
    const amt = a[cur] || 0;
    const trVal = cur === 'TRY' ? '' : '<div class="acc-amt-sub">≈ ' + fmtCur(cur === 'USD' ? amt * fxRates.USD : amt * fxRates.EUR, 'TRY') + ' ' + tr('inTRY') + '</div>';
    return '<div class="acc-row"><div style="display:flex;align-items:center;gap:12px;"><div class="acc-ico" style="background:' + m.bg + ';">' + m.flag + '</div><div><div class="acc-name">' + tr(m.name) + '</div><div class="acc-sub">' + cur + ' Hesabı</div></div></div><div style="text-align:right;"><div class="acc-amt">' + fmtCur(amt, cur) + '</div>' + trVal + '</div></div>';
  }).join('');

  // Kart
  const holder = (currentUser.name || '').toUpperCase();
  const cn = document.getElementById('card-holder-name'); if (cn) cn.innerText = holder;
  const logo = document.getElementById('card-brand-logo'); if (logo) logo.innerText = currentUser.hasCard ? currentUser.cardBrand : 'VISA';
  const num = document.getElementById('card-num-text'); if (num) num.innerText = currentUser.hasCard ? currentUser.cardNumber : '**** ****';
  const exp = document.getElementById('card-exp-text'); if (exp) exp.innerText = currentUser.hasCard ? (currentUser.cardExpiry || '--/--') : '--/--';
  const ccNum = document.getElementById('cc-card-number'); if (ccNum) ccNum.innerText = currentUser.hasCard ? currentUser.cardNumber : '**** ****';
  const ccCvv = document.getElementById('cc-card-cvv'); if (ccCvv) ccCvv.innerText = 'CVV: ' + (currentUser.hasCard ? (currentUser.cardCvv || '***') : '***');
  const ccExp = document.getElementById('cc-card-exp'); if (ccExp) ccExp.innerText = currentUser.hasCard ? (currentUser.cardExpiry || '--/--') : '--/--';
  const badge = document.getElementById('cc-brand-badge'); if (badge) badge.innerText = currentUser.hasCard ? currentUser.cardBrand : 'MASTERCARD';

  // Kripto
  const cl = document.getElementById('live-crypto-list');
  if (cl) cl.innerHTML = COINS.map(c => {
    const qty = a[c.sym] || 0, usd = qty * (prices[c.sym] || 0);
    const has = qty > 0;
    return '<div class="list-item"><div style="display:flex;align-items:center;gap:12px;"><div style="width:34px;height:34px;border-radius:50%;background:' + c.bg + ';color:white;display:flex;align-items:center;justify-content:center;font-weight:800;">' + c.txt + '</div><div><div style="font-weight:800;font-size:14px;">' + c.sym + ' <span style="font-weight:500;color:#64748B;font-size:12px;">($' + (prices[c.sym] || 0).toLocaleString('en-US') + ')</span></div><div style="font-size:12px;color:#64748B;">' + c.name + '</div></div></div><div style="text-align:right;"><div style="font-weight:800;font-size:14px;' + (has ? 'color:#10B981;' : 'color:#64748B;') + '">' + qty.toLocaleString('en-US', { maximumFractionDigits: 5 }) + ' ' + c.sym + '</div><div style="font-size:12px;color:#64748B;">≈ ' + fmtCur(usd * fxRates.USD, 'TRY') + '</div></div></div>';
  }).join('');

  // İşlemler
  const tl = document.getElementById('tx-history');
  const txs = currentUser.transactions || [];
  if (tl) tl.innerHTML = txs.length === 0 ? '<p style="color:#94A3B8;font-size:13px;">' + tr('noTx') + '</p>' : txs.slice(0, 15).map(t => '<div class="tx-row"><div><div class="tx-title">' + t.title + '</div><div class="tx-date">' + t.date + '</div></div><div class="tx-amt" style="color:' + (t.type === 'plus' ? '#10B981' : '#EF444') + ';">' + (t.type === 'plus' ? '+' : '-') + '$' + Number(t.amount).toLocaleString('en-US') + '</div></div>').join('');
}

/* ================= DÖVİZ ================= */
function updateFxRateInfo() {
  const from = document.getElementById('fx-from').value, to = document.getElementById('fx-to').value;
  const info = document.getElementById('fx-rate-info');
  if (!info) return;
  let rate = 1;
  const tFrom = from === 'TRY' ? 1 : fxRates[from], tTo = to === 'TRY' ? 1 : fxRates[to];
  rate = tFrom / tTo;
  info.innerHTML = '<b>1 ' + from + '</b> = <b>' + rate.toFixed(4) + ' ' + to + '</b><br><span style="color:#64748B;">1 USD = ' + fxRates.USD.toFixed(2) + ' ₺ · 1 EUR = ' + fxRates.EUR.toFixed(2) + ' ₺</span>';
}
async function submitFx() {
  if (!currentUser) return;
  const from = document.getElementById('fx-from').value, to = document.getElementById('fx-to').value;
  const amount = parseFloat(document.getElementById('fx-amount').value);
  if (from === to) return alert('Aynı para birimi seçilemez.');
  if (isNaN(amount) || amount <= 0) return alert('Geçerli bir tutar girin.');
  const r = await fetch('/api/fx-exchange', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, from, to, amount }) });
  const d = await r.json(); closeModal('fx-modal');
  if (!r.ok) return showBanner(d.error || 'Hata', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message, false);
}

/* ================= DİĞER İŞLEMLER ================= */
async function doDeposit() {
  const amount = document.getElementById('deposit-input-amount').value;
  if (!amount || parseFloat(amount) <= 0) return alert('Geçerli bir tutar girin.');
  const r = await fetch('/api/deposit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, amount: parseFloat(amount) }) });
  const d = await r.json(); closeModal('deposit-modal');
  if (!r.ok) return showBanner(d.error || 'Hata', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message, false);
}
async function doSendMoney() {
  if (!currentUser) return;
  const target = document.getElementById('send-target').value.trim();
  const amount = parseFloat(document.getElementById('send-amount').value);
  const note = document.getElementById('send-note').value.trim();
  if (!target) return alert('Alıcı girin.');
  if (isNaN(amount) || amount <= 0) return alert('Geçerli bir tutar girin.');
  const r = await fetch('/api/transfer', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, target, amount, note }) });
  const d = await r.json(); closeModal('send-money-modal');
  if (!r.ok) return showBanner(d.error || 'Hata', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message || 'Transfer başarılı!', false);
}
function openWithdrawModal() { toggleWithdrawFields(); openModal('withdraw-modal'); }
function toggleWithdrawFields() {
  const method = document.getElementById('withdraw-method').value;
  const isIban = (method === 'IBAN');
  document.getElementById('iban-fields-wrap').classList.toggle('hidden', !isIban);
  document.getElementById('direct-target-wrap').classList.toggle('hidden', isIban);
}
async function doWithdraw() {
  const method = document.getElementById('withdraw-method').value, amount = document.getElementById('withdraw-amount').value;
  let target = '', bankDetails = null;
  if (method === 'IBAN') {
    const bankName = document.getElementById('withdraw-bank-name').value.trim(), holderName = document.getElementById('withdraw-holder-name').value.trim(), iban = document.getElementById('withdraw-iban').value.trim(), swift = document.getElementById('withdraw-swift').value.trim();
    if (!bankName || !holderName || !iban || iban.length < 10) return alert('Geçerli banka, hesap sahibi ve IBAN girin.');
    target = 'IBAN: ' + iban + ' (' + bankName + ')'; bankDetails = { bankName, holderName, iban, swift };
  } else {
    target = document.getElementById('withdraw-address').value.trim();
    if (!target) return alert('Alıcı ID veya cüzdan adresi girin.');
  }
  if (!amount || amount <= 0) return alert('Geçerli tutar girin.');
  const r = await fetch('/api/withdraw', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ senderId: currentUser.id, method, target, bankDetails, amount: parseFloat(amount) }) });
  const d = await r.json(); closeModal('withdraw-modal');
  if (!r.ok) return showBanner(d.error, true);
  currentUser = d.user; updateDashboard(); showBanner(d.message, false);
}
async function submitBillPay() {
  const provider = document.getElementById('bill-provider').value, subNo = document.getElementById('bill-sub-no').value.trim(), amount = document.getElementById('bill-amount').value;
  if (!subNo) return alert('Abone no girin.');
  if (!amount || parseFloat(amount) <= 0) return alert('Geçerli tutar girin.');
  const r = await fetch('/api/pay-bill', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, provider, subscriberNo: subNo, amount: parseFloat(amount) }) });
  const d = await r.json(); closeModal('bill-modal');
  if (!r.ok) return showBanner(d.error || 'Hata', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message || 'Fatura ödendi!', false);
}
async function submitSwap() {
  const usd = document.getElementById('swap-usd-input').value, coin = document.getElementById('swap-coin-select').value;
  if (!usd || parseFloat(usd) <= 0) return alert('Geçerli tutar girin.');
  const r = await fetch('/api/swap', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, toCoin: coin, usdAmount: parseFloat(usd) }) });
  const d = await r.json(); closeModal('swap-modal');
  if (!r.ok) return showBanner(d.error || 'Hata', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message, false);
}
async function submitLoanRequest() {
  const amount = document.getElementById('loan-amount-input').value, months = document.getElementById('loan-months-select').value;
  if (!amount || parseFloat(amount) <= 0) return alert('Geçerli tutar girin.');
  const r = await fetch('/api/loan-request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, amount: parseFloat(amount), months }) });
  const d = await r.json(); closeModal('loan-modal');
  if (!r.ok) return showBanner(d.error || 'Hata', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message, false);
}
async function submitFreeCard() {
  if (!currentUser) return;
  const r = await fetch('/api/buy-card', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, brand: document.getElementById('cc-brand-select').value, free: true, cardType: 'VIRTUAL' }) });
  const d = await r.json();
  if (!r.ok) return showBanner(d.error || 'Hata', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message || 'Kart hazır!', false);
}
function readFileBase64(file) { return new Promise(res => { if (!file) return res(''); const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(file); }); }
async function submitKycForm() {
  const country = document.getElementById('kyc-country').value, docType = document.getElementById('kyc-doc-type').value, docNumber = document.getElementById('kyc-doc-num').value.trim(), birthDate = document.getElementById('kyc-birth').value;
  const f1 = document.getElementById('kyc-file-front'), f2 = document.getElementById('kyc-file-back');
  const fileFront = f1 && f1.files ? f1.files.item(0) : null, fileBack = f2 && f2.files ? f2.files.item(0) : null;
  if (!docNumber || docNumber.length < 6) return alert('Geçerli belge numarası girin.');
  if (!fileFront || !fileBack) return alert('Belgenin ön ve arka yüz fotoğrafını yükleyin.');
  const docImageFront = await readFileBase64(fileFront), docImageBack = await readFileBase64(fileBack);
  const r = await fetch('/api/kyc-submit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, docType, docNumber, birthDate, country, docImageFront, docImageBack }) });
  const d = await r.json(); closeModal('kyc-modal');
  if (!r.ok) return showBanner(d.error || 'Hata', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message, false);
}
function openKycModal() {
  const banner = document.getElementById('kyc-status-banner');
  if (banner) {
    const st = currentUser ? currentUser.kycStatus : 'UNVERIFIED';
    banner.innerText = (lang === 'ru' ? 'Статус: ' : lang === 'en' ? 'Status: ' : 'Durum: ') + (st === 'VERIFIED' ? '✓' : '—');
  }
  const sel = document.getElementById('kyc-country');
  if (sel && sel.options.length === 0) sel.innerHTML = ALL_COUNTRIES.map(c => '<option value="' + c + '"' + (c === 'Turkey' ? ' selected' : '') + '>' + c + '</option>').join('');
  openModal('kyc-modal');
}

/* ================= EVENT DELEGATION ================= */
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act], [data-lang]');
  if (!el) return;
  if (el.dataset.lang) { setLang(el.dataset.lang); return; }
  const act = el.dataset.act;
  const map = {
    'login': () => setAuthMode(false),
    'register': () => setAuthMode(true),
    'menu-open': () => toggleMenu(true),
    'menu-close': () => toggleMenu(false),
    'menu-dashboard': () => { toggleMenu(false); showMainView('dashboard'); },
    'menu-deposit': () => { toggleMenu(false); openModal('deposit-modal'); },
    'menu-withdraw': () => { toggleMenu(false); openWithdrawModal(); },
    'menu-fx': () => { toggleMenu(false); showMainView('dashboard'); openModal('fx-modal'); },
    'menu-swap': () => { toggleMenu(false); openModal('swap-modal'); },
    'menu-bills': () => { toggleMenu(false); openModal('bill-modal'); },
    'menu-card': () => { toggleMenu(false); showMainView('card'); },
    'menu-loan': () => { toggleMenu(false); openModal('loan-modal'); },
    'menu-kyc': () => { toggleMenu(false); openKycModal(); },
    'menu-lang': () => { toggleMenu(false); openModal('lang-modal'); },
    'menu-logout': () => logout(),
    'show-dashboard': () => showMainView('dashboard'),
    'copy-addr': () => copyAddress(),
    'copy-personal-iban': () => copyText(document.getElementById('dep-personal-iban').innerText),
    'dep-tab-crypto': () => { document.getElementById('dep-pane-crypto').classList.remove('hidden'); document.getElementById('dep-pane-personal').classList.add('hidden'); document.getElementById('dep-tab-crypto').classList.add('on'); document.getElementById('dep-tab-personal').classList.remove('on'); },
    'dep-tab-personal': () => { document.getElementById('dep-pane-personal').classList.remove('hidden'); document.getElementById('dep-pane-crypto').classList.add('hidden'); document.getElementById('dep-tab-personal').classList.add('on'); document.getElementById('dep-tab-crypto').classList.remove('on'); if (currentUser) fillPersonalDeposit(); },
    'submit-deposit': () => doDeposit(),
    'submit-send-money': () => doSendMoney(),
    'submit-withdraw': () => doWithdraw(),
    'submit-fx': () => submitFx(),
    'submit-bill': () => submitBillPay(),
    'submit-swap': () => submitSwap(),
    'submit-loan': () => submitLoanRequest(),
    'submit-kyc': () => submitKycForm(),
    'submit-card-free': () => submitFreeCard()
  };
  if (act.startsWith('close-')) { closeModal(act.slice(6) + '-modal'); return; }
  if (map[act]) map[act]();
});
document.addEventListener('submit', (e) => {
  if (e.target && e.target.id === 'auth-form') { e.preventDefault(); doAuth(); }
});
document.getElementById('send-otp-btn').addEventListener('click', sendOtpCode);
document.getElementById('head-lang-btn').addEventListener('click', () => openModal('lang-modal'));
document.getElementById('fx-from').addEventListener('change', updateFxRateInfo);
document.getElementById('fx-to').addEventListener('change', updateFxRateInfo);

/* ================= INIT ================= */
(async function init() {
  try { const r = await fetch('/api/fx-rates'); if (r.ok) fxRates = await r.json(); } catch (e) {}
  try { const r = await fetch('/api/public-settings'); if (r.ok) appSettings = { ...appSettings, ...(await r.json()) }; } catch (e) {}
  try { const r = await fetch('/api/prices'); if (r.ok) prices = await r.json(); } catch (e) {}
  const sel = document.getElementById('kyc-country');
  if (sel && sel.options.length === 0) sel.innerHTML = ALL_COUNTRIES.map(c => '<option value="' + c + '">' + c + '</option>').join('');
  setAuthMode(false);
  applyLang();
  // Oturum hatırla
  try {
    const saved = JSON.parse(localStorage.getItem('mp_user') || 'null');
    if (saved && saved.id) {
      const r = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: String(saved.id), password: saved.password, isRegister: false }) });
      if (r.ok) { const d = await r.json(); currentUser = d.user; appSettings = d.settings || appSettings; enterApp(); }
    }
  } catch (e) {}
})();
