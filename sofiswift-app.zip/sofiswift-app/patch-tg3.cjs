const fs = require('fs');
let d = fs.readFileSync('public/admin.html', 'utf8');

// HTML: telegram after wa-toggle before SMTP (multi-line tolerant match)
const re1 = /(<button type="button" id="wa-toggle-btn"[^>]*>🟢 AÇIK<\/button>\s*<h3[^>]*>)✉️ SMTP \/ SMS/;
if (!re1.test(d)) { console.log('T1 FAIL'); process.exit(1); }
d = d.replace(re1, `$1📨 Telegram Bildirimleri</h3>
            <label class="fl">Bot Token (BotFather'dan)</label><input type="text" id="set-tg-token" class="input" style="margin-top:0;" placeholder="123456:ABC-DEF..." />
            <label class="fl">Chat ID</label><input type="text" id="set-tg-chat" class="input" style="margin-top:0;" placeholder="örn: 123456789" />
            <button type="button" class="btn-sm btn-blue" style="margin-top:8px;" onclick="testTelegram()">📨 Test Mesajı Gönder</button> <span id="tg-test-result" style="font-size:12px;font-weight:800;"></span>
            <h3 style="margin-top:16px;">✉️ SMTP / SMS`);

// bump admin.js cache version
d = d.replace(/admin\.js\?v=\d+/, 'admin.js?v=2000');

fs.writeFileSync('public/admin.html', d);
console.log('admin.html TG panel + cache bump OK');
