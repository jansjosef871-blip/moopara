const fs = require('fs');
const t = fs.readFileSync('C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/index.html', 'utf8');
console.log('index len:', t.length);
console.log('has submit-auth data-act:', t.includes('data-act="submit-auth"'));
console.log('has close-deposit-modal:', t.includes('close-deposit-modal'));
console.log('has personal iban row:', t.includes('personalIban') || t.includes('Kişisel IBAN'));
console.log('has api section:', t.includes('API'));
console.log('drawer menu items:', (t.match(/data-act="menu-/g) || []).length);
