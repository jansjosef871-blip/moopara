export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/yonetim-atmaca-2026', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2500);
  out.url = await page.evaluate(() => location.pathname);
  out.hasLogin = await page.evaluate(() => !!document.getElementById('loginDiv'));
  await page.evaluate(() => {
    document.getElementById('u').value = 'atmaca';
    document.getElementById('p').value = 'admin2026!';
    return giris();
  });
  await page.waitForTimeout(2000);
  await page.evaluate(() => sekme('settings'));
  await page.waitForTimeout(400);
  out.adminTg = await page.evaluate(() => ({
    tokenField: !!document.getElementById('sTgToken'),
    chatField: !!document.getElementById('sTgChat'),
    testBtn: !!document.querySelector('button[onclick="testTelegram()"]'),
    holderField: !!document.getElementById('sHolder'),
    panelHead: (document.getElementById('icerik') || {}).innerText?.slice(0, 80)
  }));
  await page.screenshot({ path: 'admin-settings.png' });
  return out;
}
