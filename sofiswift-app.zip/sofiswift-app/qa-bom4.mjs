export default async function run(page, ui) {
  return await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=bomtest4')).text();
    try {
      (0, eval)(t);
      return 'full eval ok, setAuth=' + typeof window.setAuthMode;
    } catch (e) { return 'ERR: ' + e.message + ' stack: ' + (e.stack || '').slice(0, 500); }
  });
}
