# moopara — Cloudflare Tunnel + Namecheap ile Canlıya Alma

Bu yöntemle **VPS gerekmez** — uygulama kendi bilgisayarında çalışır, Cloudflare Tunnel
internetten erişilebilir hale getirir. Ücretsiz SSL dahil.

## Ön koşullar
- ✅ `cloudflared.exe` indirildi: `%USERPROFILE%\cloudflared.exe` (v2026.11.1)
- ✅ Uygulama pm2 ile çalışıyor: `pm2 start ecosystem.config.js` → localhost:3000
- Namecheap'te satın alınmış domain

## Adım 1 — Namecheap domain'ini Cloudflare'a ekle
1. https://dash.cloudflare.com → **Add a site** → domainini gir (örn. `moopara.com`)
2. Free plan seç
3. Cloudflare sana **2 nameserver** verir, örnek:
   - `bob.ns.cloudflare.com`
   - `lucy.ns.cloudflare.com`

## Adım 2 — Namecheap'te nameserver'ları değiştir
1. Namecheap → Domain List → domainin → **Nameservers** bölümü
2. **CustomDNS** seç → Cloudflare'ın verdiği 2 nameserver'ı yaz → kaydet
3. DNS yayılımı 5 dakika – 24 saat arası sürer (genelde 15 dk)
4. Cloudflare dashboard'da site "Active" olunca devam et

## Adım 3 — cloudflared login
```powershell
& "$env:USERPROFILE\cloudflared.exe" tunnel login
```
→ Tarayıcı açılır, Cloudflare'da domainini seç ve yetki ver.
→ `%USERPROFILE%\.cloudflared\cert.pem` oluşur.

## Adım 4 — Tunnel oluştur
```powershell
& "$env:USERPROFILE\cloudflared.exe" tunnel create mopara
```
→ Tunnel UUID + `%USERPROFILE%\.cloudflared\<UUID>.json` kimlik dosyası oluşur.

## Adım 5 — Domain'i tunnel'a yönlendir
```powershell
& "$env:USERPROFILE\cloudflared.exe" tunnel route dns mopara senindomain.com
& "$env:USERPROFILE\cloudflared.exe" tunnel route dns mopara www.senindomain.com
```
→ Cloudflare DNS'te otomatik CNAME oluşur (`<UUID>.cfargotunnel.com`).

## Adım 6 — Tunnel config dosyası
`%USERPROFILE%\.cloudflared\config.yml`:
```yaml
tunnel: <UUID>
credentials-file: C:\Users\<kullanıcı>\.cloudflared\<UUID>.json

ingress:
  - hostname: senindomain.com
    service: http://localhost:3000
  - hostname: www.senindomain.com
    service: http://localhost:3000
  - service: http_status:404
```

## Adım 7 — Tunnel'ı servis olarak başlat (reboot'ta otomatik)
```powershell
& "$env:USERPROFILE\cloudflared.exe" service install
& "$env:USERPROFILE\cloudflared.exe" service start
```
ya da test için tek seferlik:
```powershell
& "$env:USERPROFILE\cloudflared.exe" tunnel run mopara
```

## Adım 8 — Doğrula
```powershell
curl https://senindomain.com
```
Tarayıcıda `https://senindomain.com` → moopara açılmalı. SSL Cloudflare'dan otomatik.

## Önemli notlar
- **pm2 ve cloudflared service** her ikisi de bilgisayar açılışında otomatik başlar;
  uygulaman 7/24 açık kalması için bilgisayarın uyku moduna geçmemeli.
- Cloudflare dashboard → SSL/TLS modu: **Full** (tunnel bunu kendi halleder).
- Cloudflare dashboard → Speed → Optimization: Brotli + Auto Minify açılabilir.
- SmsEdge anahtarı veritabanında hazır; admin panelinden (`/admin`, kullanıcı: `atmaca`) yönetilir.
- **Güvenlik:** `server.js` içindeki `SUPER_ADMIN_PASS` değerini canlıya çıkmadan önce değiştir!
