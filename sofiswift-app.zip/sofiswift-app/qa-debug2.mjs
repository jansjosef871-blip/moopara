export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 300)));
  await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(2000);
  const r = {};
  const em = 'dbg' + Date.now() + '@mail.com';

  await page.click('#tab-register');
  await page.waitForTimeout(600);
  r.nameFieldState = await page.evaluate(() => ({
    cls: document.getElementById('name-field').className,
    display: getComputedStyle(document.getElementById('name-field')).display,
    inputExists: !!document.getElementById('auth-name'),
    title: document.getElementById('auth-title').innerText
  }));
  await page.evaluate(([e]) => {
    const f = document.getElementById('auth-form'); if (f) f.noValidate = true;
    document.getElementById('auth-name').value = 'Debug Test';
    document.getElementById('auth-email').value = e;
    document.getElementById('auth-pass').value = '123456';
  }, [em]);
  const rp = page.waitForResponse(x => x.url().includes('/api/auth'), { timeout: 15000 }).catch(() => null);
  await page.evaluate(() => document.getElementById('auth-btn-text').click());
  const resp = await rp;
  r.registerStatus = resp ? resp.status() : 'none';
  r.registerBody = resp ? await resp.text().then(t => t.slice(0, 200)) : null;
  await page.waitForTimeout(1500);
  r.authHidden = await page.evaluate(() => document.getElementById('auth-section').classList.contains('hidden'));
  r.dashboardShown = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));
  r.errText = await page.evaluate(() => document.getElementById('auth-error')?.innerText || '');
  r.errors = errors;
  return r;
}
