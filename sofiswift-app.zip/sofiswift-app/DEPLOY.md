# moopara — Canlıya Alma (Deployment)

## 1. Yerel doğrulama (tamamlandı)
- ✅ Server çalışıyor: `node server.js` → http://localhost:3000
- ✅ SmsEdge gerçek SMS gönderimi test edildi (mesaj id: 136682519, "sent": true)
- ✅ Havuz IBAN + QR deposit modalında görünüyor
- ✅ OTP artık gerçek — demo kod yalnızca SMS anahtarı yoksa gösteriliyor

## 2. Sunucuda kurulum (domain'li VPS)

### a) Node + pm2 kur
```bash
npm install -g pm2
```

### b) Projeyi sunucuya kopyala
```bash
# yerelden:
scp -r . user@sunucu:/var/www/moopara
# ya da git ile
```

### c) Bağımlılıkları kur ve pm2 ile başlat
```bash
cd /var/www/moopara
npm install --omit=dev
pm2 start ecosystem.config.js
pm2 save
pm2 startup   # sunucu reboot'ta otomatik başlar
```

### d) Nginx reverse proxy (domain'e bağla)
`/etc/nginx/sites-available/moopara`:
```nginx
server {
    listen 80;
    server_name senindomainin.com www.senindomainin.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_cache_bypass $http_upgrade;
    }
}
```
```bash
ln -s /etc/nginx/sites-available/moopara /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

### e) HTTPS (ücretsiz Let's Encrypt)
```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d senindomainin.com -d www.senindomainin.com
```

## 3. DNS
Domain panelinde A kaydı: `@` ve `www` → sunucu IP'si.

## 4. SmsEdge anahtarı
Yönetici panelinde (`/admin` → kullanıcı: atmaca) "SmsEdge API Key" alanına anahtarı gir.
Test'te doğrulandı: `https://api.smsedge.com/v1/sms/send?api_key=...`

## 5. Güvenlik notları
- SUPER_ADMIN şifresini (`server.js` içindeki `SUPER_ADMIN_PASS`) canlıya çıkmadan önce değiştir.
- `database.json` dosyasını sunucuda yedekle (cron: `cp database.json backup/$(date +%F).json`).
