export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(2000);
  // PWA button state on auth screen
  out.pwa = await page.evaluate(() => {
    const btn = document.getElementById('pwa-install-btn');
    const row = document.getElementById('pwa-install-row');
    return { rowExists: !!row, btnExists: !!btn, btnVisible: btn ? getComputedStyle(btn).display !== 'none' : false, rowText: row ? row.innerText.slice(0, 80) : null };
  });
  // Admin panel — login & settings tab
  await page.goto('http://localhost:3000/admin.html?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(1200);
  await page.fill('#u', 'atmaca');
  await page.fill('#p', 'admin2026!');
  await page.click('button[onclick="giris()"]');
  await page.waitForTimeout(1500);
  await page.evaluate(() => sekme('settings'));
  await page.waitForTimeout(500);
  out.adminTg = await page.evaluate(() => ({
    tokenField: !!document.getElementById('sTgToken'),
    chatField: !!document.getElementById('sTgChat'),
    testBtn: !!document.querySelector('button[onclick="testTelegram()"]'),
    panelText: document.getElementById('icerik').innerText.slice(0, 120)
  }));
  await page.screenshot({ path: 'admin-settings.png' });
  return out;
}
