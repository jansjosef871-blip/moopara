export default async function run(page, ui) {
  // Setup error trap FIRST, before any script runs
  await page.addInitScript(() => {
    window.__errs = [];
    window.addEventListener('error', e => window.__errs.push(String(e.message) + ' @line ' + e.lineno));
    window.addEventListener('unhandledrejection', e => window.__errs.push('REJ: ' + String(e.reason).slice(0, 200)));
  });
  await page.goto('http://localhost:3000', { waitUntil: 'load' });
  await page.waitForTimeout(2000);
  return await page.evaluate(() => ({ errs: window.__errs, setAuth: typeof window.setAuthMode }));
}
