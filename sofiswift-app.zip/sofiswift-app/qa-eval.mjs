export default async function run(page, ui) {
  const res = {};
  res.err = await page.evaluate(async () => {
    try {
      const r = await fetch('/app.js');
      const t = await r.text();
      window.eval(t);
      return 'evaled, setAuthMode=' + typeof window.setAuthMode;
    } catch (e) { return 'ERR: ' + e.message + ' | ' + (e.stack || '').slice(0, 300); }
  });
  return res;
}
