const fs = require('fs');
let d = fs.readFileSync('public/app.js', 'utf8');
// Make top-level state attach to window so external tools/harnesses and delegation always see them
const old1 = "let currentUser = null, isRegisterMode = false;\nlet appSettings = { cardPrice: 20, depositAddress: 'TX9aK8pL2mQ7vR4wN1zB6cJ3yH5fD8sG0e' };";
if (!d.includes(old1)) { console.log('DECL NOT FOUND'); process.exit(1); }
const new1 = "var currentUser = null, isRegisterMode = false;\nvar appSettings = { cardPrice: 20, depositAddress: 'TX9aK8pL2mQ7vR4wN1zB6cJ3yH5fD8sG0e' };";
d = d.replace(old1, new1);
// keep prices global too if let
d = d.replace('let prices = {', 'var prices = {');
fs.writeFileSync('public/app.js', d);
console.log('var-ified');
