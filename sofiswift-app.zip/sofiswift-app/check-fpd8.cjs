const d = require('fs').readFileSync('public/app.js', 'utf8');
const i = d.indexOf('function fillPersonalDeposit');
console.log(JSON.stringify(d.slice(i - 120, i + 750)));
