export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(2200);
  // Single evaluate: eval app.js AND use its scope in the SAME eval call
  out.dep = await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=' + Math.random(), { cache: 'no-store' })).text();
    (0, eval)(t);
    currentUser = { id: 2649012573, name: 'IBAN QA', personalIban: 'TR64 0001 0019 5900 2635 57', kycStatus: 'VERIFIED', hasCard: true, assets: { USDT: 10 }, transactions: [] };
    appSettings.officialBankIban = 'TR64 0001 0019 4952 1717 25';
    appSettings.officialBankName = 'ziraat bank';
    openModal('deposit-modal');
    document.querySelector('[data-act="dep-tab-personal"]').click();
    return {
      ibanShown: document.getElementById('dep-personal-iban').innerText,
      holder: document.getElementById('dep-personal-holder').innerText,
      bank: document.getElementById('dep-personal-bank').innerText,
      hasQr: !!document.querySelector('#dep-personal-qr img')
    };
  });
  await page.waitForTimeout(800);
  await page.screenshot({ path: 'iban-final.png' });
  return out;
}
