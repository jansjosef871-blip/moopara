export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 300)));
  await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(2500);
  const r = {};
  const em = 'papara' + Date.now() + '@mail.com';

  // Register
  await page.click('#tab-register');
  await page.waitForTimeout(500);
  await page.evaluate(([e]) => {
    const f = document.getElementById('auth-form'); if (f) f.noValidate = true;
    document.getElementById('auth-name').value = 'Papara Test';
    document.getElementById('auth-email').value = e;
    document.getElementById('auth-pass').value = '123456';
  }, [em]);
  const rp = page.waitForResponse(x => x.url().includes('/api/auth'), { timeout: 15000 }).catch(() => null);
  await page.evaluate(() => document.getElementById('auth-btn-text').click());
  const resp = await rp;
  r.regStatus = resp ? resp.status() : 'none';
  r.regBody = resp ? await resp.text().then(t => t.slice(0, 150)) : null;
  await page.waitForTimeout(2000);
  r.dashboard = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));

  // Deposit modal + 3 tabs
  await page.evaluate(() => document.getElementById('menu-open-btn').click());
  await page.waitForTimeout(500);
  r.drawerOpen = await page.evaluate(() => !document.getElementById('side-drawer').classList.contains('closed'));
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-deposit"]').click());
  await page.waitForTimeout(500);
  r.depositOpen = await page.evaluate(() => !document.getElementById('deposit-modal').classList.contains('hidden'));
  // personal tab
  await page.evaluate(() => document.querySelector('[data-act="dep-tab-personal"]').click());
  await page.waitForTimeout(400);
  r.personalTabShown = await page.evaluate(() => {
    const p = document.getElementById('dep-pane-personal');
    return !p.classList.contains('hidden') && p.style.display !== 'none';
  });
  r.personalIbanFilled = await page.evaluate(() => document.getElementById('dep-personal-iban')?.innerText.slice(0, 20));
  // crypto tab back
  await page.evaluate(() => document.querySelector('[data-act="dep-tab-crypto"]').click());
  await page.waitForTimeout(300);
  r.cryptoBack = await page.evaluate(() => !document.getElementById('dep-pane-crypto').classList.contains('hidden'));
  // close deposit via ✕
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]').click());
  await page.waitForTimeout(300);
  r.depositClosed = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));

  // API view via drawer
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-api"]').click());
  await page.waitForTimeout(500);
  r.apiViewShown = await page.evaluate(() => !document.getElementById('api-integration-view').classList.contains('hidden'));
  await page.evaluate(() => document.querySelector('[data-act="generate-api-key"]').click());
  await page.waitForTimeout(300);
  r.apiKeyGenerated = await page.evaluate(() => document.getElementById('api-key-box')?.innerText.slice(0, 20));
  await page.evaluate(() => document.querySelector('#api-integration-view [data-act="show-dashboard"]').click());
  await page.waitForTimeout(300);
  r.backToDash = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));

  // Card control view
  await page.evaluate(() => document.querySelector('#user-dashboard [data-act="menu-card"], #side-drawer [data-act="menu-card"]').click());
  await page.waitForTimeout(400);
  r.cardView = await page.evaluate(() => !document.getElementById('card-control-view').classList.contains('hidden'));
  r.ccPill = await page.evaluate(() => document.getElementById('cc-status-pill')?.innerText);

  await page.screenshot({ path: 'papara-check.png' });
  r.errors = errors;
  return r;
}
