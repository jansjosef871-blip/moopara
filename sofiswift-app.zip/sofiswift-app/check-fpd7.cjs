const d = require('fs').readFileSync('public/app.js', 'utf8');
// check: does fillPersonalDeposit exist in the served portion, but ALSO check 'US64 SOFI' vs real prefix. User IBAN starts 'TR64' so isCustomIban = true -> uses currentUser.personalIban. That's fine.
// Problem in test: fillPersonalDeposit threw "Cannot read personalIban of null" meaning currentUser was null AT THAT POINT in the eval'd scope.
// In page.evaluate(() => currentUser = d2.user) — this sets the eval-context binding? With indirect eval top-level let stays in eval's own scope? Actually indirect eval runs in global scope but let/const create bindings in a new "declarative environment" per eval! That's the issue — `let currentUser` in indirect eval is NOT accessible across separate eval calls.
// Confirm: functions declared with function statement in indirect eval DO attach to global... they do attach. But `let currentUser` doesn't — it lives in that eval's environment, and the function closes over THAT, while the test's separate evaluate has its own scope.
// So the app itself is FINE in a real browser (single script tag = one global lexical scope). The test harness is the limitation.
console.log('Analysis: test-harness artifact. app.js is fine.');
// verify fillPersonalDeposit robustness anyway: guard currentUser null
console.log('guard present:', d.includes('function fillPersonalDeposit() {\n  if (!currentUser)'));
