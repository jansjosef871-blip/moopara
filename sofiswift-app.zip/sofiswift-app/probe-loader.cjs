const fs = require('fs');
let d = fs.readFileSync('public/admin.html', 'utf8');

// 1) HTML: telegram panel after wa-toggle, before SMTP
const old1 = `<button type="button" id="wa-toggle-btn" class="btn-sm btn-green" style="margin-top:8px;" onclick="toggleWaStatus()">🟢 AÇIK</button>
            <h3 style="margin-top:16px;">✉️ SMTP / SMS</h3>`;
const new1 = `<button type="button" id="wa-toggle-btn" class="btn-sm btn-green" style="margin-top:8px;" onclick="toggleWaStatus()">🟢 AÇIK</button>
            <h3 style="margin-top:16px;">📨 Telegram Bildirimleri</h3>
            <label class="fl">Bot Token (BotFather'dan)</label><input type="text" id="set-tg-token" class="input" style="margin-top:0;" placeholder="123456:ABC-DEF..." />
            <label class="fl">Chat ID</label><input type="text" id="set-tg-chat" class="input" style="margin-top:0;" placeholder="örn: 123456789" />
            <button type="button" class="btn-sm btn-blue" style="margin-top:8px;" onclick="testTelegram()">📨 Test Mesajı Gönder</button> <span id="tg-test-result" style="font-size:12px;font-weight:800;"></span>
            <h3 style="margin-top:16px;">✉️ SMTP / SMS</h3>`;
if (!d.includes(old1)) { console.log('T1 FAIL'); process.exit(1); }
d = d.replace(old1, new1);

// 2) JS: how are settings fields populated? Find the settings loader
const m2 = d.match(/set-bank-name['"]\)?[^;]{0,120};/);
console.log('bank fill sample:', m2 && m2[0]);
const i2 = d.indexOf("set-bank-name");
console.log(JSON.stringify(d.slice(i2 - 400, i2 + 200)));
