const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');
const bad = "POS'larda kullanılabilir.";
const good = "POS ve ATM'lerde kullanılabilir.";
if (t.includes(bad)) { t = t.replace(bad, good); fs.writeFileSync(p, t); console.log('apostrophe FIXED'); }
else console.log('pattern check:', t.includes('POS'));
