const d = require('fs').readFileSync('served-admin.html', 'utf8');
// How does the JS fill settings? Look for 's.settings' or a fetch that maps to fields
const patterns = ['settings', 'saveSystemSettings', 'adminGenerateApiKey'];
for (const p of patterns) {
  let i = d.indexOf(p, d.indexOf('<script'));
  console.log('---', p, '@', i, '---');
  if (i > -1) console.log(JSON.stringify(d.slice(i - 200, i + 500)).slice(0, 800));
}
