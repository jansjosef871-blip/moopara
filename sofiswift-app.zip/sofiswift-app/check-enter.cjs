const d = require('fs').readFileSync('public/app.js', 'utf8');
const lines = d.split('\n');
const idx = lines.findIndex(l => l.includes('function enterApp'));
console.log(lines.slice(idx, idx + 12).map((l, i) => (idx + i + 1) + ': ' + l).join('\n'));
