export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 300)));
  const authBodies = [];
  await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(2500);
  const r = {};
  const em = 'flow' + Date.now() + '@mail.com';

  page.on('response', async res => {
    if (res.url().includes('/api/auth')) authBodies.push({ status: res.status(), body: (await res.text().catch(() => '')).slice(0, 150) });
  });

  // STEP 1: click register tab and CHECK UI STATE
  await page.evaluate(() => document.getElementById('tab-register').click());
  await page.waitForTimeout(800);
  r.step1 = await page.evaluate(() => ({
    nameShown: !document.getElementById('name-field').classList.contains('hidden'),
    nameVisible: getComputedStyle(document.getElementById('name-field')).display,
    btnText: document.getElementById('auth-btn-text').innerText,
    formExists: !!document.getElementById('auth-form')
  }));
  return { r, authBodies, errors };
}
