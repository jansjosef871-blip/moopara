$dst = 'C:\Users\baran\OneDrive\Desktop\sofiswift-app\public\app.js'
$d = [System.IO.File]::ReadAllText($dst)

# Patch the coin list rendering to add data-val attribute
$old = 'return ' + "'" + '<div class="list-item">'
$new = 'return ' + "'" + '<div class="list-item"'' + (qty > 0 ? ' + "'" + ' data-val="1"' + "'" + ' : ' + "'" + ''" + "'" + ') + ' + "'" + '>'
$i = $d.IndexOf($old)
Write-Output ("pattern idx: " + $i)
if ($i -gt 0) {
  $d = $d.Replace($old, $new)
  [System.IO.File]::WriteAllText($dst, $d)
  Write-Output 'GREEN ROW PATCHED'
} else {
  # show actual context
  $j = $d.IndexOf('list-item')
  Write-Output $d.Substring($j - 40, 120)
}
