export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push('PE: ' + String(e).slice(0, 250)));
  await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(4500);
  const r = {};
  const em = 'pro' + Date.now() + '@mail.com';

  // REGISTER — now with personal IBAN/TRC20 from server
  await page.evaluate(() => document.getElementById('tab-register').click());
  await page.waitForTimeout(600);
  await page.evaluate(([e]) => {
    const f = document.getElementById('auth-form'); if (f) f.noValidate = true;
    document.getElementById('auth-name').value = 'Pro Final';
    document.getElementById('auth-email').value = e;
    document.getElementById('auth-pass').value = '123456';
  }, [em]);
  await page.evaluate(() => document.getElementById('auth-btn-text').click());
  await page.waitForTimeout(2500);
  r.dashboard = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));

  // DEPOSIT → PERSONAL TAB (user-specific IBAN + TRC20)
  await page.evaluate(() => document.getElementById('menu-open-btn').click());
  await page.waitForTimeout(500);
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-deposit"]').click());
  await page.waitForTimeout(600);
  r.depositOpen = await page.evaluate(() => !document.getElementById('deposit-modal').classList.contains('hidden'));
  r.modalFits = await page.evaluate(() => document.querySelector('#deposit-modal .modal-box').getBoundingClientRect().height <= window.innerHeight);
  await page.evaluate(() => document.querySelector('[data-act="dep-tab-personal"]').click());
  await page.waitForTimeout(400);
  r.personalTab = await page.evaluate(() => !document.getElementById('dep-pane-personal').classList.contains('hidden'));
  r.personalIban = await page.evaluate(() => document.getElementById('dep-personal-iban').innerText.slice(0, 30));
  r.isPersonalIban = await page.evaluate(() => document.getElementById('dep-personal-iban').innerText.startsWith('US64'));
  r.personalTrc = await page.evaluate(() => (document.getElementById('dep-personal-trc').innerText || '').slice(0, 10));
  await page.screenshot({ path: 'personal-iban.png' });

  // CLOSE via X
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]').click());
  await page.waitForTimeout(500);
  r.depositClosed = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));

  // WITHDRAW open/close
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-withdraw"]').click());
  await page.waitForTimeout(500);
  r.withdrawOpen = await page.evaluate(() => !document.getElementById('withdraw-modal').classList.contains('hidden'));
  await page.evaluate(() => document.querySelector('[data-act="close-withdraw-modal"]').click());
  await page.waitForTimeout(500);
  r.withdrawClosed = await page.evaluate(() => document.getElementById('withdraw-modal').classList.contains('hidden'));

  // ESC + overlay close
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-bills"]').click());
  await page.waitForTimeout(400);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  r.billEscClosed = await page.evaluate(() => document.getElementById('bill-modal').classList.contains('hidden'));

  // FREE VIRTUAL CARD
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-card"]').click());
  await page.waitForTimeout(500);
  r.cardView = await page.evaluate(() => !document.getElementById('card-control-view').classList.contains('hidden'));
  r.freeBanner = await page.evaluate(() => document.getElementById('cc-free-banner')?.style.display);
  await page.evaluate(() => document.querySelector('#cc-type-physical').click());
  await page.waitForTimeout(400);
  r.physicalSelected = await page.evaluate(() => document.getElementById('cc-free-banner').style.display === 'none');
  await page.evaluate(() => document.querySelector('#cc-type-virtual').click());
  await page.waitForTimeout(400);
  // Ücretsiz kart oluştur
  await page.evaluate(() => document.querySelector('#cc-payment-details [data-act="submit-card-order"]').click());
  await page.waitForTimeout(2500);
  r.freeCardCreated = await page.evaluate(() => currentUser && currentUser.hasCard);
  r.cardNumber = await page.evaluate(() => currentUser ? (currentUser.cardNumber || '').slice(0, 6) : null);
  await page.evaluate(() => updateDashboard());
  r.ccPill = await page.evaluate(() => document.getElementById('cc-status-pill')?.innerText);

  // API title + drawer only
  await page.evaluate(() => document.querySelector('#card-control-view [data-act="show-dashboard"]').click());
  await page.waitForTimeout(400);
  r.dashApiBtnGone = await page.evaluate(() => !document.querySelector('#user-dashboard [data-act="menu-api"]'));
  await page.evaluate(() => document.getElementById('menu-open-btn').click());
  await page.waitForTimeout(500);
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-api"]').click());
  await page.waitForTimeout(500);
  r.apiTitle = await page.evaluate(() => document.querySelector('#api-integration-view h3').innerText);
  r.apiStatus = await page.evaluate(() => document.getElementById('api-status-box')?.innerText.slice(0, 40));
  await page.evaluate(() => document.querySelector('[data-act="drawer-close"]').click());
  await page.waitForTimeout(300);
  await page.screenshot({ path: 'pro-final.png' });
  r.errors = errors;
  return r;
}
