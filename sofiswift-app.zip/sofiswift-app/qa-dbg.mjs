export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push('PE: ' + String(e).slice(0, 250)));
  await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(4500);
  const r = {};
  const em = 'dbg' + Date.now() + '@mail.com';

  await page.evaluate(() => document.getElementById('tab-register').click());
  await page.waitForTimeout(600);
  const resp = await page.evaluate(async (e) => {
    const f = document.getElementById('auth-form'); if (f) f.noValidate = true;
    document.getElementById('auth-name').value = 'Dbg Pro';
    document.getElementById('auth-email').value = e;
    document.getElementById('auth-pass').value = '123456';
    const rr = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'Dbg Pro', email: e, password: '123456', isRegister: true }) });
    const d = await rr.json();
    if (!rr.ok) return { status: rr.status, error: d.error };
    try { currentUser = d.user; appSettings = d.settings || appSettings; prices = d.prices || prices; enterApp(); } catch (e2) { return { status: rr.status, enterErr: e2.message }; }
    return { status: rr.status, iban: d.user.personalIban, trc: (d.user.personalTrc20 || '').slice(0, 10) };
  }, em);
  r.reg = resp;
  await page.waitForTimeout(1000);
  r.dashboard = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));
  r.errors = errors;
  return r;
}
