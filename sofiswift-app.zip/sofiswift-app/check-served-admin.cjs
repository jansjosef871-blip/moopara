require('http').get('http://127.0.0.1:3000/yonetim-atmaca-2026', r => {
  let d = '';
  r.on('data', c => d += c);
  r.on('end', () => {
    console.log('len:', d.length);
    console.log('hasTg:', d.includes('Telegram'));
    console.log('hasSEO:', d.includes('SEO'));
    console.log('hasLogo:', d.includes('logo'));
    const fs = require('fs');
    fs.writeFileSync('served-admin.html', d);
    console.log('saved to served-admin.html');
  });
});
