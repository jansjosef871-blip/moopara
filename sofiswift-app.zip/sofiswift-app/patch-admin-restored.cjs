const fs = require('fs');
let d = fs.readFileSync('public/admin.html', 'utf8');

// 1) API create/delete helpers (after corpRegen)
const anchor1 = `    function sekme(s) {`;
const helpers1 = `    async function apiCreate() {
      const name = document.getElementById('nc-name').value.trim();
      const url = document.getElementById('nc-url').value.trim();
      const mail = document.getElementById('nc-mail').value.trim();
      if (!name || !url) return alert('Site adı ve URL zorunlu!');
      const r = await fetch('/api/admin-panel-action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'api-create', siteName: name, siteUrl: url, contactEmail: mail }) });
      const d = await r.json();
      if (!r.ok) return alert(d.error || 'Hata');
      document.getElementById('nc-result').innerHTML = '<div style="background:#052e16;border:1px solid #10b981;padding:12px;border-radius:10px;">✅ <b>' + name + '</b> için anahtar hazır:<br><code id="nc-key" style="color:#fbbf24;font-size:13px;word-break:break-all;">' + d.apiKey + '</code> <button style="background:#0284C7;padding:5px 10px;" onclick="kopyalaKey(\\'' + d.apiKey + '\\')">📋 Kopyala</button></div>';
      yukle();
    }
    async function apiDel(id) {
      if (!confirm('Bu API anahtarı kalıcı olarak silinecek! Emin misiniz?')) return;
      await fetch('/api/admin-panel-action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'api-delete', corpId: id }) });
      yukle();
    }
    async function testTelegram() {
      const token = document.getElementById('sTgToken').value.trim();
      const chat = document.getElementById('sTgChat').value.trim();
      await fetch('/api/admin-panel-action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'settings', settings: { telegramBotToken: token, telegramChatId: chat } }) });
      const r = await fetch('/api/admin-telegram-test', { method: 'POST' });
      const d = await r.json();
      document.getElementById('tgTestResult').innerHTML = d.ok ? '<b style="color:#34D399;">✅ Gönderildi! Telegramınıza bakın.</b>' : '<b style="color:#F87171;">❌ ' + (d.error || 'Gönderilemedi') + '</b>';
    }
    function sekme(s) {`;
if (!d.includes(anchor1)) { console.log('A1 FAIL'); process.exit(1); }
d = d.replace(anchor1, helpers1);

// 2) corp tab: add create panel + delete btn. Find the corp innerHTML assignment
const anchor2 = `      } else if (s === 'corp') {
        const corps = veri.corporateMembers || [];
        alan.innerHTML = '<h3>Kurumsal Üyeler & API Anahtarları (' + corps.length + ')</h3>' +`;
const newCorp = `      } else if (s === 'corp') {
        const corps = veri.corporateMembers || [];
        alan.innerHTML = '<div style="background:#312e81;border-radius:12px;padding:16px;margin-bottom:16px;">' +
          '<h3 style="margin:0 0 10px;">➕ Yeni Site/API Anahtarı Oluştur</h3>' +
          '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;">' +
          '<input id="nc-name" placeholder="Site / Firma Adı (örn: ShopA)">' +
          '<input id="nc-url" placeholder="https://shopA.com" />' +
          '<input id="nc-mail" placeholder="İletişim e-posta (opsiyonel)" />' +
          '</div><button style="margin-top:10px;background:#10b981;padding:10px 22px;" onclick="apiCreate()">🔑 API Anahtarı Oluştur</button>' +
          '<div id="nc-result" style="margin-top:10px;"></div></div>' +
          '<h3>Kurumsal Üyeler & API Anahtarları (' + corps.length + ')</h3>' +`;
if (!d.includes(anchor2)) { console.log('A2 FAIL'); process.exit(1); }
d = d.replace(anchor2, newCorp);

// 3) settings tab: telegram panel
const anchor3 = `      } else if (s === 'settings') {`;
const idx3 = d.indexOf(anchor3);
const end3 = d.indexOf('      }\n    }', idx3);
if (idx3 === -1 || end3 === -1) { console.log('A3 LOCATE FAIL', idx3, end3); process.exit(1); }
const newSettings = `      } else if (s === 'settings') {
        alan.innerHTML = '<h3>Ayarlar</h3>' +
          '<div style="background:#1e3a5f;border:1px solid #2563eb;border-radius:12px;padding:14px;margin-bottom:14px;">' +
          '<b style="color:#60a5fa;">📨 Telegram Bildirimleri</b> <small style="color:#94A3B8;">— kayıt / para yatırma / çekim olaylarında anında mesaj</small>' +
          '<p style="margin:8px 0 4px;font-size:12px;">Bot Token (BotFather&apos;dan):</p><input id="sTgToken" value="' + (set.telegramBotToken || '') + '" placeholder="123456:ABC-DEF..." />' +
          '<p style="margin:8px 0 4px;font-size:12px;">Chat ID (admin kendi ID&apos;niz veya grup ID&apos;si):</p><input id="sTgChat" value="' + (set.telegramChatId || '') + '" placeholder="örn: 123456789 veya -1001234..." />' +
          '<button style="margin-top:8px;background:#2563eb;" onclick="testTelegram()">📨 Test Mesajı Gönder</button> <span id="tgTestResult"></span></div>' +
          '<p>Resmi TR IBAN:</p><input id="sIban" value="' + (set.officialBankIban || '') + '"><p>Banka Adı:</p><input id="sBank" value="' + (set.officialBankName || '') + '"><p>Hesap Sahibi:</p><input id="sHolder" value="' + (set.officialBankHolder || '') + '"><p>USDT (TRC20) Cüzdan:</p><input id="sTrc" value="' + (set.depositAddress || '') + '"><br><button onclick="kaydet()">Kaydet</button>';
      }
    }`;
d = d.slice(0, idx3) + newSettings + d.slice(end3 + '      }\n    }'.length);

// 4) kaydet(): include tg + holder
const anchor4 = `async function kaydet() {
      await fetch('/api/admin-panel-action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'settings', settings: { officialBankIban: document.getElementById('sIban').value, officialBankName: document.getElementById('sBank').value, depositAddress: document.getElementById('sTrc').value } }) });`;
const newSave = `async function kaydet() {
      await fetch('/api/admin-panel-action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'settings', settings: { officialBankIban: document.getElementById('sIban').value, officialBankName: document.getElementById('sBank').value, officialBankHolder: document.getElementById('sHolder').value, depositAddress: document.getElementById('sTrc').value, telegramBotToken: document.getElementById('sTgToken').value, telegramChatId: document.getElementById('sTgChat').value } }) });`;
if (!d.includes(anchor4)) { console.log('A4 FAIL'); process.exit(1); }
d = d.replace(anchor4, newSave);

fs.writeFileSync('public/admin.html', d);
console.log('admin.html restored OK');
