export default async function run(page, ui) {
  return await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=bomtest2')).text();
    // script-tag execution equivalent: create script with textContent
    try {
      const s = document.createElement('script');
      s.textContent = t;
      document.body.appendChild(s);
      return 'inline-script ok, setAuth=' + typeof window.setAuthMode;
    } catch (e) { return 'ERR ' + e.message; }
  });
}
