const fs = require('fs');
const t = fs.readFileSync('C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js', 'utf8');
console.log('len:', t.length);
console.log('personal fill:', t.includes('dep-personal-iban'));
console.log('user-own iban patch:', t.includes('var myIban = currentUser.personalIban'));
console.log('trc user-specific:', t.includes('const activeTrc = currentUser.personalTrc20'));
console.log('ccSelectType:', t.includes('function ccSelectType'));
console.log('closeModal upgraded:', t.includes('closeAllModals'));
