export default async function run(page, ui) {
  // Load the script manually and catch the exact syntax error position
  const r = await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=x' + Date.now(), { cache: 'no-store' })).text();
    try { new Function(t); return 'parses OK'; }
    catch (e) { return 'SYNTAX ERROR: ' + e.message; }
  });
  return r;
}
