export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 300)));
  let authResp = null;
  await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(2500);
  const r = {};
  const em = 'papr' + Date.now() + '@mail.com';

  // Direct API test first
  const apiTest = await page.evaluate(async (e) => {
    const r = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'API Test', email: e, password: '123456', isRegister: true }) });
    return { status: r.status, body: await r.text() };
  }, em);
  r.apiDirect = apiTest;
  return { r, errors };
}
