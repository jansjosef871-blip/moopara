export default async function run(page, ui) {
  const res = {};
  res.before = await page.evaluate(() => typeof window.setAuthMode);
  await page.evaluate(() => { const s = document.createElement('script'); s.src = '/app.js?v=' + Math.random(); document.head.appendChild(s); });
  await page.waitForTimeout(1500);
  res.after = await page.evaluate(() => typeof window.setAuthMode);
  return res;
}
