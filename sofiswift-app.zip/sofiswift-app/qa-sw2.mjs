export default async function run(page, ui) {
  const res = {};
  res.check = await page.evaluate(async () => {
    const r = await fetch('/app.js?v=30000001', { cache: 'no-store' });
    const t = await r.text();
    return { len: t.length, start: t.slice(0, 60), fromCache: r.headers.get('x-served-by') || 'n/a' };
  });
  // try adding a NEW script tag with different URL
  res.after = await page.evaluate(async () => {
    await new Promise(res => {
      const s = document.createElement('script');
      s.src = '/app.js?v=zzz999';
      s.onload = () => res('loaded');
      s.onerror = () => res('error');
      document.body.appendChild(s);
      setTimeout(() => res('timeout'), 5000);
    });
    return typeof window.setAuthMode;
  });
  return res;
}
