const fs = require('fs');
const html = fs.readFileSync('public/admin.html', 'utf8');
const ids = ['adm-user', 'adm-pass', 'login-err', 'admin-panel', 'admin-login-box', 'admin-nav-right', 'admin-role-badge', 'stat-users', 'stat-reqs', 'stat-cards', 'stat-kyc', 'pending-box', 'pending-list', 'req-count', 'users-grid', 'user-search-input', 'open-staff-modal-btn', 'stf-name', 'stf-email', 'stf-pass', 'staff-list-wrap', 'audit-log-list', 'set-card-price', 'set-deposit-addr', 'set-api-key', 'set-bank-name', 'set-bank-holder', 'set-bank-iban', 'set-bank-swift', 'set-wa-num', 'set-wa-text', 'wa-toggle-btn', 'set-sms-key', 'set-smtp-user', 'set-smtp-pass', 'set-seo-title', 'set-seo-keys', 'set-seo-desc', 'set-logo-url', 'kyc-modal-details', 'kyc-modal-img-wrap', 'kyc-modal-toggle-btn', 'kyc-view-modal', 'staff-modal-overlay', 'admin-toast'];
const missing = ids.filter(i => !html.includes('id="' + i + '"'));
console.log(missing.length ? 'MISSING IDS: ' + missing.join(', ') : 'ALL IDS PRESENT');

const js = fs.readFileSync('public/admin.js', 'utf8');
const fns = ['doAdminLogin', 'adminLogin', 'adminLogout', 'renderAdmin', 'filterAdminUsers', 'saveSystemSettings', 'createStaffAdminV2', 'openStaffModal', 'handleReq', 'adminBal', 'adminCard', 'inspectUserKyc', 'promptAssignBank', 'clearAuditLogs', 'renderAuditLogs', 'adminGenerateApiKey', 'adminCopyApiKey', 'toggleWaStatus', 'toggleStaffPerm', 'toggleStaffAdmin', 'adminUserBan', 'promptAssignBank'];
const missFn = fns.filter(f => !js.includes('function ' + f) && !js.includes(f + ' =') && !js.includes(f + '('));
console.log(missFn.length ? 'CHECK FNS: ' + missFn.join(', ') : 'ALL FNS OK');

const idx = fs.readFileSync('public/index.html', 'utf8');
const check = ['manifest.json', 'sw.js', 'landing-hero', 'landing-features', 'pwa-install-btn', 'auth-section', 'tab-register'];
const missIdx = check.filter(c => !idx.includes(c));
console.log(missIdx.length ? 'MISSING INDEX: ' + missIdx.join(', ') : 'INDEX OK');
