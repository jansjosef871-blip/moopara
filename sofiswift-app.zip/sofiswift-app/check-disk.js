const fs = require('fs');
const t = fs.readFileSync('public/app.js', 'utf8');
console.log('len:', t.length);
console.log('drawer-open:', t.includes('drawer-open'));
console.log('menu-deposit:', t.includes('menu-deposit'));
console.log('submit-auth:', t.includes('submit-auth'));
console.log('toggle-pass:', t.includes('toggle-pass'));
console.log('close-deposit:', t.includes('close-deposit-modal'));
console.log('has delegation listener:', t.includes("addEventListener('click'"));
