let d = require('fs').readFileSync('public/app.js', 'utf8');
const oldStr = "    'dep-tab-personal': () => { document.getElementById('dep-pane-personal').classList.remove('hidden'); document.getElementById('dep-pane-crypto').classList.add('hidden'); document.getElementById('dep-tab-personal').classList.add('on'); document.getElementById('dep-tab-crypto').classList.remove('on'); },";
const newStr = "    'dep-tab-personal': () => { document.getElementById('dep-pane-personal').classList.remove('hidden'); document.getElementById('dep-pane-crypto').classList.add('hidden'); document.getElementById('dep-tab-personal').classList.add('on'); document.getElementById('dep-tab-crypto').classList.remove('on'); if (currentUser) fillPersonalDeposit(); },";
if (!d.includes(oldStr)) { console.log('NOT FOUND'); process.exit(1); }
d = d.replace(oldStr, newStr);

// add fillPersonalDeposit helper after openModal definition
const anchor = "function closeModal(id) { const el = document.getElementById(id); if (el) el.classList.add('hidden'); }";
const helper = anchor + "\nfunction fillPersonalDeposit() {\n  const ib = (currentUser.personalIban && !currentUser.personalIban.startsWith('US64 SOFI')) ? currentUser.personalIban : (appSettings.officialBankIban || 'US89 SOFI 0001 9988 7766 55');\n  const pq = document.getElementById('dep-personal-qr');\n  if (pq) pq.innerHTML = '<img src=\"/api/qr?text=' + encodeURIComponent(ib) + '\" alt=\"QR\" style=\"width:150px;height:150px;border-radius:12px;border:1px solid #E2E8F0;padding:6px;background:white;\" />';\n  const iE = document.getElementById('dep-personal-iban'); if (iE) iE.innerText = ib;\n  const hE = document.getElementById('dep-personal-holder'); if (hE) hE.innerText = currentUser.fullName || currentUser.name || '-';\n  const bE = document.getElementById('dep-personal-bank'); if (bE) bE.innerText = appSettings.officialBankName || 'Moopara Corporate Bank';\n}";
if (!d.includes(anchor)) { console.log('ANCHOR NOT FOUND'); process.exit(1); }
d = d.replace(anchor, helper);
require('fs').writeFileSync('public/app.js', d);
console.log('patched OK');
