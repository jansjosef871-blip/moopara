export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(2500);
  await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=' + Math.random(), { cache: 'no-store' })).text();
    (0, eval)(t);
  });
  out.reg = await page.evaluate(async () => {
    const email = 'qa' + Date.now() + '@test.com';
    const r = await fetch('/api/send-otp', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, phone: '05551234567' }) });
    const d = await r.json();
    const r2 = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'QA User', email, password: '1234', phone: '05551234567', otpCode: d.demoCode || '000000', isRegister: true }) });
    const d2 = await r2.json();
    if (!r2.ok) return { err: d2.error };
    currentUser = d2.user; appSettings = d2.settings || appSettings;
    enterApp();
    return { ok: true, uid: currentUser.id };
  });
  out.debug = await page.evaluate(() => {
    try {
      openModal('deposit-modal');
      return { cu: currentUser ? currentUser.id : null, modalVisible: !document.getElementById('deposit-modal').classList.contains('hidden') };
    } catch (e) { return { err: e.message }; }
  });
  out.click2 = await page.evaluate(() => {
    try {
      document.querySelector('[data-act="dep-tab-personal"]').click();
      return { iban: document.getElementById('dep-personal-iban').innerText, hasQr: !!document.querySelector('#dep-personal-qr img'), holder: document.getElementById('dep-personal-holder').innerText, bank: document.getElementById('dep-personal-bank').innerText };
    } catch (e) { return { err: e.message, stack: String(e.stack).slice(0, 200) }; }
  });
  await page.waitForTimeout(1200);
  await page.screenshot({ path: 'personal-iban-qr.png' });
  return out;
}
