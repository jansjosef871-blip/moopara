const http = require('http');
const start = Date.now();
http.get('http://localhost:3000/', res => {
  let t = '';
  res.on('data', d => t += d);
  res.on('end', () => {
    console.log('status:', res.statusCode, 'time:', Date.now() - start, 'ms, len:', t.length);
    console.log('has auth-section:', t.includes('auth-section'));
    console.log('has tab-register:', t.includes('tab-register'));
    console.log('has user-dashboard:', t.includes('user-dashboard'));
    console.log('body tag to auth-section gap:', t.indexOf('auth-section') - t.indexOf('<body'));
  });
});
