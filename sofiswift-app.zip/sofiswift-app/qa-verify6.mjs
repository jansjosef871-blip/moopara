export default async function run(page, ui) {
  const r = {};
  r.inline = await page.evaluate(() => {
    const s = document.createElement('script');
    s.textContent = 'window.__it = 7;';
    document.body.appendChild(s);
    return 'appended, immediate: ' + window.__it;
  });
  await page.waitForTimeout(600);
  r.afterWait = await page.evaluate(() => window.__it);
  return r;
}
