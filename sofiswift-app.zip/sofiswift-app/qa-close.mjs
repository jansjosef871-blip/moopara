export default async function run(page, ui) {
  // Currently deposit modal open in v13 session; click X
  const r = {};
  r.before = await page.evaluate(() => {
    const m = document.getElementById('deposit-modal');
    return { hidden: m ? m.classList.contains('hidden') : null, cls: m ? m.className : null };
  });
  await page.evaluate(() => { const b = document.querySelector('[data-act="close-deposit-modal"]'); if (b) b.click(); });
  await page.waitForTimeout(400);
  r.after = await page.evaluate(() => {
    const m = document.getElementById('deposit-modal');
    return { hidden: m.classList.contains('hidden'), display: getComputedStyle(m).display };
  });
  return r;
}
