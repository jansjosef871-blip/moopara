export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 200)));
  page.on('console', m => { if (m.type() === 'error') errors.push('CONSOLE: ' + m.text().slice(0, 150)); });
  await page.goto('http://localhost:3000/', { waitUntil: 'load' });
  await page.waitForTimeout(1000);
  const r = {};
  const em = 'final' + Date.now() + '@mail.com';

  // 1. REGISTER
  await page.click('#tab-register');
  await page.waitForTimeout(300);
  r.regNameVisible = await page.locator('#auth-name').isVisible();
  await page.fill('#auth-name', 'Final Test');
  await page.fill('#auth-email', em);
  await page.fill('#auth-pass', '123456');
  const rp = page.waitForResponse(x => x.url().includes('/api/auth'), { timeout: 8000 }).catch(() => null);
  await page.click('#auth-btn-text');
  r.regStatus = (await rp)?.status();
  await page.waitForTimeout(1200);
  r.dashboard = await page.locator('#user-dashboard').isVisible().catch(() => false);

  // 2. DRAWER MENU — open, navigate to card view, back
  await page.click('#menu-open-btn');
  await page.waitForTimeout(400);
  r.drawerOpen = await page.evaluate(() => !document.getElementById('side-drawer').classList.contains('closed'));
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-card"]').click());
  await page.waitForTimeout(400);
  r.cardView = await page.locator('#card-control-view').isVisible().catch(() => false);
  await page.evaluate(() => document.querySelector('#card-control-view button[onclick], #card-control-view .back-btn')?.click() || window.showMainView && showMainView('dashboard'));
  await page.waitForTimeout(300);
  r.backToDash = await page.locator('#user-dashboard').isVisible().catch(() => false);

  // 3. All modals via dashboard action buttons
  const modals = [['menu-deposit', 'deposit-modal'], ['menu-bills', 'bill-modal'], ['menu-swap', 'swap-modal'], ['menu-withdraw', 'withdraw-modal']];
  r.modals = {};
  for (const [act, id] of modals) {
    await page.evaluate(a => document.querySelector('#user-dashboard [data-act="' + a + '"], #side-drawer [data-act="' + a + '"]').click(), act);
    await page.waitForTimeout(300);
    r.modals[id] = await page.evaluate(i => !document.getElementById(i).classList.contains('hidden'), id);
    await page.evaluate(i => document.getElementById(i).classList.add('hidden'), id);
    Calibrate: ;
  }

  // 4. Card visual elements
  r.cardCvv = await page.evaluate(() => !!document.getElementById('card-cvv-text'));
  r.cardExp = await page.evaluate(() => !!document.getElementById('card-exp-text'));
  r.cardChip = await page.evaluate(() => !!document.querySelector('.card-chip'));

  // 5. Balance green logic
  r.balanceGreen = await page.evaluate(() => getComputedStyle(document.getElementById('user-balance')).color);

  // 6. Logout then login
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-logout"]').click());
  await page.waitForTimeout(500);
  r.backToAuth = await page.locator('#auth-section').isVisible().catch(() => false);
  await page.fill('#auth-email', em);
  await page.fill('#auth-pass', '123456');
  const lp = page.waitForResponse(x => x.url().includes('/api/auth'), { timeout: 8000 }).catch(() => null);
  await page.click('#auth-btn-text');
  r.loginStatus = (await lp)?.status();
  await page.waitForTimeout(1000);
  r.reloggedIn = await page.locator('#user-dashboard').isVisible().catch(() => false);

  // screenshot of dashboard
  await page.screenshot({ path: 'final-dashboard.png', fullPage: false });
  r.errors = errors;
  return r;
}
