export default async function run(page, ui) {
  const r = await page.evaluate(() => new Promise(resolve => {
    const s = document.createElement('script');
    s.textContent = 'window.a=1;';
    document.documentElement.appendChild(s);
    setTimeout(() => resolve({ a: String(window.a) }), 400);
  }));
  return r;
}
