const d = require('fs').readFileSync('public/app.js', 'utf8');
// how many openModal defs? and where is currentUser = d.user?
console.log('openModal count:', (d.match(/function openModal/g) || []).length);
const idxs = [...d.matchAll(/function openModal/g)].map(m => d.slice(0, m.index).split('\n').length);
console.log('openModal lines:', idxs);
const cu = [...d.matchAll(/currentUser = d\.user/g)].map(m => d.slice(0, m.index).split('\n').length);
console.log('currentUser=d.user lines:', cu);
// check openModal at 100 vs other
for (const ln of idxs) {
  const lines = d.split('\n');
  console.log('--- openModal at line', ln, '---');
  console.log(lines.slice(ln - 1, ln + 15).join('\n'));
}
