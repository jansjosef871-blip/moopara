export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);
  out.authVisible = await page.evaluate(() => {
    const a = document.getElementById('auth-section');
    return a ? !a.classList.contains('hidden') : 'missing';
  });
  // register a fresh test user
  const email = 'qa' + Date.now() + '@test.dev';
  await page.evaluate(() => { try { window.setAuthMode(true); } catch (e) { } });
  await page.evaluate(() => document.getElementById('name-field')?.classList.remove('hidden'));
  await page.fill('#auth-name', 'QA Tester');
  await page.fill('#auth-email', email);
  await page.fill('#auth-pass', 'test1234');
  await page.evaluate(() => { try { window.handleAuth(); } catch (e) { console.error(e); } });
  await page.waitForTimeout(1500);
  out.loggedIn = await page.evaluate(() => !!document.getElementById('drawer-user-name') && document.getElementById('drawer-user-name').innerText.length > 1);
  // open deposit modal
  await page.evaluate(() => {
    const btn = [...document.querySelectorAll('[data-act]')].find(b => ['menu-deposit', 'open-deposit'].includes(b.dataset.act));
    if (btn) btn.click();
  });
  await page.waitForTimeout(400);
  out.modalOpen = await page.evaluate(() => !document.getElementById('deposit-modal')?.classList.contains('hidden'));
  out.tabs = {};
  for (const t of ['personal', 'bank', 'crypto']) {
    await page.evaluate(tab => document.querySelector('[data-act="dep-tab-' + tab + '"]')?.click(), t);
    await page.waitForTimeout(250);
    out.tabs[t] = await page.evaluate(tab => {
      const pane = document.getElementById('dep-pane-' + tab);
      const btn = document.querySelector('[data-act="dep-tab-' + tab + '"]');
      return pane ? { hidden: pane.classList.contains('hidden'), active: btn ? btn.style.background !== 'transparent' : null } : 'missing';
    }, t);
  }
  await page.evaluate(() => document.querySelector('[data-act="dep-tab-personal"]')?.click());
  await page.waitForTimeout(300);
  out.personal = await page.evaluate(() => ({
    iban: document.getElementById('dep-personal-iban')?.innerText,
    holder: document.getElementById('dep-personal-holder')?.innerText,
    bank: document.getElementById('dep-personal-bank')?.innerText,
    trc: document.getElementById('dep-personal-trc')?.innerText?.slice(0, 14)
  }));
  await page.screenshot({ path: 'finish-personal.png' });
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]')?.click());
  await page.waitForTimeout(300);
  out.closedAfterX = await page.evaluate(() => document.getElementById('deposit-modal')?.classList.contains('hidden'));
  await page.screenshot({ path: 'finish-closed.png' });
  return JSON.stringify(out, null, 2);
}
