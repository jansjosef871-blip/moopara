// Simulate exactly what server.js does
process.chdir(__dirname || '.');
const getDB = () => JSON.parse(require('fs').readFileSync('database.json', 'utf8'));
const db = getDB();
const t = db.settings.telegramBotToken, chat = db.settings.telegramChatId;
console.log('token:', JSON.stringify(t));
console.log('chat:', JSON.stringify(chat));
fetch('https://api.telegram.org/bot' + t + '/sendMessage', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ chat_id: chat, text: '[SIM] server benzeri çağrı', parse_mode: 'HTML' })
}).then(r => r.json()).then(d => console.log('result:', JSON.stringify(d)));
