export default async function run(page, ui) {
  return await page.evaluate(async () => {
    const results = {};
    // 1. Simple blob script — did __simple get set?
    results.simple = window.__simple;   // from previous run (different session, so null)
    // 2. Inline event handler sanity
    const b = document.createElement('button');
    b.setAttribute('onclick', 'window.__oc=1');
    document.body.appendChild(b);
    b.click();
    results.onclick = window.__oc;
    // 3. Now via blob url simple script — fresh
    const blob = new Blob(['window.__simple2="yes";'], { type: 'text/javascript' });
    const s = document.createElement('script');
    s.src = URL.createObjectURL(blob);
    document.body.appendChild(s);
    await new Promise(r => setTimeout(r, 800));
    results.blobScript = window.__simple2;
    return results;
  });
}
