export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(2000);
  await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=' + Math.random(), { cache: 'no-store' })).text();
    (0, eval)(t);
  });
  // Full UI-driven register flow
  await page.evaluate(() => setAuthMode(true));
  const email = 'qa' + Date.now() + '@test.com';
  await page.fill('#auth-name', 'Canli Test');
  await page.fill('#auth-email', email);
  await page.fill('#auth-phone', '05551112233');
  await page.fill('#auth-pass', '1234');
  await page.evaluate(() => sendOtpCode());
  await page.waitForTimeout(2500);
  out.otpMsg = await page.evaluate(() => document.getElementById('auth-error').innerText);
  // OTP is on the real phone now; we cannot read it. Verify the message says SMS sent (not demo code).
  out.smsReallySent = out.otpMsg.includes('telefonunuza gönderildi');
  return out;
}
