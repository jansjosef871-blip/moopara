const fs = require('fs');
const t = fs.readFileSync('C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js', 'utf8');
console.log('starts with IIFE:', t.trimStart().slice(0, 30));
console.log('has "function enterApp":', t.includes('function enterApp'));
console.log('has "function doAuth":', t.includes('function doAuth'));
// find how functions are declared
const i = t.indexOf('enterApp');
console.log('ctx around enterApp:', t.slice(Math.max(0, i - 100), i + 60));
