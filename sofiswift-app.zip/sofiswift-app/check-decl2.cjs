const d = require('fs').readFileSync('public/app.js', 'utf8');
const m = [...d.matchAll(/^let currentUser/gm)];
m.forEach(x => {
  const ln = d.slice(0, x.index).split('\n').length;
  console.log('decl at line', ln, ':', d.slice(x.index, x.index + 120));
});
