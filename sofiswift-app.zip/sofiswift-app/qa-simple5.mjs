export default async function run(page, ui) {
  const r = {};
  r.inline = await page.evaluate(() => { const s = document.createElement('script'); s.textContent = 'window.__it=7'; document.body.appendChild(s); return window.__it; });
  r.waited = await page.evaluate(() => new Promise(res => setTimeout(() => res(window.__it), 500)));
  return r;
}
