export default async function run(page, ui) {
  const res = {};
  res.probe = await page.evaluate(async () => {
    // Load via blob URL, exact bytes
    const t = await (await fetch('/app.js?v=blob1', { cache: 'no-store' })).text();
    const blob = new Blob([t], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const s = document.createElement('script');
    s.src = url;
    document.body.appendChild(s);
    await new Promise(r => { s.onload = r; s.onerror = r; setTimeout(r, 3000); });
    return { viaBlob: typeof window.setAuthMode, firstChar: t.charCodeAt(0), lastChars: t.slice(-3) };
  });
  return res;
}
