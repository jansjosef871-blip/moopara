const d = require('fs').readFileSync('public/app.js', 'utf8');
// There may be TWO click delegation handlers; the second one (capture) might hijack dep-tab-personal before map
const count = (d.match(/document.addEventListener\('click'/g) || []).length;
console.log('click handlers:', count);
const idx = d.indexOf("'dep-tab-personal': () => { document.getElementById('dep-pane-personal').classList.remove('hidden'); document.getElementById('dep-pane-crypto').classList.add('hidden'); document.getElementById('dep-tab-personal').classList.add('on'); document.getElementById('dep-tab-crypto').classList.remove('on'); if (currentUser) fillPersonalDeposit(); }");
console.log('patched handler present:', idx > 0);
// Which handler contains it? find preceding "document.addEventListener('click'"
const h2 = d.lastIndexOf("document.addEventListener('click'", idx);
console.log('handler index:', h2, 'total handlers pos:', [...d.matchAll(/document.addEventListener\('click'/g)].map(m => m.index));
