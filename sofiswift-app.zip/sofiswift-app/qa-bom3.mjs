export default async function run(page, ui) {
  return await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=bomtest3')).text();
    // Execute only a small deterministic portion to see where it silently stops
    const lines = t.split('\n');
    const results = [];
    for (let n = 20; n <= lines.length; n += 40) {
      try {
        const chunk = lines.slice(0, n).join('\n');
        // indirect eval -> global scope
        (0, eval)(chunk);
        results.push(n + ':ok');
      } catch (e) { results.push(n + ':' + e.message.slice(0, 60)); break; }
    }
    return { total: lines.length, setAuthAfter: typeof window.setAuthMode, results: results.slice(0, 12) };
  });
}
