﻿const express = require('express');
const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');
const nodemailer = require('nodemailer');
const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'database.json');
const SUPER_ADMIN_USER = 'atmaca';
const SUPER_ADMIN_PASS = 'admin2026!';
const PRICES = { USDT: 1, USDC: 1, BTC: 91500, ETH: 3120, SOL: 210, TRX: 0.25, XRP: 1.15, BNB: 620, ADA: 0.75, AVAX: 38 };
const EMPTY_ASSETS = { USDT: 0, USDC: 0, BTC: 0, ETH: 0, SOL: 0, TRX: 0, XRP: 0, BNB: 0, ADA: 0, AVAX: 0, TRY: 0, USD: 0, EUR: 0 };

app.use(express.json({ limit: '10mb' }));
const helmet = require('helmet');
const crypto = require('crypto');

app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));

const apiHits = {};
app.use('/api/', (req, res, next) => {
  const ip = req.ip || 'unknown';
  const now = Date.now();
  const entry = apiHits[ip] || { count: 0, reset: now + 60000 };
  if (now > entry.reset) { entry.count = 0; entry.reset = now + 60000; }
  entry.count += 1;
  apiHits[ip] = entry;
  if (entry.count > 120) return res.status(429).json({ error: 'Too many requests. Please slow down.' });
  next();
});
app.get('/', (req, res) => {
  const s = getDB().settings;
  let html = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf-8');
  if (s.seoTitle) html = html.replace(/<title>.*?<\/title>/, '<title>' + s.seoTitle + '</title>');
  if (s.seoDesc) html = html.replace(/<meta name="description" content=".*?" \/>/, '<meta name="description" content="' + s.seoDesc + '" />');
  if (s.seoKeys) html = html.replace(/<meta name="keywords" content=".*?" \/>/, '<meta name="keywords" content="' + s.seoKeys + '" />');
  if (!html.includes('/app.js')) html += '<script src="/app.js?v=999999"></script>'; if (!html.includes('/app.js')) html = html.replace('</body>', '<script src="/app.js?v=2026999"></script></body>'); res.send(html);
});
app.use(express.static(path.join(__dirname, 'public'), { etag: false, lastModified: false, setHeaders: (res) => { res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate'); } }));

async function sendBankSms(phone, message) {
  try {
    const db = getDB();
    if (!phone || !db.settings.smsEdgeKey) return { sent: false, reason: 'no-key' };
    // Normalize phone to E.164 (Turkey default)
    let to = String(phone).replace(/[^0-9+]/g, '');
    if (!to.startsWith('+')) {
      if (to.startsWith('0')) to = '+90' + to.slice(1);
      else if (to.length === 10) to = '+90' + to;
      else to = '+' + to;
    }
    const r = await fetch('https://api.smsedge.com/v1/sms/send?api_key=' + encodeURIComponent(db.settings.smsEdgeKey), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'accept': 'application/json' },
      body: JSON.stringify({ to, text: message, from: 'Moopara' })
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || d.success === false) {
      console.error('SmsEdge error:', JSON.stringify(d).slice(0, 300));
      return { sent: false, reason: 'api-error', detail: d };
    }
    return { sent: true, id: d.data && d.data.id };
  } catch (e) { console.error('SmsEdge exception:', e.message); return { sent: false, reason: 'exception' }; }
}

// Telegram bildirimi: admin panelinden girilen botToken + chatId'ye mesaj yollar
async function sendTelegram(text, tag) {
  try {
    const db = getDB();
    const t = db.settings.telegramBotToken, chat = db.settings.telegramChatId;
    if (!t || !chat) return { sent: false, reason: 'not-configured' };
    console.log('[TG] sending with token:', String(t).slice(0, 12), 'chat:', chat);
    const msg = (tag ? '[' + tag + '] ' : '') + text;
    const r = await fetch('https://api.telegram.org/bot' + t + '/sendMessage', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chat, text: msg, parse_mode: 'HTML' })
    });
    const d = await r.json().catch(() => ({}));
    if (!d.ok) { console.error('Telegram error:', JSON.stringify(d).slice(0, 200)); return { sent: false, detail: d }; }
    return { sent: true };
  } catch (e) { console.error('Telegram exception:', e.message); return { sent: false }; }
}

async function sendBankEmail(toEmail, subject, htmlBody) {
  try {
    const db = getDB();
    if (!db.settings.smtpUser || !db.settings.smtpPass) return;
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user: db.settings.smtpUser, pass: db.settings.smtpPass }
    });
    await transporter.sendMail({ from: '"Moopara Global Bank" <' + db.settings.smtpUser + '>', to: toEmail, subject, html: htmlBody });
  } catch (e) {}
}

function generateUserBankDetails(userId) {
  const cleanId = String(userId).padStart(10, '0');
  const iban = 'TR64 0001 0019 ' + cleanId.slice(0, 4) + ' ' + cleanId.slice(4, 8) + ' ' + cleanId.slice(8, 10);
  const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  let seed = Number(String(userId).slice(-6)) || 123456;
  let addr = 'T';
  for (let i = 0; i < 33; i++) {
    seed = (seed * 16807) % 2147483647;
    addr += chars[seed % chars.length];
  }
  return { personalIban: iban, swiftCode: 'TCZBTR2AXXX', personalTrc20: addr };
}
function getDB() {
  const ensureBank = (u) => { if (!u.personalIban || !u.personalTrc20) { const b = generateUserBankDetails(u.id); u.personalIban = u.personalIban || b.personalIban; u.swiftCode = u.swiftCode || b.swiftCode; u.personalTrc20 = u.personalTrc20 || b.personalTrc20; } };
  if (!fs.existsSync(DB_FILE)) {
    const init = {
      settings: { cardPrice: 20, depositAddress: 'TX9aK8pL2mQ7vR4wN1zB6cJ3yH5fD8sG0e', logoUrl: '', smsEdgeKey: '', smtpUser: '', smtpPass: '' },
      pendingRequests: [],
      users: [{ id: 9277818464, name: 'Ercan SaÄŸlam', email: 'ercan@moopara.com', password: '123', isAdmin: false, kycStatus: 'UNVERIFIED', assets: { ...EMPTY_ASSETS, USDT: 22000000 }, hasCard: false, cardBrand: null, cardNumber: null, cardExpiry: null, cardCvv: null, transactions: [] }]
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(init, null, 2));
  }
  const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  if (!db.pendingRequests) db.pendingRequests = []; if (!db.auditLogs) db.auditLogs = []; (db.users || []).forEach(ensureBank);
  return db;
}
function saveDB(db) {
  const json = JSON.stringify(db, null, 2);
  fs.writeFileSync(DB_FILE + '.tmp', json);
  fs.renameSync(DB_FILE + '.tmp', DB_FILE);
  fs.writeFileSync(path.join(__dirname, 'database.backup.json'), json);
} 
function addAuditLog(actor, action, detail) {
  try {
    const db = getDB();
    if (!db.auditLogs) db.auditLogs = []; (db.users || []).forEach(ensureBank);
    db.auditLogs.unshift({ id: Date.now(), actor: actor || 'Sistem', action, detail, date: new Date().toLocaleString('tr-TR') });
    if (db.auditLogs.length > 200) db.auditLogs = db.auditLogs.slice(0, 200);
    saveDB(db);
  } catch (e) {}
}

app.post('/api/admin/clear-logs', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid || auth.role !== 'SUPER') return res.status(403).end();
  const db = getDB(); db.auditLogs = []; saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});
function checkAdminAuth(req) { const u = req.headers['x-admin-user'], p = req.headers['x-admin-password']; req.adminActor = u; if (u === SUPER_ADMIN_USER && p === SUPER_ADMIN_PASS) return { valid: true, role: 'SUPER' }; const sub = getDB().users.find(x => x.isAdmin && x.adminActive !== false && x.adminActive !== false && (x.email.toLowerCase() === String(u).toLowerCase() || String(x.id) === String(u)) && x.password === p); return sub ? { valid: true, role: 'OPERATOR', name: sub.name } : { valid: false }; }
function makeCard(brand) {
  const b = brand === 'MASTERCARD' ? 'MASTERCARD' : 'VISA', p1 = b === 'MASTERCARD' ? '5412 ' : '4532 ';
  const rnd = () => Math.floor(1000 + Math.random() * 9000);
  return { cardBrand: b, cardNumber: p1 + rnd() + ' ' + rnd() + ' ' + rnd(), cardExpiry: '08/30', cardCvv: String(Math.floor(100 + Math.random() * 899)) };
}
const SECRET_ADMIN_PATH = '/yonetim-atmaca-2026';
const adminLoginAttempts = {};

/* ---------- TOTP (Google Authenticator uyumlu) — bağımsız implementasyon ---------- */
const crypto2 = crypto;
function base32Encode(buf) {
  const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits = 0, val = 0, out = '';
  for (const b of buf) { val = (val << 8) | b; bits += 8; while (bits >= 5) { out += A[(val >>> (bits - 5)) & 31]; bits -= 5; } }
  if (bits > 0) out += A[(val << (5 - bits)) & 31];
  return out;
}
function base32Decode(str) {
  const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits = 0, val = 0; const out = [];
  for (const c of str.toUpperCase().replace(/=+$/, '')) { const i = A.indexOf(c); if (i === -1) continue; val = (val << 5) | i; bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(out);
}
function totpGenerate(secretB32, timeStep) {
  const step = timeStep || Math.floor(Date.now() / 30000);
  const buf = Buffer.alloc(8); buf.writeUInt32BE(Math.floor(step / 2 ** 32), 0); buf.writeUInt32BE(step % 2 ** 32, 4);
  const hmac = crypto2.createHmac('sha1', base32Decode(secretB32)).update(buf).digest();
  const off = hmac[hmac.length - 1] & 15;
  const code = ((hmac[off] & 127) << 24 | hmac[off + 1] << 16 | hmac[off + 2] << 8 | hmac[off + 3]) % 1000000;
  return String(code).padStart(6, '0');
}
function totpVerify(secretB32, code) {
  if (!secretB32 || !/^\d{6}$/.test(String(code || ''))) return false;
  const now = Math.floor(Date.now() / 30000);
  for (const s of [now, now - 1, now + 1]) if (totpGenerate(secretB32, s) === String(code)) return true;
  return false;
}
function ensureAdminTotp(db) {
  if (!db.settings.adminTotpSecret) {
    db.settings.adminTotpSecret = base32Encode(crypto2.randomBytes(20));
    saveDB(db);
  }
  return db.settings.adminTotpSecret;
}

app.use((req, res, next) => {
  if (req.path === '/admin' || req.path === '/admin/' || req.path === '/admin.html') {
    return res.status(404).send('<!DOCTYPE html><html><head><title>404 Not Found</title></head><body><h1>Not Found</h1><p>The requested URL was not found on this server.</p></body></html>');
  }
  next();
});

app.get(SECRET_ADMIN_PATH, (req, res) => {
  res.setHeader('X-Robots-Tag', 'noindex, nofollow, noarchive');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

/* ---------- 2FA Kurulum (Sadece süper admin kimliğiyle) ---------- */
app.get('/api/admin/2fa-setup', (req, res) => {
  const u = req.query.u, p = req.query.p;
  if (u !== SUPER_ADMIN_USER || p !== SUPER_ADMIN_PASS) return res.status(403).json({ error: 'Yetkisiz' });
  const db = getDB();
  const secret = ensureAdminTotp(db);
  const otpauth = 'otpauth://totp/moopara:' + encodeURIComponent('atmaca') + '?secret=' + secret + '&issuer=moopara&algorithm=SHA1&digits=6&period=30';
  res.json({ secret, otpauth, qrUrl: '/api/qr?text=' + encodeURIComponent(otpauth) });
});

app.post('/api/admin/2fa-verify', (req, res) => {
  const { username, password, code } = req.body || {};
  if (username !== SUPER_ADMIN_USER || password !== SUPER_ADMIN_PASS) return res.status(403).json({ error: 'Yetkisiz' });
  const db = getDB();
  const secret = ensureAdminTotp(db);
  const ok = totpVerify(secret, code);
  res.json({ ok });
});

app.get('/api/prices', (req, res) => res.json(PRICES));
app.get('/api/qr', async (req, res) => {
  try {
    const url = await QRCode.toDataURL(req.query.text || 'TX9aK8pL2mQ7vR4wN1zB6cJ3yH5fD8sG0e', { width: 220, margin: 2 });
    const img = Buffer.from(url.slice(22), 'base64');
    res.writeHead(200, { 'Content-Type': 'image/png', 'Content-Length': img.length });
    res.end(img);
  } catch (e) { res.status(500).end(); }
});

const pendingOtps = {};

app.post('/api/auth', (req, res) => {
  const { name, email, password, phone, otpCode, isRegister } = req.body, db = getDB();
  if (isRegister) {
    if (!name || !email || !password) return res.status(400).json({ error: 'Lütfen tüm alanları doldurun.' });
    if (!phone || String(phone).replace(/[^0-9]/g, '').length < 10) return res.status(400).json({ error: 'SMS doğrulama için geçerli bir telefon numarası gerekli.' });
    const expected = pendingOtps[String(email).toLowerCase()];
    if (!expected || typeof expected !== 'object') return res.status(400).json({ error: 'Önce telefonunuza SMS doğrulama kodu gönderin.' });
    if (expected.expires < Date.now()) { delete pendingOtps[String(email).toLowerCase()]; return res.status(400).json({ error: 'Doğrulama kodunun süresi doldu. Yeni kod isteyin.' }); }
    if (String(otpCode || '').trim() !== expected.code) return res.status(400).json({ error: 'SMS doğrulama kodu hatalı! Lütfen telefonunuza gelen 6 haneli kodu girin.' });
    delete pendingOtps[String(email).toLowerCase()];
    if (db.users.find(u => u.email.toLowerCase() === email.toLowerCase())) return res.status(400).json({ error: 'Bu e-posta zaten kayıtlı.' });
    const nu = { id: Math.floor(1000000000 + Math.random() * 8999999999), name, email, phone: phone || '', password, isAdmin: false, kycStatus: 'UNVERIFIED', assets: { ...EMPTY_ASSETS }, hasCard: false, cardBrand: null, cardNumber: null, cardExpiry: null, cardCvv: null, transactions: [] };
    const bank = generateUserBankDetails(nu.id);
    nu.personalIban = bank.personalIban; nu.swiftCode = bank.swiftCode; nu.personalTrc20 = bank.personalTrc20;
    db.users.push(nu); saveDB(db);
    sendTelegram('🆕 <b>YENİ KAYIT</b>\n👤 ' + nu.name + '\n📧 ' + nu.email + '\n📱 ' + (nu.phone || '-') + '\n🆔 ID: ' + nu.id + '\n🕒 ' + new Date().toLocaleString('tr-TR'), 'REGISTER');
    return res.json({ user: nu, settings: { ...db.settings, officialBankName: db.settings.officialBankName || 'Moopara Corporate Bank USA', officialBankHolder: db.settings.officialBankHolder || 'Moopara Financial LLC', officialBankIban: db.settings.officialBankIban || 'US89 MOOP 0001 9988 7766 55', officialBankSwift: db.settings.officialBankSwift || 'TCZBTR2AXXX' }, prices: PRICES });
  }
  const idKey = String(email || '').trim().toLowerCase();
  const u = db.users.find(x => ((x.email || '').toLowerCase() === idKey || String(x.phone || '') === String(email || '').trim() || String(x.phone || '').replace(/[^0-9]/g, '') === idKey.replace(/[^0-9]/g, '')) && x.password === password);
  if (!u) return res.status(401).json({ error: 'Invalid email, phone or password!' }); if (u.isBanned) return res.status(403).json({ error: 'Account suspended by compliance department!' });
  res.json({ user: u, settings: { ...db.settings, officialBankName: db.settings.officialBankName || 'Moopara Corporate Bank USA', officialBankHolder: db.settings.officialBankHolder || 'Moopara Financial LLC', officialBankIban: db.settings.officialBankIban || 'US89 MOOP 0001 9988 7766 55', officialBankSwift: db.settings.officialBankSwift || 'TCZBTR2AXXX' }, prices: PRICES });
});
app.post('/api/deposit', (req, res) => {
  const { userId, amount } = req.body, db = getDB(), u = db.users.find(x => x.id == userId), val = parseFloat(amount);
  if (!u || isNaN(val) || val <= 0) return res.status(400).json({ error: 'Invalid amount.' });
  const now = new Date().toLocaleString('en-US');
  db.pendingRequests.unshift({ id: Date.now(), type: 'DEPOSIT', userId: u.id, userName: u.name, amount: val, date: now });
  u.transactions.unshift({ title: 'Deposit Notice (Pending)', amount: val, type: 'plus', date: now });
  saveDB(db);
  sendTelegram('💰 <b>PARA YATIRMA BİLDİRİMİ</b>\n👤 ' + u.name + ' (ID: ' + u.id + ')\n💵 Tutar: <b>$' + val + '</b>\n🕒 ' + now, 'DEPOSIT');
  res.json({ user: u, message: 'Deposit notice submitted.' });
});

app.post('/api/buy-card', (req, res) => {
  const { userId, brand, paidAmount, free, cardType } = req.body, db = getDB(), u = db.users.find(x => x.id == userId), val = parseFloat(paidAmount);
  const isFreeVirtual = !!free && cardType === 'VIRTUAL' && !u.hasCard;
  if (!u) return res.status(400).json({ error: 'User not found' });
  if (!isFreeVirtual && (isNaN(val) || val < db.settings.cardPrice)) return res.status(400).json({ error: 'Min payment: $' + db.settings.cardPrice });
  const b = brand === 'MASTERCARD' ? 'MASTERCARD' : 'VISA', now = new Date().toLocaleString('en-US');
  if (isFreeVirtual) {
    // Ãœcretsiz sanal kart â€” anÄ±nda ver
    u.hasCard = true; u.cardBrand = b; u.cardNumber = '5' + String(Math.floor(Math.random() * 1e15)).padStart(15, '0').slice(0, 15);
    u.cardExpiry = '12/' + (new Date().getFullYear() + 3).toString().slice(-2); u.cardCvv = String(Math.floor(Math.random() * 900) + 100);
    u.transactions.unshift({ title: b + ' Ãœcretsiz Sanal Kart OluÅŸturuldu', amount: 0, type: 'plus', date: now });
    saveDB(db); return res.json({ user: u, message: 'Ãœcretsiz sanal kartÄ±n hazÄ±r! ğŸ‰' });
  }
  db.pendingRequests.unshift({ id: Date.now(), type: 'CARD', userId: u.id, userName: u.name, brand: b, amount: val, date: now });
  u.transactions.unshift({ title: b + ' Card Payment Notice', amount: val, type: 'plus', date: now });
  saveDB(db); res.json({ user: u, message: 'Card payment submitted.' });
});

app.post('/api/send-otp', async (req, res) => {
  const { email, phone } = req.body || {};
  if (!email) return res.status(400).json({ error: 'E-posta gerekli.' });
  const code = String(Math.floor(100000 + Math.random() * 900000));
  pendingOtps[String(email).toLowerCase()] = { code, expires: Date.now() + 10 * 60 * 1000 };
  let smsResult = null;
  if (phone) smsResult = await sendBankSms(phone, 'Moopara dogrulama kodu: ' + code);
  // SMS gerçekten gittiyse kodu yanıtta LEKELEME — gerçek doğrulama.
  if (smsResult && smsResult.sent) return res.json({ ok: true, sent: true, via: 'smsedge' });
  // Anahtar yok / gönderilemedi → test modunda kodu göster
  res.json({ ok: true, sent: false, demoCode: code });
});

app.post('/api/withdraw', (req, res) => {
  const { senderId, method, target, bankDetails, amount } = req.body, db = getDB(), s = db.users.find(x => x.id == senderId);
  if (!s) return res.status(401).json({ error: 'Oturum bulunamadı.' });
  if (!s.hasCard && method !== 'INTERNAL') return res.status(403).json({ error: 'Active Virtual Card required!' });
  const val = parseFloat(amount);
  if (isNaN(val) || val <= 0 || val > s.assets.USDT) return res.status(400).json({ error: 'Insufficient USDT balance.' });
  const now = new Date().toLocaleString('en-US');

  if (method === 'INTERNAL') {
    const r = db.users.find(x => String(x.id) === String(target).replace('#', '') || x.email.toLowerCase() === String(target).toLowerCase());
    if (!r || r.id === s.id) return res.status(400).json({ error: 'Recipient Moopara Account ID not found.' });
    s.assets.USDT -= val; r.assets.USDT += val;
    s.transactions.unshift({ title: 'Internal Transfer -> ID ' + r.id, amount: val, type: 'minus', date: now });
    r.transactions.unshift({ title: 'Received <- ID ' + s.id, amount: val, type: 'plus', date: now });
    saveDB(db);
    return res.json({ user: s, message: 'Instant transfer sent to ID ' + r.id });
  }

  s.assets.USDT -= val;
  const infoText = bankDetails
    ? (bankDetails.bankName + ' | ' + bankDetails.holderName + ' | IBAN: ' + bankDetails.iban + (bankDetails.swift ? ' | SWIFT: ' + bankDetails.swift : ''))
    : target;
  db.pendingRequests.unshift({ id: Date.now(), type: 'WITHDRAW_IBAN', userId: s.id, userName: s.name, amount: val, brand: infoText, date: now });
  s.transactions.unshift({ title: 'Bank IBAN Withdrawal (' + (bankDetails ? bankDetails.iban : target) + ')', amount: val, type: 'minus', date: now });
  saveDB(db);
  sendBankEmail(s.email, 'Moopara Bank IBAN Withdrawal Contract & Receipt (-$' + val + ')', '<h2>Moopara Wire Withdrawal Contract</h2><p>Dear <b>' + s.name + '</b>,</p><p>Your withdrawal order of <b>$' + val + ' USD</b> to <b>' + infoText + '</b> has been queued on ' + now + '.</p>');
  sendTelegram('💸 <b>ÇEKİM TALEBİ</b>\n👤 ' + s.name + ' (ID: ' + s.id + ')\n💵 Tutar: <b>$' + val + '</b>\n🏦 ' + infoText + '\n🕒 ' + now, 'WITHDRAW');
  res.json({ user: s, message: 'Bank IBAN withdrawal submitted! Receipt & contract sent to your email.' });
});

app.post('/api/pay-bill', (req, res) => {
  const { userId, provider, subscriberNo, amount } = req.body, db = getDB(), u = db.users.find(x => x.id == userId), val = parseFloat(amount);
  if (!u || !u.hasCard) return res.status(403).json({ error: 'Active card required!' });
  if (isNaN(val) || val <= 0 || val > u.assets.USDT) return res.status(400).json({ error: 'Insufficient USDT.' });
  u.assets.USDT -= val;
  u.transactions.unshift({ title: 'Bill: ' + provider + ' (' + subscriberNo + ')', amount: val, type: 'minus', date: new Date().toLocaleString('en-US') });
  saveDB(db); res.json({ user: u, message: 'Bill paid!' });
});

app.post('/api/swap', (req, res) => {
  const { userId, toCoin, usdAmount } = req.body, db = getDB(), u = db.users.find(x => x.id == userId), val = parseFloat(usdAmount);
  if (!u || isNaN(val) || val <= 0 || val > u.assets.USDT) return res.status(400).json({ error: 'Insufficient USDT.' });
  const got = val / (PRICES[toCoin] || 1);
  u.assets.USDT -= val; u.assets[toCoin] = (u.assets[toCoin] || 0) + got;
  u.transactions.unshift({ title: 'Swap $' + val + ' -> ' + got.toFixed(5) + ' ' + toCoin, amount: val, type: 'minus', date: new Date().toLocaleString('en-US') });
  saveDB(db); res.json({ user: u, message: 'Converted!' });
});

app.post('/api/loan-request', (req, res) => {
  const { userId, amount, months } = req.body, db = getDB(), u = db.users.find(x => x.id == userId), val = parseFloat(amount);
  if (!u || isNaN(val) || val <= 0) return res.status(400).json({ error: 'Invalid amount.' });
  const now = new Date().toLocaleString('en-US');
  db.pendingRequests.unshift({ id: Date.now(), type: 'LOAN', userId: u.id, userName: u.name, amount: val, brand: (months || 12) + ' Months', date: now });
  u.transactions.unshift({ title: 'Credit Request (Pending)', amount: val, type: 'plus', date: now });
  saveDB(db); res.json({ user: u, message: 'Credit request submitted.' });
});

app.post('/api/kyc-submit', (req, res) => {
  const { userId, docType, docNumber, birthDate, country, docImageFront, docImageBack } = req.body, db = getDB(), u = db.users.find(x => x.id == userId);
  if (!u || !docNumber || String(docNumber).trim().length < 6) return res.status(400).json({ error: 'Invalid ID.' });
  const now = new Date().toLocaleString('en-US');
  u.kycStatus = 'VERIFIED';
  u.kycInfo = { docType: docType || 'ID / Passport', docNumber, birthDate, country, docImageFront: docImageFront || '', docImageBack: docImageBack || '', verifiedAt: now };
  u.transactions.unshift({ title: 'KYC Identity Verified âœ“', amount: 0, type: 'plus', date: now });
  saveDB(db); res.json({ user: u, message: 'Identity verified and archived in compliance center!' });
});
app.post('/api/transfer', (req, res) => {
  const { userId, target, amount, note } = req.body || {};
  // Cüzdan içi hızlı gönderim: yeni payload (userId+note) geldiyse doğrudan bu handler çalışır
  const db = getDB();
  const sender = db.users.find(x => String(x.id) === String(userId));
  if (!sender) return res.status(401).json({ error: 'Oturum bulunamadı.' });
  const val = parseFloat(amount);
  if (isNaN(val) || val <= 0) return res.status(400).json({ error: 'Geçerli bir tutar girin.' });
  const bal = sender.assets && sender.assets.USDT !== undefined ? Number(sender.assets.USDT) : 0;
  if (bal < val) return res.status(400).json({ error: 'Yetersiz bakiye. Mevcut: $' + bal.toFixed(2) });
  const key = String(target || '').trim().toLowerCase();
  const recv = db.users.find(x => x !== sender && (String(x.id) === String(target) || (x.email || '').toLowerCase() === key || (x.phone || '') === String(target)));
  if (!recv) return res.status(404).json({ error: 'Alıcı bulunamadı. ID, e-posta veya telefon numarasını kontrol edin.' });
  const now = new Date().toLocaleString('tr-TR');
  sender.assets.USDT = bal - val;
  sender.transactions = sender.transactions || [];
  sender.transactions.unshift({ title: '💸 Gönderim: ' + (recv.name || recv.email) + (note ? ' — ' + note : ''), amount: val, type: 'minus', date: now });
  recv.assets = recv.assets || { USDT: 0 };
  recv.assets.USDT = Number(recv.assets.USDT || 0) + val;
  recv.transactions = recv.transactions || [];
  recv.transactions.unshift({ title: '💰 Gelen: ' + (sender.name || sender.email) + (note ? ' — ' + note : ''), amount: val, type: 'plus', date: now });
  saveDB(db);
  res.json({ ok: true, user: sender, message: '✓ $' + val.toFixed(2) + ' ' + (recv.name || recv.email) + ' kişisine gönderildi.' });
});

app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  const db = getDB();
  if (username === SUPER_ADMIN_USER && password === SUPER_ADMIN_PASS) {
    return res.json({ ok: true, role: 'SUPER', adminName: 'atmaca (Süper Admin)', permissions: { requests: true, balance: true, cards: true, kyc: true, settings: true }, data: db });
  }
  const sub = (db.users || []).find(x => x.isAdmin && x.adminActive !== false && (String(x.email).toLowerCase() === String(username).toLowerCase() || String(x.id) === String(username)) && x.password === password);
  if (!sub) return res.status(401).json({ error: 'Hatalı yönetici kullanıcı adı veya şifre!' });
  res.json({ ok: true, role: 'OPERATOR', adminName: sub.name, permissions: sub.permissions || { requests: true, balance: false, cards: false, kyc: true, settings: false }, data: db });
});
app.post('/api/admin/staff-perm', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid || auth.role !== 'SUPER') return res.status(403).json({ error: 'Super Admin only!' });
  const { userId, permKey } = req.body, db = getDB(), u = db.users.find(x => x.id == userId);
  if (u) {
    if (!u.permissions) u.permissions = { requests: true, balance: false, cards: false, kyc: true, settings: false };
    u.permissions[permKey] = !u.permissions[permKey];
  }
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/toggle-role', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid || auth.role !== 'SUPER') return res.status(403).json({ error: 'Super Admin only!' });
  const db = getDB(), u = db.users.find(x => x.id == req.body.userId);
  if (u) u.isAdmin = !u.isAdmin;
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/kyc-toggle', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid) return res.status(401).end();
  const db = getDB(), u = db.users.find(x => x.id == req.body.userId);
  if (u) u.kycStatus = u.kycStatus === 'VERIFIED' ? 'UNVERIFIED' : 'VERIFIED';
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/approve', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid) return res.status(401).end();
  const db = getDB(), idx = db.pendingRequests.findIndex(x => x.id == req.body.requestId);
  if (idx === -1) return res.status(404).end();
  const item = db.pendingRequests[idx], u = db.users.find(x => x.id == item.userId), now = new Date().toLocaleString('en-US');
  if (u && req.body.decision === 'APPROVE') {
    if (item.type === 'DEPOSIT' || item.type === 'LOAN') {
      u.assets.USDT = (u.assets.USDT || 0) + item.amount;
      u.transactions.unshift({ title: 'Approved (+' + item.amount + ' USDT)', amount: item.amount, type: 'plus', date: now });
      sendBankEmail(u.email, 'Moopara Deposit Contract & Receipt (+$' + item.amount + ')', '<h2>Moopara Institutional Deposit Agreement</h2><p>Dear <b>' + u.name + '</b>, your deposit of <b>$' + item.amount + ' USDT</b> has been approved on ' + now + '.</p>');
    } else if (item.type === 'CARD') {
      const c = makeCard(item.brand);
      u.hasCard = true; u.cardBrand = c.cardBrand; u.cardNumber = c.cardNumber; u.cardExpiry = c.cardExpiry; u.cardCvv = c.cardCvv;
      u.transactions.unshift({ title: c.cardBrand + ' Card Activated', amount: item.amount, type: 'plus', date: now });
    } else if (item.type === 'WITHDRAW_IBAN') {
      u.transactions.unshift({ title: 'Bank IBAN Wire Completed âœ“', amount: item.amount, type: 'minus', date: now });
    }
  } else if (u && req.body.decision === 'REJECT' && item.type === 'WITHDRAW_IBAN') {
    u.assets.USDT = (u.assets.USDT || 0) + item.amount;
    u.transactions.unshift({ title: 'IBAN Withdrawal Refunded (+$' + item.amount + ')', amount: item.amount, type: 'plus', date: now });
  }
  db.pendingRequests.splice(idx, 1); saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/balance', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid) return res.status(401).end();
  const { userId, action, amount, coin } = req.body, db = getDB(), u = db.users.find(x => x.id == userId), c = coin || 'USDT';
  if (action === 'add') u.assets[c] = (u.assets[c] || 0) + parseFloat(amount);
  else if (action === 'reset') u.assets = { ...EMPTY_ASSETS };
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/card-manage', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid) return res.status(401).end();
  const { userId, mode, brand } = req.body, db = getDB(), u = db.users.find(x => x.id == userId);
  if (u) {
    if (mode === 'ISSUE') { const c = makeCard(brand); u.hasCard = true; u.cardBrand = c.cardBrand; u.cardNumber = c.cardNumber; u.cardExpiry = c.cardExpiry; u.cardCvv = c.cardCvv; }
    else { u.hasCard = false; u.cardNumber = null; u.cardExpiry = null; u.cardCvv = null; }
  }
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/settings', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid || auth.role !== 'SUPER') return res.status(403).json({ error: 'Super Admin only!' });
  const { newCardPrice, newDepositAddress, newLogoUrl, smsEdgeKey, smtpUser, smtpPass } = req.body, db = getDB();
  if (newCardPrice !== undefined && newCardPrice !== '') db.settings.cardPrice = parseFloat(newCardPrice);
  if (newDepositAddress) db.settings.depositAddress = newDepositAddress;
  if (newLogoUrl !== undefined) db.settings.logoUrl = newLogoUrl; if (req.body.seoTitle !== undefined) db.settings.seoTitle = req.body.seoTitle; if (req.body.seoDesc !== undefined) db.settings.seoDesc = req.body.seoDesc; if (req.body.seoKeys !== undefined) db.settings.seoKeys = req.body.seoKeys; if (req.body.officialBankName !== undefined) db.settings.officialBankName = req.body.officialBankName; if (req.body.officialBankHolder !== undefined) db.settings.officialBankHolder = req.body.officialBankHolder; if (req.body.officialBankIban !== undefined) db.settings.officialBankIban = req.body.officialBankIban; if (req.body.officialBankSwift !== undefined) db.settings.officialBankSwift = req.body.officialBankSwift;
  if (smsEdgeKey !== undefined) db.settings.smsEdgeKey = smsEdgeKey;
  if (smtpUser !== undefined) db.settings.smtpUser = smtpUser;
  if (smtpPass !== undefined) db.settings.smtpPass = smtpPass; if (req.body.whatsappNumber !== undefined) db.settings.whatsappNumber = req.body.whatsappNumber; if (req.body.whatsappEnabled !== undefined) db.settings.whatsappEnabled = !!req.body.whatsappEnabled; if (req.body.whatsappText !== undefined) db.settings.whatsappText = req.body.whatsappText;
  if (req.body.corporateApiKey !== undefined) db.settings.corporateApiKey = req.body.corporateApiKey;
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/staff-create', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid || auth.role !== 'SUPER') return res.status(403).json({ error: 'Super Admin only!' });
  const { name, email, password } = req.body, db = getDB();
  if (!name || !email || !password) return res.status(400).json({ error: 'TÃ¼m alanlarÄ± doldurun.' });
  if (db.users.find(u => u.email.toLowerCase() === email.toLowerCase())) return res.status(400).json({ error: 'Bu kullanÄ±cÄ± adÄ±/e-posta zaten kayÄ±tlÄ±.' });
  const newStaff = { id: Math.floor(1000000000 + Math.random() * 8999999999), name, email, password, isAdmin: true, adminActive: true, permissions: { requests: true, balance: false, cards: false, kyc: true, settings: false }, kycStatus: 'VERIFIED', assets: { ...EMPTY_ASSETS }, hasCard: false, transactions: [] };
  db.users.push(newStaff); saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/staff-toggle', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid || auth.role !== 'SUPER') return res.status(403).json({ error: 'Super Admin only!' });
  const db = getDB(), u = db.users.find(x => x.id == req.body.userId);
  if (u) {
    if (req.body.mode === 'DELETE') {
      db.users = db.users.filter(x => x.id != req.body.userId);
    } else {
      u.isAdmin = true;
      u.adminActive = (u.adminActive === false) ? true : false;
    }
  }
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/promote-user', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid || auth.role !== 'SUPER') return res.status(403).json({ error: 'Sadece Super Admin!' });
  const db = getDB(), u = db.users.find(x => x.id == req.body.userId);
  if (u) {
    u.isAdmin = true;
    u.adminActive = true;
    if (!u.permissions) u.permissions = { requests: true, balance: false, cards: false, kyc: true, settings: false };
  }
  saveDB(db);
  res.json({ data: db });
});

app.post('/api/admin/user-ban', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid) return res.status(401).end();
  const db = getDB(), u = db.users.find(x => x.id == req.body.userId);
  if (u) {
    if (req.body.mode === 'DELETE') db.users = db.users.filter(x => x.id != req.body.userId);
    else u.isBanned = !u.isBanned;
  }
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/staff-create', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid || auth.role !== 'SUPER') return res.status(403).json({ error: 'Super Admin only!' });
  const { name, email, password } = req.body, db = getDB();
  if (!name || !email || !password) return res.status(400).json({ error: 'TÃ¼m alanlarÄ± doldurun!' });
  if (db.users.find(u => u.email.toLowerCase() === email.toLowerCase())) return res.status(400).json({ error: 'Bu kullanÄ±cÄ± adÄ± kayÄ±tlÄ±!' });
  db.users.push({ id: Math.floor(1000000000 + Math.random() * 8999999999), name, email, password, isAdmin: true, adminActive: true, permissions: { requests: true, balance: false, cards: false, kyc: true, settings: false }, kycStatus: 'VERIFIED', assets: { ...EMPTY_ASSETS }, hasCard: false, transactions: [] });
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/staff-perm', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid || auth.role !== 'SUPER') return res.status(403).end();
  const { userId, permKey } = req.body, db = getDB(), u = db.users.find(x => x.id == userId);
  if (u) { if (!u.permissions) u.permissions = { requests: true, balance: false, cards: false, kyc: true, settings: false }; u.permissions[permKey] = !u.permissions[permKey]; }
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.post('/api/admin/staff-toggle', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid || auth.role !== 'SUPER') return res.status(403).end();
  const db = getDB(), u = db.users.find(x => x.id == req.body.userId);
  if (u) { if (req.body.mode === 'DELETE') db.users = db.users.filter(x => x.id != req.body.userId); else u.adminActive = (u.adminActive === false) ? true : false; }
  saveDB(db); addAuditLog(req.adminActor, 'Admin Ä°ÅŸlemi', req.path.replace('/api/admin/', '') + (req.body.userId ? ' (Hedef ID: ' + req.body.userId + ')' : '') + (req.body.amount ? ' | Tutar: ' + req.body.amount : '')); res.json({ data: db });
});

app.get('/api/public-settings', (req, res) => { const s = getDB().settings; res.json({ whatsappNumber: s.whatsappNumber || '12025550199', whatsappEnabled: s.whatsappEnabled !== false, whatsappText: s.whatsappText || 'Hello Moopara Support! I would like to get information about digital banking, virtual cards, and transfers.', officialBankName: s.officialBankName || 'Moopara Corporate Bank USA', officialBankHolder: s.officialBankHolder || 'Moopara Financial LLC', officialBankIban: s.officialBankIban || 'US89 MOOP 0001 9988 7766 55', officialBankSwift: s.officialBankSwift || 'TCZBTR2AXXX', cardPrice: s.cardPrice, depositAddress: s.depositAddress, logoUrl: s.logoUrl || '' }); });

app.post('/api/admin/assign-bank', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid) return res.status(401).end();
  const { userId, personalIban, personalTrc20 } = req.body, db = getDB(), u = db.users.find(x => x.id == userId);
  if (u) {
    if (personalIban) u.personalIban = personalIban.trim();
    if (personalTrc20) u.personalTrc20 = personalTrc20.trim();
  }
  saveDB(db);
  addAuditLog(req.adminActor, 'Ã–zel IBAN/CÃ¼zdan AtandÄ±', 'Hedef ID: ' + userId);
  res.json({ data: db });
});

// Admin: müşteri telefon / e-posta güncelleme
app.post('/api/admin/update-contact', (req, res) => {
  const auth = checkAdminAuth(req);
  if (!auth.valid) return res.status(401).end();
  const { userId, phone, email } = req.body, db = getDB(), u = db.users.find(x => x.id == userId);
  if (!u) return res.status(404).json({ error: 'Kullanıcı bulunamadı.' });
  if (phone !== undefined && phone !== null) {
    const digits = String(phone).replace(/[^0-9]/g, '');
    if (digits && digits.length < 10) return res.status(400).json({ error: 'Geçerli bir telefon numarası girin (en az 10 hane).' });
    if (digits) {
      const clash = db.users.find(x => x.id != u.id && String(x.phone || '').replace(/[^0-9]/g, '') === digits);
      if (clash) return res.status(400).json({ error: 'Bu telefon numarası başka bir hesaba kayıtlı: #' + clash.id });
    }
    u.phone = phone.trim();
  }
  if (email !== undefined && email !== null && String(email).trim() !== '') {
    const em = String(email).trim().toLowerCase();
    const clash2 = db.users.find(x => x.id != u.id && (x.email || '').toLowerCase() === em);
    if (clash2) return res.status(400).json({ error: 'Bu e-posta başka bir hesaba kayıtlı: #' + clash2.id });
    u.email = String(email).trim();
  }
  saveDB(db);
  addAuditLog(req.adminActor, 'İletişim Bilgisi Güncellendi', 'Hedef ID: ' + userId + (phone ? ' | Tel: ' + phone : '') + (email ? ' | E-posta: ' + email : ''));
  res.json({ ok: true, data: db });
});

app.get('/whatsapp-destek', (req, res) => {
  const s = getDB().settings;
  const num = String(s.whatsappNumber || '9955550003573').replace(/[^0-9]/g, '');
  const msg = encodeURIComponent(s.whatsappText || 'Hello Moopara Support!');
  const url = ['https:', '', '://whatsapp.com', 'send?phone=' + num + '&text=' + msg].join('/');
  res.send('<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0;url=' + url + '"></head><body>Redirecting to WhatsApp...</body></html>');
});

app.get('/go-whatsapp', (req, res) => {
  const s = getDB().settings;
  let num = String(s.whatsappNumber || '995555003573').replace(/[^0-9]/g, '');
  if (num.startsWith('9950')) num = '995' + num.slice(4);
  const msg = s.whatsappText || 'Hello Moopara Support!';
  res.send('<!DOCTYPE html><html><body style="font-family:sans-serif;text-align:center;padding:60px;"><h3>Connecting to WhatsApp Support...</h3><form id="wf" method="GET" action="https://whatsapp.com"><input type="hidden" name="phone" value="' + num + '"><input type="hidden" name="text" value="' + msg.replace(/"/g, '&quot;') + '"></form><script>document.getElementById("wf").submit();</script></body></html>');
});

/* ================= PAPARA BENZERÄ° KURUMSAL API SÄ°STEMÄ° ================= */
const MERCHANT_FEE_PCT = 1.5; // %1.5 komisyon

// Merchant Ã¶deme oluÅŸtur (API key ile)
// API anahtarı doğrulama: settings.corporateApiKey VEYA corporateMembers listesindeki herhangi bir aktif anahtar
function findApiKeyOwner(db, key) {
  if (!key) return null;
  if (db.settings.corporateApiKey === key) return { type: 'global' };
  const m = (db.corporateMembers || []).find(x => x.apiKey === key && x.status === 'ACTIVE');
  return m ? { type: 'member', member: m } : null;
}
app.post('/api/v1/payments', (req, res) => {
  const auth = req.headers['authorization'] || '';
  const key = auth.replace('Bearer ', '');
  const db = getDB();
  const owner = findApiKeyOwner(db, key);
  if (!owner) return res.status(401).json({ error: 'Invalid API key' });
  const { amount, currency, customer, callback, orderId } = req.body || {};
  const val = parseFloat(amount);
  if (isNaN(val) || val <= 0) return res.status(400).json({ error: 'Invalid amount' });
  const paymentId = 'pay_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  db.merchants = db.merchants || [];
  db.merchants.push({ id: paymentId, orderId: orderId || '', amount: val, currency: currency || 'USD', customer: customer || '', callback: callback || '', status: 'PENDING', fee: +(val * MERCHANT_FEE_PCT / 100).toFixed(2), net: +(val - val * MERCHANT_FEE_PCT / 100).toFixed(2), createdAt: new Date().toISOString() });
  saveDB(db);
  res.json({ ok: true, id: paymentId, status: 'PENDING', amount: val, currency: currency || 'USD', fee: +(val * MERCHANT_FEE_PCT / 100).toFixed(2), checkoutUrl: req.protocol + '://' + req.get('host') + '/checkout/' + paymentId });
});

app.get('/api/v1/payments/:id', (req, res) => {
  const auth = (req.headers['authorization'] || '').replace('Bearer ', '');
  const db = getDB();
  if (!findApiKeyOwner(db, auth)) return res.status(401).json({ error: 'Invalid API key' });
  const m = (db.merchants || []).find(x => x.id === req.params.id);
  if (!m) return res.status(404).json({ error: 'Not found' });
  res.json(m);
});

app.post('/api/v1/payout', (req, res) => {
  const auth = (req.headers['authorization'] || '').replace('Bearer ', '');
  const db = getDB();
  if (!findApiKeyOwner(db, auth)) return res.status(401).json({ error: 'Invalid API key' });
  const { amount, iban, customer } = req.body || {};
  const val = parseFloat(amount);
  if (isNaN(val) || val <= 0) return res.status(400).json({ error: 'Invalid amount' });
  const payoutId = 'po_' + Date.now().toString(36);
  db.payouts = db.payouts || [];
  db.payouts.push({ id: payoutId, amount: val, fee: +(val * MERCHANT_FEE_PCT / 100).toFixed(2), net: +(val - val * MERCHANT_FEE_PCT / 100).toFixed(2), iban: iban || '', customer: customer || '', status: 'PENDING', createdAt: new Date().toISOString() });
  saveDB(db);
  res.json({ id: payoutId, status: 'PENDING' });
});

app.get('/api/v1/balance', (req, res) => {
  const auth = (req.headers['authorization'] || '').replace('Bearer ', '');
  const db = getDB();
  if (!findApiKeyOwner(db, auth)) return res.status(401).json({ error: 'Invalid API key' });
  const ms = db.merchants || [];
  const gross = ms.filter(m => m.status === 'SUCCEEDED').reduce((a, m) => a + m.amount, 0);
  const fees = ms.filter(m => m.status === 'SUCCEEDED').reduce((a, m) => a + m.fee, 0);
  res.json({ gross: +gross.toFixed(2), fees: +fees.toFixed(2), net: +(gross - fees).toFixed(2), currency: 'USD' });
});

// Papara benzeri hosted checkout sayfasÄ±
app.get('/checkout/:id', (req, res) => {
  const db = getDB();
  const m = (db.merchants || []).find(x => x.id === req.params.id);
  if (!m) return res.status(404).send('Ã–deme bulunamadÄ±');
  res.send(`<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Ã–deme â€” Moopara Checkout</title><style>
    *{box-sizing:border-box;margin:0;padding:0;font-family:'Segoe UI',sans-serif}
    body{background:#0F172A;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:16px}
    .co{background:#fff;border-radius:24px;max-width:400px;width:100%;padding:28px}
    .brand{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
    .amt{font-size:36px;font-weight:800;margin:8px 0 2px}
    .muted{color:#64748B;font-size:13px}
    .pay-btn{width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#00A2C7,#007799);color:#fff;font-size:15px;font-weight:800;cursor:pointer;margin-top:16px}
    .sec{display:grid;gap:8px;margin-top:14px}
    .opt{border:1.5px solid #E2E8F0;border-radius:14px;padding:12px 14px;display:flex;justify-content:space-between;align-items:center;cursor:pointer;font-weight:700;font-size:13px}
    .opt.sel{border-color:#00A2C7;background:#E0F7FA}
    .ok{background:#ECFDF5;color:#065F46;padding:14px;border-radius:14px;text-align:center;font-weight:800;margin-top:14px}
  </style></head><body><div class="co">
    <div class="brand"><b style="font-size:17px;">Sofi<span style="color:#0284C7">Swift</span></b><span style="font-size:11px;color:#94A3B8;">ğŸ”’ GÃ¼venli Ã–deme</span></div>
    <div class="muted">Ã–denecek Tutar</div>
    <div class="amt">$${m.amount.toFixed(2)}</div>
    <div class="muted">SipariÅŸ: ${m.orderId || m.id}</div>
    <div class="sec">
      <div class="opt sel" id="o-wallet" onclick="sel(this,'wallet')">ğŸ¦ Moopara CÃ¼zdanÄ±m <span style="color:#64748B;font-size:11px;">HÄ±zlÄ±</span></div>
      <div class="opt" id="o-card" onclick="sel(this,'card')">ğŸ’³ Kredi / Banka KartÄ±</div>
      <div class="opt" id="o-transfer" onclick="sel(this,'transfer')">ğŸ” Havale / EFT</div>
    </div>
    <div id="st"></div>
    <button class="pay-btn" onclick="pay()">$${m.amount.toFixed(2)} Ã–de</button>
    <div style="margin-top:12px;text-align:center;font-size:11px;color:#94A3B8;">SSL 256-bit ÅŸifreleme ile korunur</div>
  </div><script>
    var mode='wallet';
    function sel(el,m){document.querySelectorAll('.opt').forEach(o=>o.classList.remove('sel'));el.classList.add('sel');mode=m;}
    function pay(){
      document.getElementById('st').innerHTML='<div class="ok" id="pp">Ä°ÅŸlem gerÃ§ekleÅŸtiriliyor...</div>';
      fetch('/checkout/${m.id}/confirm',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({method:mode})})
      .then(r=>r.json()).then(d=>{
        if(d.ok){document.getElementById('pp').innerHTML='âœ… Ã–deme baÅŸarÄ±lÄ±! YÃ¶nlendiriliyorsunuz...';
        ${m.callback ? `setTimeout(function(){location.href='${m.callback}?payment=${m.id}&status=success'},1500);` : "setTimeout(function(){document.getElementById('pp').innerHTML='âœ… Ã–deme baÅŸarÄ±lÄ±! Bu sekmeyi kapatabilirsiniz.'},1500);"}
        } else { document.getElementById('pp').innerHTML='âŒ '+ (d.error||'Hata'); }
      });
    }
  </script></body></html>`);
});

app.post('/checkout/:id/confirm', (req, res) => {
  const db = getDB();
  const m = (db.merchants || []).find(x => x.id === req.params.id);
  if (!m) return res.status(404).json({ ok: false });
  if (m.status === 'SUCCEEDED') return res.json({ ok: true });
  m.status = 'SUCCEEDED'; m.method = req.body.method || 'wallet'; m.paidAt = new Date().toISOString();
  saveDB(db);
  // Webhook bildirimi (async fire-and-forget)
  if (m.callback) { fetch(m.callback, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ event: 'payment.succeeded', id: m.id, amount: m.amount, orderId: m.orderId }) }).catch(() => {}); }
  res.json({ ok: true });
});

app.get('/api/v1/transactions', (req, res) => {
  const auth = (req.headers['authorization'] || '').replace('Bearer ', '');
  const db = getDB();
  if (!findApiKeyOwner(db, auth)) return res.status(401).json({ error: 'Invalid API key' });
  res.json({ payments: db.merchants || [], payouts: db.payouts || [] });
});

/* ---------- Kurumsal Üye (Merchant) Paneli ---------- */
app.post('/api/merchant/register', (req, res) => {
  const { companyName, email, password, website } = req.body || {};
  if (!companyName || !email || !password || String(password).length < 6) return res.status(400).json({ error: 'Şirket adı, e-posta ve en az 6 haneli şifre zorunludur.' });
  const db = getDB();
  db.corporateMembers = db.corporateMembers || [];
  if (db.corporateMembers.some(m => m.email.toLowerCase() === String(email).toLowerCase())) return res.status(409).json({ error: 'Bu e-posta ile kayıtlı kurumsal üye zaten var.' });
  const apiKey = 'mp_live_' + crypto.randomBytes(24).toString('hex');
  const member = { id: 'cmp_' + Date.now().toString(36), companyName, email, password, website: website || '', apiKey, status: 'ACTIVE', createdAt: new Date().toISOString() };
  db.corporateMembers.push(member); saveDB(db);
  addAuditLog('Kurumsal Üye', 'Yeni Kurumsal Kayıt', companyName + ' (' + email + ')');
  res.json({ ok: true, member: { id: member.id, companyName, email, apiKey } });
});

app.post('/api/merchant/login', (req, res) => {
  const { email, password } = req.body || {};
  const db = getDB();
  const m = (db.corporateMembers || []).find(x => x.email.toLowerCase() === String(email || '').toLowerCase() && x.password === password);
  if (!m) return res.status(401).json({ error: 'Geçersiz kurumsal giriş bilgileri.' });
  res.json({ ok: true, member: { id: m.id, companyName: m.companyName, email: m.email, apiKey: m.apiKey, website: m.website, status: m.status } });
});

app.get('/api/merchant/dashboard', (req, res) => {
  const auth = (req.headers['authorization'] || '').replace('Bearer ', '');
  const db = getDB();
  const m = (db.corporateMembers || []).find(x => x.apiKey === auth);
  if (!m) return res.status(401).json({ error: 'Yetkisiz' });
  const all = db.merchants || [];
  const pays = all.filter(p => p.companyEmail === m.email || !p.companyEmail);
  const ok = pays.filter(p => p.status === 'SUCCEEDED');
  const gross = ok.reduce((a, p) => a + p.amount, 0), fees = ok.reduce((a, p) => a + (p.fee || 0), 0);
  res.json({ member: { companyName: m.companyName, email: m.email, apiKey: m.apiKey, website: m.website }, stats: { total: pays.length, succeeded: ok.length, gross: +gross.toFixed(2), fees: +fees.toFixed(2), net: +(gross - fees).toFixed(2), currency: 'USD' }, payments: pays.slice(-50).reverse(), payouts: (db.payouts || []).slice(-20).reverse() });
});

// Kurumsal üye: moopara ile ödeme talebi oluştur (panelden)
app.post('/api/merchant/create-payment', (req, res) => {
  const auth = (req.headers['authorization'] || '').replace('Bearer ', '');
  const db = getDB();
  const m = (db.corporateMembers || []).find(x => x.apiKey === auth);
  if (!m) return res.status(401).json({ error: 'Yetkisiz' });
  const { amount, orderId, customer } = req.body || {};
  const val = parseFloat(amount);
  if (isNaN(val) || val <= 0) return res.status(400).json({ error: 'Geçersiz tutar.' });
  db.merchants = db.merchants || [];
  const paymentId = 'pay_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  db.merchants.push({ id: paymentId, orderId: orderId || '', amount: val, currency: 'USD', customer: customer || '', companyEmail: m.email, companyName: m.companyName, status: 'PENDING', fee: +(val * MERCHANT_FEE_PCT / 100).toFixed(2), net: +(val - val * MERCHANT_FEE_PCT / 100).toFixed(2), createdAt: new Date().toISOString() });
  saveDB(db);
  res.json({ ok: true, id: paymentId, checkoutUrl: req.protocol + '://' + req.get('host') + '/checkout/' + paymentId });
});



// === MO PARA ADMIN API BRIDGE ===
app.get('/api/admin/data', (req, res) => {
  const db = JSON.parse(fs.readFileSync('database.json', 'utf8'));
  res.json({ users: db.users || [], requests: db.requests || [], staff: db.staff || [{ username: 'atmaca', role: 'SUPER_ADMIN' }], logs: db.logs || [], settings: db.settings || {} });
});
app.post('/api/admin/balance', (req, res) => {
  const db = JSON.parse(fs.readFileSync('database.json', 'utf8'));
  const u = (db.users || []).find(x => String(x.id) === String(req.body.userId));
  if (u) {
    u.assets = u.assets || { USDT: 0 };
    u.assets.USDT = Math.max(0, (Number(u.assets.USDT) || 0) + Number(req.body.amount || 0));
    u.transactions = u.transactions || [];
    u.transactions.unshift({ title: req.body.amount >= 0 ? 'YÃ¶netici Bakiye Ekleme' : 'YÃ¶netici Bakiye DÃ¼ÅŸme', amount: Math.abs(Number(req.body.amount)), type: req.body.amount >= 0 ? 'plus' : 'minus', date: new Date().toLocaleString() });
    fs.writeFileSync('database.json', JSON.stringify(db, null, 2));
  }
  res.json({ ok: true });
});
app.post('/api/admin/toggle-card', (req, res) => {
  const db = JSON.parse(fs.readFileSync('database.json', 'utf8'));
  const u = (db.users || []).find(x => String(x.id) === String(req.body.userId));
  if (u) {
    u.hasCard = !u.hasCard;
    if (u.hasCard && !u.cardNumber) {
      u.cardBrand = 'MASTERCARD';
      u.cardNumber = '5392 ' + Math.floor(1000+Math.random()*9000) + ' ' + Math.floor(1000+Math.random()*9000) + ' ' + Math.floor(1000+Math.random()*9000);
      u.cardExpiry = '09/29'; u.cardCvv = String(Math.floor(100+Math.random()*900));
    }
    fs.writeFileSync('database.json', JSON.stringify(db, null, 2));
  }
  res.json({ ok: true });
});
app.post('/api/admin/delete-user', (req, res) => {
  const db = JSON.parse(fs.readFileSync('database.json', 'utf8'));
  db.users = (db.users || []).filter(x => String(x.id) !== String(req.body.userId));
  fs.writeFileSync('database.json', JSON.stringify(db, null, 2));
  res.json({ ok: true });
});
app.post('/api/admin/kyc-action', (req, res) => {
  const db = JSON.parse(fs.readFileSync('database.json', 'utf8'));
  const u = (db.users || []).find(x => String(x.id) === String(req.body.userId));
  if (u) { u.kycStatus = req.body.status; fs.writeFileSync('database.json', JSON.stringify(db, null, 2)); }
  res.json({ ok: true });
});
app.post('/api/admin/request-action', (req, res) => {
  const db = JSON.parse(fs.readFileSync('database.json', 'utf8'));
  const q = (db.requests || []).find(x => String(x.id) === String(req.body.requestId));
  if (q) {
    q.status = req.body.action === 'approve' ? 'APPROVED' : 'REJECTED';
    if (req.body.action === 'approve' && q.type === 'DEPOSIT') {
      const u = (db.users || []).find(x => String(x.id) === String(q.userId));
      if (u) { u.assets = u.assets || {}; u.assets.USDT = (Number(u.assets.USDT) || 0) + Number(q.amount); }
    }
    fs.writeFileSync('database.json', JSON.stringify(db, null, 2));
  }
  res.json({ ok: true });
});
app.post('/api/admin/settings', (req, res) => {
  const db = JSON.parse(fs.readFileSync('database.json', 'utf8'));
  db.settings = Object.assign(db.settings || {}, req.body);
  fs.writeFileSync('database.json', JSON.stringify(db, null, 2));
  res.json({ ok: true });
});

app.get('/api/admin-panel-full', (req, res) => {
  const db = getDB();
  res.json({ users: db.users || [], requests: db.pendingRequests || [], logs: db.auditLogs || [], settings: db.settings || {}, corporateMembers: db.corporateMembers || [] });
});
app.post('/api/admin-telegram-test', async (req, res) => {
  const r = await sendTelegram('✅ <b>Moopara test bildirimi</b> — Telegram entegrasyonu çalışıyor!', 'TEST');
  if (r.sent) return res.json({ ok: true });
  if (r.reason === 'not-configured') return res.json({ ok: false, error: 'Bot Token ve Chat ID girin.' });
  res.json({ ok: false, error: 'Telegram API hatası — token/chatId doğrulayın.' });
});
app.post('/api/admin-panel-action', (req, res) => {
  const { type, userId, amount, requestId, status, settings, corpId } = req.body;
  const db = getDB();
  if (type === 'balance') {
    const u = (db.users || []).find(x => String(x.id) === String(userId));
    if (u) {
      u.assets = u.assets || { TRY: 0 };
      const cur = u.assets.TRY !== undefined ? Number(u.assets.TRY) : Number(u.assets.USDT || 0);
      const next = Math.max(0, cur + Number(amount || 0));
      u.assets.TRY = next; u.assets.USDT = next;
      u.transactions = u.transactions || [];
      u.transactions.unshift({ title: amount >= 0 ? 'YÃ¶netici TL Bakiye Ekleme' : 'YÃ¶netici TL Bakiye DÃ¼ÅŸme', amount: Math.abs(Number(amount)), type: amount >= 0 ? 'plus' : 'minus', date: new Date().toLocaleString('tr-TR') });
    }
  } else if (type === 'card') {
    const u = (db.users || []).find(x => String(x.id) === String(userId));
    if (u) { u.hasCard = !u.hasCard; if (u.hasCard && !u.cardNumber) Object.assign(u, makeCard('MASTERCARD')); }
  } else if (type === 'staff') {
    const u = (db.users || []).find(x => String(x.id) === String(userId));
    if (u) { u.isAdmin = !u.isAdmin; u.adminActive = u.isAdmin; }
  } else if (type === 'delete') {
    db.users = (db.users || []).filter(x => String(x.id) !== String(userId));
  } else if (type === 'kyc') {
    const u = (db.users || []).find(x => String(x.id) === String(userId));
    if (u) u.kycStatus = status;
  } else if (type === 'request') {
    const q = (db.pendingRequests || []).find(x => String(x.id) === String(requestId));
    if (q) {
      q.status = status;
      const u = (db.users || []).find(x => String(x.id) === String(q.userId));
      if (u && status === 'APPROVED' && q.type === 'DEPOSIT') {
        const cur = u.assets.TRY !== undefined ? Number(u.assets.TRY) : Number(u.assets.USDT || 0);
        u.assets.TRY = cur + Number(q.amount); u.assets.USDT = u.assets.TRY;
        u.transactions.unshift({ title: 'OnaylÄ± TL Para YatÄ±rma', amount: q.amount, type: 'plus', date: new Date().toLocaleString('tr-TR') });
      }
    }
  } else if (type === 'corp-toggle') {
    const m = (db.corporateMembers || []).find(x => x.id === corpId);
    if (m) m.status = m.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
  } else if (type === 'corp-regen') {
    const m = (db.corporateMembers || []).find(x => x.id === corpId);
    if (m) m.apiKey = 'mp_live_' + crypto.randomBytes(24).toString('hex');
  } else if (type === 'api-create') {
    // Admin: site URL + isim ile yeni API anahtarı oluştur
    const { siteName, siteUrl, contactEmail } = req.body;
    if (!siteName || !siteUrl) return res.status(400).json({ error: 'Site adı ve URL zorunlu.' });
    db.corporateMembers = db.corporateMembers || [];
    const key = 'mp_live_' + crypto.randomBytes(24).toString('hex');
    db.corporateMembers.push({ id: 'corp_' + Date.now().toString(36), companyName: siteName, website: siteUrl, email: contactEmail || ('admin@' + String(siteUrl).replace(/^https?:\/\//, '').replace(/\/.*/, '')), apiKey: key, status: 'ACTIVE', createdAt: new Date().toISOString(), createdBy: 'admin' });
    saveDB(db);
    return res.json({ ok: true, apiKey: key });
  } else if (type === 'api-delete') {
    db.corporateMembers = (db.corporateMembers || []).filter(x => x.id !== corpId);
  } else if (type === 'settings' && settings) {
    db.settings = Object.assign(db.settings || {}, settings);
  }
  saveDB(db);
  res.json({ ok: true });
});
app.post('/api/fx-action', (req, res) => {
  const { userId, action, sym, tlAmount, rate } = req.body;
  const db = getDB();
  const u = (db.users || []).find(x => String(x.id) === String(userId));
  if (!u) return res.status(404).json({ error: 'KullanÄ±cÄ± bulunamadÄ±.' });
  u.openedFx = u.openedFx || [];
  u.assets = u.assets || { TRY: 0 };
  if (u.assets.TRY === undefined) u.assets.TRY = Number(u.assets.USDT || 0);
  if (action === 'open') {
    if (!u.openedFx.includes(sym)) u.openedFx.push(sym);
    saveDB(db);
    return res.json({ ok: true, user: u });
  } else if (action === 'buy') {
    const tl = Number(tlAmount);
    if (u.assets.TRY < tl) return res.status(400).json({ error: 'Yetersiz TÃ¼rk LirasÄ± (â‚º) bakiyesi!' });
    const bought = tl / Number(rate);
    u.assets.TRY -= tl; u.assets.USDT = u.assets.TRY;
    u.assets[sym] = (Number(u.assets[sym]) || 0) + bought;
    u.transactions = u.transactions || [];
    u.transactions.unshift({ title: 'DÃ¶viz AlÄ±mÄ±: ' + bought.toFixed(2) + ' ' + sym, amount: tl, type: 'minus', date: new Date().toLocaleString('tr-TR') });
    saveDB(db);
    return res.json({ ok: true, user: u, message: bought.toFixed(2) + ' ' + sym + ' baÅŸarÄ±yla dÃ¶viz hesabÄ±nÄ±za aktarÄ±ldÄ±!' });
  }
});
/* ================= DÖİZ (FX) HESAP SİSTEMİ ================= */
function getFxRates() {
  // Canlı kur: exchangerate.host yoksa sabit fallback. Cache 5 dk.
  if (!getFxRates.cache || Date.now() - getFxRates.cache.at > 300000) {
    getFxRates.cache = { at: Date.now(), rates: { USD: 34.20, EUR: 36.80, GBP: 43.10 } };
    fetch('https://api.exchangerate.host/latest?base=TRY&symbols=USD,EUR,GBP')
      .then(r => r.json()).then(d => {
        if (d && d.rates && d.rates.USD) getFxRates.cache = { at: Date.now(), rates: { USD: 1 / d.rates.USD, EUR: 1 / d.rates.EUR, GBP: 1 / d.rates.GBP } };
      }).catch(() => {});
  }
  return getFxRates.cache.rates;
}
app.get('/api/fx-rates', (req, res) => res.json(getFxRates()));
app.post('/api/fx-exchange', (req, res) => {
  const { userId, from, to, amount } = req.body || {}, db = getDB();
  const u = db.users.find(x => String(x.id) === String(userId));
  if (!u) return res.status(401).json({ error: 'Oturum bulunamadı.' });
  const fromCur = (from || 'TRY').toUpperCase(), toCur = (to || 'USD').toUpperCase();
  const val = parseFloat(amount);
  if (isNaN(val) || val <= 0) return res.status(400).json({ error: 'Geçerli bir tutar girin.' });
  if (fromCur === toCur) return res.status(400).json({ error: 'Aynı para birimleri arasında dönüşüm yapılamaz.' });
  u.assets = u.assets || { ...EMPTY_ASSETS };
  const bal = Number(u.assets[fromCur] || 0);
  if (bal < val) return res.status(400).json({ error: 'Yetersiz ' + fromCur + ' bakiyesi. Mevcut: ' + bal.toFixed(2) });
  const rates = getFxRates();
  const TRYAMT = fromCur === 'TRY' ? val : val * rates[fromCur];
  const got = toCur === 'TRY' ? TRYAMT : TRYAMT / rates[toCur];
  u.assets[fromCur] = bal - val;
  u.assets[toCur] = (Number(u.assets[toCur] || 0)) + +got.toFixed(2);
  u.transactions = u.transactions || [];
  u.transactions.unshift({ title: 'Döviz: ' + val.toFixed(2) + ' ' + fromCur + ' → ' + got.toFixed(2) + ' ' + toCur, amount: val, type: 'minus', date: new Date().toLocaleString('tr-TR') });
  saveDB(db);
  res.json({ ok: true, user: u, message: '✓ ' + val.toFixed(2) + ' ' + fromCur + ' → ' + got.toFixed(2) + ' ' + toCur + ' dönüştürüldü.' });
});

app.listen(PORT, '0.0.0.0', () => console.log('mo para Aktif: http://localhost:' + PORT));
setInterval(() => {}, 60000);

























