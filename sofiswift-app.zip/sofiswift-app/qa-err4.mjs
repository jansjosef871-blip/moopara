export default async function run(page, ui) {
  const res = {};
  res.errs = [];
  page.on('pageerror', e => res.errs.push(String(e).slice(0, 400)));
  res.probe = await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=blob2', { cache: 'no-store' })).text();
    // find a minimal reproducible chunk: try executing in fresh script tag with error listener
    return new Promise(resolve => {
      const handler = e => { resolve({ err: e.message, line: e.lineno, col: e.colno, file: e.filename }); };
      window.addEventListener('error', handler, { once: true });
      const s = document.createElement('script');
      s.src = '/app.js?v=blob2&nocache=' + Math.random();
      document.body.appendChild(s);
      setTimeout(() => resolve({ err: 'no error fired', setAuth: typeof window.setAuthMode, ctx: window.__lastErr || null }), 3000);
    });
  });
  return res;
}
