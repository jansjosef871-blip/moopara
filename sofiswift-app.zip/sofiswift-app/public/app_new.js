let currentUser = null, isRegisterMode = false;
let appSettings = { cardPrice: 20, depositAddress: 'TX9aK8pL2mQ7vR4wN1zB6cJ3yH5fD8sG0e' };
let prices = { USDT: 1, USDC: 1, BTC: 91500, ETH: 3120, SOL: 210, TRX: 0.25, XRP: 1.15, BNB: 620, ADA: 0.75, AVAX: 38 };
const COINS = [
  { sym: 'USDT', name: 'Tether USD', bg: '#10B981', txt: 'T' },
  { sym: 'USDC', name: 'USD Coin', bg: '#2563EB', txt: '$' },
  { sym: 'BTC', name: 'Bitcoin', bg: '#F59E0B', txt: 'B' },
  { sym: 'ETH', name: 'Ethereum', bg: '#6366F1', txt: 'E' },
  { sym: 'SOL', name: 'Solana', bg: '#14B8A6', txt: 'S' },
  { sym: 'TRX', name: 'TRON', bg: '#EF4444', txt: 'T' },
  { sym: 'XRP', name: 'Ripple', bg: '#0EA5E9', txt: 'X' },
  { sym: 'BNB', name: 'BNB Chain', bg: '#EAB308', txt: 'B' },
  { sym: 'ADA', name: 'Cardano', bg: '#1D4ED8', txt: 'A' },
  { sym: 'AVAX', name: 'Avalanche', bg: '#E11D48', txt: 'V' }
];
const ALL_COUNTRIES = ["United States", "Turkey", "Georgia", "Germany", "United Kingdom", "France", "Netherlands", "Switzerland", "United Arab Emirates", "Saudi Arabia", "Qatar", "Azerbaijan", "Russia", "Ukraine", "Kazakhstan", "Uzbekistan", "Turkmenistan", "Kyrgyzstan", "Tajikistan", "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Argentina", "Armenia", "Australia", "Austria", "Bahrain", "Bangladesh", "Belarus", "Belgium", "Bosnia and Herzegovina", "Brazil", "Bulgaria", "Canada", "Chile", "China", "Colombia", "Croatia", "Cyprus", "Czech Republic", "Denmark", "Egypt", "Estonia", "Finland", "Greece", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Japan", "Jordan", "Kenya", "Kuwait", "Latvia", "Lebanon", "Libya", "Lithuania", "Luxembourg", "Malaysia", "Malta", "Mexico", "Moldova", "Monaco", "Montenegro", "Morocco", "New Zealand", "Nigeria", "North Macedonia", "Norway", "Oman", "Pakistan", "Palestine", "Peru", "Philippines", "Poland", "Portugal", "Romania", "Serbia", "Singapore", "Slovakia", "Slovenia", "South Africa", "South Korea", "Spain", "Sweden", "Syria", "Taiwan", "Thailand", "Tunisia", "Vietnam", "Yemen"];

/* ---------- UI helpers ---------- */
function openModal(id) {
  if (id === 'deposit-modal' && currentUser) {
    const isCustomTrc = currentUser.personalTrc20 && !currentUser.personalTrc20.startsWith('TTZ');
    const activeTrc = isCustomTrc ? currentUser.personalTrc20 : appSettings.depositAddress;
    const wBox = document.getElementById('deposit-wallet-box'); if (wBox) wBox.innerText = activeTrc;
    setQr('dep-qr-box', activeTrc);
    const isCustomIban = currentUser.personalIban && !currentUser.personalIban.startsWith('US64 SOFI');
    const activeIban = isCustomIban ? currentUser.personalIban : (appSettings.officialBankIban || 'US89 SOFI 0001 9988 7766 55');
    if (document.getElementById('dep-bank-name')) document.getElementById('dep-bank-name').innerText = appSettings.officialBankName || 'SofiSwift Corporate Bank USA';
    if (document.getElementById('dep-bank-holder')) document.getElementById('dep-bank-holder').innerText = appSettings.officialBankHolder || 'SofiSwift Financial LLC';
    if (document.getElementById('dep-bank-swift')) document.getElementById('dep-bank-swift').innerText = (appSettings.officialBankSwift || 'SOFIUS33XXX') + '  |  REF: ID-' + currentUser.id;
    if (document.getElementById('dep-bank-iban')) document.getElementById('dep-bank-iban').innerText = activeIban;
  }
  const el = document.getElementById(id); if (el) el.classList.remove('hidden');
}
function closeModal(id) { const el = document.getElementById(id); if (el) el.classList.add('hidden'); }
function toggleDrawer(open) {
  const bd = document.getElementById('drawer-backdrop'), dr = document.getElementById('side-drawer');
  if (bd) bd.classList.toggle('hidden', !open);
  if (dr) dr.classList.toggle('open', open);
}
function showBanner(msg, isErr) {
  const b = document.getElementById('alert-box'); if (!b || !msg) return;
  b.innerText = msg; b.className = 'banner ' + (isErr ? 'banner-err' : 'banner-ok'); b.classList.remove('hidden');
  setTimeout(() => b.classList.add('hidden'), 6000);
}
function showMainView(v) {
  const dash = document.getElementById('user-dashboard'), card = document.getElementById('card-control-view');
  if (dash) dash.classList.toggle('hidden', v !== 'dashboard');
  if (card) card.classList.toggle('hidden', v !== 'card');
  toggleDrawer(false);
  window.scrollTo(0, 0);
}
function switchDepositTab(tab) {
  const isCrypto = (tab === 'crypto');
  document.getElementById('dep-pane-crypto').classList.toggle('hidden', !isCrypto);
  document.getElementById('dep-pane-bank').classList.toggle('hidden', isCrypto);
  const bC = document.getElementById('dep-tab-crypto'), bB = document.getElementById('dep-tab-bank');
  bC.style.background = isCrypto ? '#0F172A' : 'transparent'; bC.style.color = isCrypto ? '#FFFFFF' : '#475569';
  bB.style.background = !isCrypto ? '#0F172A' : 'transparent'; bB.style.color = !isCrypto ? '#FFFFFF' : '#475569';
}

/* ---------- Auth ---------- */
function switchMode() {
  isRegisterMode = !isRegisterMode;
  document.getElementById('name-field').classList.toggle('hidden', !isRegisterMode);
  document.getElementById('auth-title').innerText = isRegisterMode ? 'Open Free Account' : 'Sign In to Your Account';
  document.getElementById('auth-btn-text').innerText = isRegisterMode ? 'Create My Account' : 'Secure Sign In';
  document.getElementById('toggle-auth-btn').innerText = isRegisterMode ? "Already have an account? Sign In" : "Don't have an account? Open Free Account";
}
async function doAuth() {
  const name = document.getElementById('auth-name').value.trim();
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-pass').value.trim();
  const err = document.getElementById('auth-error'); err.classList.add('hidden');
  if (isRegisterMode && !name) { err.innerText = 'Please enter your full name.'; err.classList.remove('hidden'); return; }
  if (!email || !password) { err.innerText = 'Please enter email and password.'; err.classList.remove('hidden'); return; }
  try {
    const r = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, email, password, isRegister: isRegisterMode }) });
    const d = await r.json();
    if (!r.ok) { err.innerText = d.error || 'Error'; err.classList.remove('hidden'); return; }
    currentUser = d.user; appSettings = d.settings || appSettings; prices = d.prices || prices;
    enterApp();
  } catch (e) { err.innerText = 'Connection error. Please try again.'; err.classList.remove('hidden'); }
}
function enterApp() {
  document.getElementById('auth-section').classList.add('hidden');
  document.getElementById('user-dashboard').classList.remove('hidden');
  const nav = document.getElementById('nav-user-actions'); if (nav) nav.classList.remove('hidden');
  const mb = document.getElementById('menu-open-btn'); if (mb) mb.classList.remove('hidden');
  document.querySelectorAll('.price-tag').forEach(el => el.innerText = appSettings.cardPrice);
  updateDashboard();
}
function logout() {
  currentUser = null; isRegisterMode = false;
  document.getElementById('user-dashboard').classList.add('hidden');
  const card = document.getElementById('card-control-view'); if (card) card.classList.add('hidden');
  const nav = document.getElementById('nav-user-actions'); if (nav) nav.classList.add('hidden');
  const mb = document.getElementById('menu-open-btn'); if (mb) mb.classList.add('hidden');
  toggleDrawer(false);
  document.getElementById('auth-section').classList.remove('hidden');
}

/* ---------- QR & copy ---------- */
function setQr(boxId, text) {
  const b = document.getElementById(boxId);
  if (b) b.innerHTML = '<img src="/api/qr?text=' + encodeURIComponent(text) + '" style="width:155px;height:155px;border-radius:12px;border:1px solid #E2E8F0;padding:6px;background:white;" />';
}
function copyAddress() {
  const cc = document.getElementById('cc-wallet-addr');
  const txt = (cc && !cc.closest('#cc-payment-details').classList.contains('hidden')) ? cc.innerText
    : (document.getElementById('deposit-wallet-box') ? document.getElementById('deposit-wallet-box').innerText : appSettings.depositAddress);
  navigator.clipboard.writeText(txt);
  alert('Wallet address copied!');
}

/* ---------- Dashboard render ---------- */
function updateDashboard() {
  if (!currentUser) return;
  const a = currentUser.assets || {};
  let totalUsd = 0;
  COINS.forEach(c => { totalUsd += (a[c.sym] || 0) * (prices[c.sym] || 0); });
  const fmt = '$' + totalUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  document.getElementById('user-balance').innerText = fmt;
  document.getElementById('drawer-user-bal').innerText = fmt;
  document.getElementById('drawer-user-name').innerText = currentUser.name;
  document.getElementById('drawer-user-id').innerText = 'ID: ' + currentUser.id;

  const isVer = (currentUser.kycStatus === 'VERIFIED');
  document.getElementById('nav-username').innerHTML = currentUser.name + ' <span style="background:#E0F2FE;color:#0369A1;padding:3px 8px;border-radius:8px;">ID: ' + currentUser.id + '</span> <span style="background:' + (isVer ? '#D1FAE5;color:#065F46' : '#FEF3C7;color:#B45309') + ';padding:3px 8px;border-radius:8px;font-size:11px;font-weight:800;">' + (isVer ? 'OK KYC' : 'KYC!') + '</span>';

  const holder = currentUser.name.toUpperCase();
  const cn = document.getElementById('card-holder-name'); if (cn) cn.innerText = holder;
  document.getElementById('card-brand-logo').innerText = currentUser.hasCard ? currentUser.cardBrand : 'VISA';
  document.getElementById('card-num-text').innerText = currentUser.hasCard ? currentUser.cardNumber : '**** **** **** ****';
  const badge = document.getElementById('badge-card');
  if (badge) {
    badge.innerText = currentUser.hasCard ? currentUser.cardBrand + ' Active' : 'Card Locked';
    badge.className = 'status-pill ' + (currentUser.hasCard ? 'pill-active' : 'pill-locked');
  }
  const lock = document.getElementById('card-lock-cover');
  if (lock) lock.classList.toggle('hidden', !!currentUser.hasCard);

  document.getElementById('live-crypto-list').innerHTML = COINS.map(c => {
    const qty = a[c.sym] || 0, usd = qty * (prices[c.sym] || 0);
    return '<div class="list-item"><div style="display:flex;align-items:center;gap:12px;"><div style="width:34px;height:34px;border-radius:50%;background:' + c.bg + ';color:white;display:flex;align-items:center;justify-content:center;font-weight:800;">' + c.txt + '</div><div><div style="font-weight:800;font-size:14px;">' + c.sym + ' <span style="font-weight:500;color:#64748B;font-size:12px;">($' + (prices[c.sym] || 0).toLocaleString('en-US') + ')</span></div><div style="font-size:12px;color:#64748B;">' + c.name + '</div></div></div><div style="text-align:right;"><div style="font-weight:800;font-size:14px;">' + qty.toLocaleString('en-US', { maximumFractionDigits: 5 }) + ' ' + c.sym + '</div><div style="font-size:12px;color:#64748B;">$' + usd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '</div></div></div>';
  }).join('');

  const txs = currentUser.transactions || [];
  document.getElementById('tx-history').innerHTML = txs.length === 0 ? '<p style="color:#94A3B8;font-size:13px;">No transactions yet.</p>' : txs.map(t => '<div class="tx-row"><div><div style="font-weight:700;font-size:14px;">' + t.title + '</div><div style="font-size:11px;color:#94A3B8;">' + t.date + '</div></div><div style="font-weight:800;color:' + (t.type === 'plus' ? '#10B981' : '#EF4444') + ';">' + (t.type === 'plus' ? '+' : '-') + '$' + Number(t.amount).toLocaleString('en-US') + '</div></div>').join('');
}

/* ---------- Card control view ---------- */
function updateCardPreviewNetwork() {
  const b = document.getElementById('cc-brand-select').value;
  document.getElementById('cc-brand-badge').innerText = b;
}
function onGatewayChange() {
  const g = document.getElementById('cc-gateway-select').value;
  const box = document.getElementById('cc-payment-details');
  if (!g) { box.classList.add('hidden'); return; }
  box.classList.remove('hidden');
  const addr = appSettings.depositAddress || 'TX9aK8pL2mQ7vR4wN1zB6cJ3yH5fD8sG0e';
  document.getElementById('cc-wallet-addr').innerText = addr;
  setQr('cc-qr-box', addr);
}
async function submitCardControlOrder() {
  const paid = document.getElementById('cc-pay-amount').value;
  if (!paid || parseFloat(paid) <= 0) return alert('Enter the amount you sent (USD).');
  const r = await fetch('/api/buy-card', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, brand: document.getElementById('cc-brand-select').value, paidAmount: parseFloat(paid) }) });
  const d = await r.json();
  if (!r.ok) return showBanner(d.error || 'Card request error', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message || 'Card payment submitted!', false);
}

/* ---------- Deposit ---------- */
async function doDeposit() {
  const amount = document.getElementById('deposit-input-amount').value;
  if (!amount || parseFloat(amount) <= 0) return alert('Enter a valid deposit amount.');
  const r = await fetch('/api/deposit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, amount: parseFloat(amount) }) });
  const d = await r.json(); closeModal('deposit-modal');
  if (!r.ok) return showBanner(d.error || 'Deposit error', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message || 'Deposit notice submitted!', false);
}

/* ---------- Withdraw / Transfer ---------- */
function openWithdrawModal() {
  const m = document.getElementById('withdraw-method'); if (m) m.value = 'IBAN';
  toggleWithdrawFields();
  openModal('withdraw-modal');
}
function toggleWithdrawFields() {
  const method = document.getElementById('withdraw-method').value;
  const isIban = (method === 'IBAN');
  document.getElementById('iban-fields-wrap').classList.toggle('hidden', !isIban);
  document.getElementById('direct-target-wrap').classList.toggle('hidden', isIban);
}
async function doWithdraw() {
  const method = document.getElementById('withdraw-method').value, amount = document.getElementById('withdraw-amount').value;
  let target = '', bankDetails = null;
  if (method === 'IBAN') {
    const bankName = document.getElementById('withdraw-bank-name').value.trim(), holderName = document.getElementById('withdraw-holder-name').value.trim(), iban = document.getElementById('withdraw-iban').value.trim(), swift = document.getElementById('withdraw-swift').value.trim();
    if (!bankName || !holderName || !iban || iban.length < 10) return alert('Please enter valid Bank Name, Account Holder and IBAN.');
    target = 'IBAN: ' + iban + ' (' + bankName + ')'; bankDetails = { bankName, holderName, iban, swift };
  } else {
    target = document.getElementById('withdraw-address').value.trim();
    if (!target) return alert('Please enter recipient Account ID or Wallet address.');
  }
  if (!amount || amount <= 0) return alert('Enter valid amount.');
  const r = await fetch('/api/transfer', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ senderId: currentUser.id, method, target, bankDetails, amount: parseFloat(amount) }) });
  const d = await r.json(); closeModal('withdraw-modal');
  if (!r.ok) return showBanner(d.error, true);
  currentUser = d.user; updateDashboard(); showBanner(d.message || 'Transfer submitted!', false);
}

/* ---------- Bills ---------- */
async function submitBillPay() {
  const provider = document.getElementById('bill-provider').value, subNo = document.getElementById('bill-sub-no').value.trim(), amount = document.getElementById('bill-amount').value;
  if (!subNo) return alert('Enter your subscriber / account number.');
  if (!amount || parseFloat(amount) <= 0) return alert('Enter a valid bill amount.');
  const r = await fetch('/api/pay-bill', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, provider, subscriberNo: subNo, amount: parseFloat(amount) }) });
  const d = await r.json(); closeModal('bill-modal');
  if (!r.ok) return showBanner(d.error || 'Bill payment error', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message || 'Bill paid!', false);
}

/* ---------- Swap ---------- */
async function submitSwap() {
  const usd = document.getElementById('swap-usd-input').value, coin = document.getElementById('swap-coin-select').value;
  if (!usd || parseFloat(usd) <= 0) return alert('Enter a valid amount to convert.');
  const r = await fetch('/api/swap', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, toCoin: coin, usdAmount: parseFloat(usd) }) });
  const d = await r.json(); closeModal('swap-modal');
  if (!r.ok) return showBanner(d.error || 'Swap error', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message || 'Converted!', false);
}

/* ---------- Loan ---------- */
async function submitLoanRequest() {
  const amount = document.getElementById('loan-amount-input').value, months = document.getElementById('loan-months-select').value;
  if (!amount || parseFloat(amount) <= 0) return alert('Enter a valid loan amount.');
  const r = await fetch('/api/loan-request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, amount: parseFloat(amount), months }) });
  const d = await r.json(); closeModal('loan-modal');
  if (!r.ok) return showBanner(d.error || 'Loan request error', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message || 'Credit request submitted!', false);
}

/* ---------- KYC ---------- */
function openKycModal() {
  const banner = document.getElementById('kyc-status-banner');
  if (banner) {
    const st = currentUser ? currentUser.kycStatus : 'UNVERIFIED';
    banner.innerText = 'Status: ' + (st === 'VERIFIED' ? 'Verified' : 'Unverified');
  }
  const sel = document.getElementById('kyc-country');
  if (sel && sel.options.length === 0) sel.innerHTML = ALL_COUNTRIES.map(c => '<option value="' + c + '">' + c + '</option>').join('');
  openModal('kyc-modal');
}
function readFileBase64(file) { return new Promise(res => { if (!file) return res(''); const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(file); }); }
async function submitKycForm() {
  const country = document.getElementById('kyc-country').value, docType = document.getElementById('kyc-doc-type').value, docNumber = document.getElementById('kyc-doc-num').value.trim(), birthDate = document.getElementById('kyc-birth').value;
  const f1 = document.getElementById('kyc-file-front'), f2 = document.getElementById('kyc-file-back');
  const fileFront = f1 && f1.files ? f1.files.item(0) : null, fileBack = f2 && f2.files ? f2.files.item(0) : null;
  if (!docNumber || docNumber.length < 6) return alert('Enter valid Passport / ID number (min 6 chars).');
  if (!fileFront || !fileBack) return alert('Please upload both FRONT and BACK photos of your document.');
  const docImageFront = await readFileBase64(fileFront), docImageBack = await readFileBase64(fileBack);
  const r = await fetch('/api/kyc-submit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: currentUser.id, docType, docNumber, birthDate, country, docImageFront, docImageBack }) });
  const d = await r.json(); closeModal('kyc-modal');
  if (!r.ok) return showBanner(d.error || 'KYC error', true);
  currentUser = d.user; updateDashboard(); showBanner(d.message, false);
}

/* ---------- Init ---------- */
document.addEventListener('DOMContentLoaded', () => {
  const sel = document.getElementById('kyc-country');
  if (sel) sel.innerHTML = ALL_COUNTRIES.map(c => '<option value="' + c + '">' + c + '</option>').join('');
  fetch('/api/prices').then(r => r.json()).then(p => { prices = p || prices; if (currentUser) updateDashboard(); }).catch(() => { });
  fetch('/api/public-settings').then(r => r.json()).then(s => { appSettings = Object.assign({}, appSettings, s || {}); document.querySelectorAll('.price-tag').forEach(el => el.innerText = appSettings.cardPrice); }).catch(() => { });
});
