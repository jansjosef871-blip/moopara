const http = require('http');
http.get('http://localhost:3000/app.js?v=20261215', res => {
  let t = '';
  res.on('data', d => t += d);
  res.on('end', () => {
    console.log('content-type:', res.headers['content-type']);
    console.log('served len:', t.length);
    console.log('served has function enterApp:', t.includes('function enterApp'));
    console.log('served first 60:', JSON.stringify(t.slice(0, 60)));
  });
});
