export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/yonetim-atmaca-2026', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1200);
  out.page = await page.evaluate(() => ({ title: document.title, btns: Array.from(document.querySelectorAll('button')).map(b => b.innerText).slice(0, 5) }));
  // login form may differ; find inputs
  await page.evaluate(() => {
    const inputs = Array.from(document.querySelectorAll('input'));
    if (inputs[0]) inputs[0].value = 'atmaca';
    if (inputs[1]) inputs[1].value = 'admin2026!';
    const btn = Array.from(document.querySelectorAll('button')).find(b => /giriş|panel/i.test(b.innerText));
    if (btn) btn.click();
  });
  await page.waitForTimeout(2200);
  await page.evaluate(() => { const b = Array.from(document.querySelectorAll('button')).find(x => x.innerText.trim() === 'Ayarlar'); if (b) b.click(); });
  await page.waitForTimeout(600);
  out.adminTg = await page.evaluate(() => ({
    tokenField: !!document.getElementById('sTgToken'),
    chatField: !!document.getElementById('sTgChat'),
    testBtn: !!document.querySelector('button[onclick="testTelegram()"]'),
    holderField: !!document.getElementById('sHolder'),
    panelHead: (document.getElementById('icerik') || {}).innerText?.slice(0, 90)
  }));
  await page.screenshot({ path: 'admin-settings.png' });
  return out;
}
