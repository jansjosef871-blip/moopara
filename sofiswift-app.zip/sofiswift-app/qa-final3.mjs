export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 300)));
  page.on('console', m => { if (m.type() === 'error') errors.push('C: ' + m.text().slice(0, 200)); });
  await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(2500);
  const r = {};
  const em = 'fin' + Date.now() + '@mail.com';

  await page.click('#tab-register');
  await page.waitForTimeout(600);
  await page.evaluate(([e]) => {
    const f = document.getElementById('auth-form'); if (f) f.noValidate = true;
    document.getElementById('auth-name').value = 'Final Control';
    document.getElementById('auth-email').value = e;
    document.getElementById('auth-pass').value = '123456';
  }, [em]);
  const rp = page.waitForResponse(x => x.url().includes('/api/auth'), { timeout: 15000 }).catch(() => null);
  await page.evaluate(() => document.getElementById('auth-btn-text').click());
  r.regStatus = (await rp)?.status();
  // wait longer for enterApp
  await page.waitForTimeout(3000);
  r.dashboard = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));
  r.authHidden = await page.evaluate(() => document.getElementById('auth-section').classList.contains('hidden'));

  if (r.dashboard) {
    // Drawer test
    await page.evaluate(() => document.getElementById('menu-open-btn').click());
    await page.waitForTimeout(600);
    r.drawerOpen = await page.evaluate(() => {
      const d = document.getElementById('side-drawer');
      return !d.classList.contains('closed') && getComputedStyle(d).transform === 'matrix(1, 0, 0, 1, 0, 0)';
    });
    // Deposit via drawer
    await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-deposit"]').click());
    await page.waitForTimeout(600);
    r.depositOpen = await page.evaluate(() => !document.getElementById('deposit-modal').classList.contains('hidden'));
    await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]').click());
    await page.waitForTimeout(400);
    r.depositClosed = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));
    // Card + green balance
    r.balanceColor = await page.evaluate(() => getComputedStyle(document.getElementById('user-balance')).color);
    r.cvv = await page.evaluate(() => document.getElementById('card-cvv-text')?.innerText);
    r.chip = await page.evaluate(() => !!document.querySelector('.card-visual .card-chip'));
    // Green row simulation
    r.greenRow = await page.evaluate(() => {
      const el = document.createElement('div');
      el.className = 'list-item'; el.setAttribute('data-val', '1');
      el.innerHTML = '<div>x</div><div><div>22M USDT</div><div>$22,000,000.00</div></div>';
      document.getElementById('live-crypto-list').appendChild(el);
      return getComputedStyle(el.lastElementChild.querySelector('div:last-child')).color;
    });
    await page.screenshot({ path: 'final-dashboard.png' });
  }
  r.errors = errors;
  return r;
}
