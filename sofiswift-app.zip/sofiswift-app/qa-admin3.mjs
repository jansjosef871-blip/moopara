export default async function run(page, ui) {
  const out = {};
  await page.goto('http://localhost:3000/admin.html', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1500);
  out.adminLoaded = await page.evaluate(() => ({ hasLogin: !!document.getElementById('loginDiv'), title: document.title, url: location.href }));
  await page.fill('#u', 'atmaca');
  await page.fill('#p', 'admin2026!');
  await page.evaluate(() => giris());
  await page.waitForTimeout(2000);
  await page.evaluate(() => sekme('settings'));
  await page.waitForTimeout(400);
  out.adminTg = await page.evaluate(() => ({
    tokenField: !!document.getElementById('sTgToken'),
    chatField: !!document.getElementById('sTgChat'),
    testBtn: !!document.querySelector('button[onclick="testTelegram()"]'),
    holderField: !!document.getElementById('sHolder'),
    text: (document.getElementById('icerik') || {}).innerText?.slice(0, 100)
  }));
  await page.screenshot({ path: 'admin-settings.png' });
  return out;
}
