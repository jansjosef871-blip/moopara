export default async function run(page, ui) {
  const out = {};
  // force reload app.js (cache-bust)
  await page.goto('http://localhost:3000/?v=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(2500);
  out.setAuth = await page.evaluate(() => typeof window.setAuthMode);
  if (out.setAuth !== 'function') {
    // fallback: manually eval app.js
    await page.evaluate(async () => {
      const t = await (await fetch('/app.js?v=' + Math.random(), { cache: 'no-store' })).text();
      (0, eval)(t);
    });
    out.setAuthAfterEval = await page.evaluate(() => typeof window.setAuthMode);
  }
  // register a test user
  out.reg = await page.evaluate(async () => {
    const email = 'qa' + Date.now() + '@test.com';
    const r = await fetch('/api/send-otp', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, phone: '05551234567' }) });
    const d = await r.json();
    const r2 = await fetch('/api/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'QA User', email, password: '1234', phone: '05551234567', otpCode: d.demoCode || '000000', isRegister: true }) });
    const d2 = await r2.json();
    if (!r2.ok) return { err: d2.error };
    currentUser = d2.user; appSettings = d2.settings || appSettings;
    enterApp();
    return { ok: true, iban: appSettings.officialBankIban };
  });
  // open deposit modal, switch to personal tab
  out.deposit = await page.evaluate(() => {
    openModal('deposit-modal');
    document.querySelector('[data-act="dep-tab-personal"]').click();
    return {
      paneVisible: !document.getElementById('dep-pane-personal').classList.contains('hidden'),
      iban: document.getElementById('dep-personal-iban').innerText,
      holder: document.getElementById('dep-personal-holder').innerText,
      bank: document.getElementById('dep-personal-bank').innerText,
      hasQrImg: !!document.querySelector('#dep-personal-qr img'),
      qrSrc: (document.querySelector('#dep-personal-qr img') || {}).src || ''
    };
  });
  await page.waitForTimeout(1000);
  await page.screenshot({ path: 'personal-iban-qr.png' });
  return out;
}
