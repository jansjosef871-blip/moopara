export default async function run(page, ui) {
  const res = {};
  page.on('response', r => { if (r.url().includes('app.js')) res.status = r.status(); });
  res.out = await page.evaluate(() => new Promise(resolve => {
    const s = document.createElement('script');
    s.src = '/app.js?v=abc123';
    s.onload = () => resolve('onload fired, setAuth=' + typeof window.setAuthMode);
    s.onerror = (e) => resolve('onerror fired');
    document.body.appendChild(s);
    setTimeout(() => resolve('timeout: setAuth=' + typeof window.setAuthMode), 4000);
  }));
  return res;
}
