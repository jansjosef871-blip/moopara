const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');
// append pill update inside badge if-block
const old = `    badge.className = 'status-pill ' + (currentUser.hasCard ? 'pill-active' : 'pill-locked');
  }`;
const nw = `    badge.className = 'status-pill ' + (currentUser.hasCard ? 'pill-active' : 'pill-locked');
  }
  var ccPill = document.getElementById('cc-status-pill');
  if (ccPill) { ccPill.innerText = currentUser.hasCard ? currentUser.cardBrand + ' Aktif' : 'Kart Yok'; ccPill.className = 'status-pill ' + (currentUser.hasCard ? 'pill-active' : 'pill-locked'); }`;
if (t.includes(old)) { t = t.replace(old, nw); fs.writeFileSync(p, t); console.log('cc pill PATCHED'); }
else console.log('not found');
