const fs = require('fs');
const t = fs.readFileSync('C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js', 'utf8');
console.log('len:', t.length);
console.log('switchDepositTab crypto only:', t.includes("function switchDepositTab(tab) {\n  const isCrypto = (tab === 'crypto');"));
console.log('has dep-tab-personal:', t.includes('dep-tab-personal'));
