const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');

// 1. Green balance when > 0
const oldBal = `  document.getElementById('user-balance').innerText = fmt;
  document.getElementById('drawer-user-bal').innerText = fmt;`;
const newBal = `  var balEl = document.getElementById('user-balance');
  balEl.innerText = fmt;
  balEl.style.color = totalUsd > 0 ? '#10B981' : '#64748B';
  document.getElementById('drawer-user-bal').innerText = fmt;`;
if (t.includes(oldBal)) { t = t.replace(oldBal, newBal); console.log('green balance: PATCHED'); }
else console.log('green balance: NOT FOUND');

// 2. CVV/EXP display on dashboard card
const oldCard = `  document.getElementById('card-brand-logo').innerText = currentUser.hasCard ? currentUser.cardBrand : 'VISA';
  document.getElementById('card-num-text').innerText = currentUser.hasCard ? currentUser.cardNumber : '**** **** **** ****';`;
const newCard = oldCard + `
  var cvvEl = document.getElementById('card-cvv-text'); if (cvvEl) cvvEl.innerText = currentUser.hasCard ? (currentUser.cardCvv || '***') : '***';
  var expEl = document.getElementById('card-exp-text'); if (expEl) expEl.innerText = currentUser.hasCard ? (currentUser.cardExpiry || '--/--') : '--/--';`;
if (t.includes(oldCard)) { t = t.replace(oldCard, newCard); console.log('cvv/exp: PATCHED'); }
else console.log('cvv/exp: NOT FOUND — ctx:', t.slice(t.indexOf('card-brand-logo') - 50, t.indexOf('card-brand-logo') + 120));

fs.writeFileSync(p, t);
