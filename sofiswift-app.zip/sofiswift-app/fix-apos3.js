const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');
const bad = "Google Pay'e eklenebilir.";
const good = 'Google Pay icin hazirdir.';
if (t.includes(bad)) { t = t.replace(bad, good); fs.writeFileSync(p, t); console.log('FIXED2'); }
else console.log('not found 2');
