const d = require('fs').readFileSync('public/app.js', 'utf8');
const i = d.indexOf("'copy-personal-iban'");
console.log(JSON.stringify(d.slice(i - 350, i + 400)));
