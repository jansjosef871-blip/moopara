export default async function run(page, ui) {
  const out = { console: [], errors: [] };
  page.on('console', m => { if (m.type() === 'error') out.console.push(m.text()); });
  page.on('pageerror', e => out.errors.push(String(e)));

  // 1) Register/login a user via API-backed UI
  const email = 'qa' + Date.now() + '@test.com';
  await ui.snapshot();

  // switch to register tab
  const regBtn = (await ui.snapshot()).match(/@(e\d+) button "Ücretsiz Hesap Aç|Kayıt/i);
  // fallback: use JS
  await page.evaluate(() => { if (typeof setAuthMode === 'function') setAuthMode(true); });
  await page.fill('#auth-name', 'QA User');
  await page.fill('#auth-email', email);
  await page.fill('#auth-phone', '05551234567');
  await page.fill('#auth-pass', '1234');
  // request OTP then read demo code from the error box
  await page.evaluate(() => sendOtpCode());
  await page.waitForTimeout(1200);
  const otpText = await page.evaluate(() => document.getElementById('auth-error')?.innerText || '');
  const otp = (otpText.match(/\b(\d{6})\b/) || [])[1];
  out.otpShown = otp || otpText;
  if (otp) await page.fill('#auth-otp', otp);
  await page.click('#auth-btn-text');
  await page.waitForTimeout(1500);
  out.loggedIn = await page.evaluate(() => !!currentUser);

  if (!out.loggedIn) return out;

  // 2) Deposit modal: open, check tabs, ✕ close
  await page.evaluate(() => openModal('deposit-modal'));
  await page.waitForTimeout(600);
  out.cryptoVisible = await page.evaluate(() => !document.getElementById('dep-pane-crypto').classList.contains('hidden'));
  await page.evaluate(() => document.querySelector('[data-act="dep-tab-personal"]').click());
  await page.waitForTimeout(400);
  out.personalPaneVisible = await page.evaluate(() => !document.getElementById('dep-pane-personal').classList.contains('hidden'));
  out.personalIbanText = await page.evaluate(() => document.getElementById('dep-personal-iban').innerText);
  out.holderText = await page.evaluate(() => document.getElementById('dep-personal-holder').innerText);
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]').click());
  await page.waitForTimeout(400);
  out.modalClosedByX = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));

  // 3) Corporate view
  await page.evaluate(() => { showMainView('corporate'); });
  await page.waitForTimeout(800);
  out.corpAuthBox = await page.evaluate(() => !!document.getElementById('corp-auth-box'));
  out.corpVisible = await page.evaluate(() => !document.getElementById('corporate-view').classList.contains('hidden'));

  // screenshot dashboard
  await page.evaluate(() => showMainView('dashboard'));
  await page.waitForTimeout(500);
  await page.screenshot({ path: 'live-final.png', fullPage: false });
  return out;
}
