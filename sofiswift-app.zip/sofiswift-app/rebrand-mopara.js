const fs = require('fs');
const path = require('path');
const root = __dirname;

const files = [
  'public/index.html', 'public/admin.html', 'public/app.js', 'public/admin.js', 'public/actions.js', 'public/logo.svg',
  'public/robots.txt', 'public/sitemap.xml', 'server.js', 'database.json', 'database.backup.json', 'ecosystem.config.js', 'package.json'
];

let total = 0;
for (const f of files) {
  const p = path.join(root, f);
  if (!fs.existsSync(p)) { console.log('SKIP (yok):', f); continue; }
  let t = fs.readFileSync(p, 'utf8');
  const before = t;
  t = t.replace(/SofiSwift/g, 'Mopara')
    .replace(/sofiswift/g, 'mopara')
    .replace(/SOFISWIFT/g, 'MOPARA')
    .replace(/SOFIUS33XXX/g, 'MOPAUS33XXX')
    .replace(/US64 SOFI/g, 'US64 MOPA')
    .replace(/US89 SOFI/g, 'US89 MOPA')
    .replace(/ss_live_/g, 'mp_live_')
    .replace(/sofiswift-bank/g, 'mopara-bank');
  if (t !== before) {
    fs.writeFileSync(p, t, 'utf8');
    const n = (before.match(/sofiswift/gi) || []).length;
    total += n;
    console.log('OK:', f, '(' + n + ' değişiklik)');
  } else {
    console.log('değişiklik yok:', f);
  }
}
console.log('TOPLAM:', total);
