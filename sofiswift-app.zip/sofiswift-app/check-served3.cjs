require('http').get('http://127.0.0.1:3000/app.js?v=' + Date.now(), r => {
  let d = '';
  r.on('data', c => d += c);
  r.on('end', () => {
    const i = d.indexOf("'dep-tab-personal'");
    console.log('len', d.length, 'idx', i);
    console.log(JSON.stringify(d.slice(i - 100, i + 400)));
    console.log('has fillPersonalDeposit:', d.includes('fillPersonalDeposit'));
  });
});
