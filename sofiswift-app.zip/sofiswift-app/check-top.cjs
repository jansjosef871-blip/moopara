const d = require('fs').readFileSync('public/app.js', 'utf8');
console.log('currentUser decl:', d.slice(0, 200).includes('let currentUser'));
console.log('top of file:', JSON.stringify(d.slice(0, 150)));
