export default async function run(page, ui) {
  return await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=final', { cache: 'no-store' })).text();
    const s = document.createElement('script');
    s.textContent = t;
    return new Promise(resolve => {
      s.addEventListener('error', e => resolve('ERR event'));
      document.body.appendChild(s);
      setTimeout(() => resolve({ setAuth: typeof window.setAuthMode, probe: window.__it, it2: window.__z }), 1500);
    });
  });
}
