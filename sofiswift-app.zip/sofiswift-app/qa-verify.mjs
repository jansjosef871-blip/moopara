export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 300)));
  await page.goto('http://localhost:3000/', { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(2000);
  const r = {};
  const em = 'ok' + Date.now() + '@mail.com';

  // REGISTER with unique email
  await page.click('#tab-register');
  await page.waitForTimeout(600);
  await page.evaluate(([e]) => {
    const f = document.getElementById('auth-form'); if (f) f.noValidate = true;
    document.getElementById('auth-name').value = 'OK Test';
    document.getElementById('auth-email').value = e;
    document.getElementById('auth-pass').value = '123456';
  }, [em]);
  const rp = page.waitForResponse(x => x.url().includes('/api/auth'), { timeout: 15000 }).catch(() => null);
  await page.evaluate(() => document.getElementById('auth-btn-text').click());
  const resp = await rp;
  r.registerStatus = resp ? resp.status() : 'none';
  await page.waitForTimeout(1800);
  r.dashboard = await page.evaluate(() => !document.getElementById('user-dashboard').classList.contains('hidden'));
  r.errText = await page.evaluate(() => document.getElementById('auth-error')?.innerText || '');

  // DRAWER open
  await page.evaluate(() => document.getElementById('menu-open-btn').click());
  await page.waitForTimeout(500);
  r.drawerOpen = await page.evaluate(() => {
    const d = document.getElementById('side-drawer');
    return !d.classList.contains('closed') && getComputedStyle(d).transform === 'matrix(1, 0, 0, 1, 0, 0)';
  });

  // Deposit via drawer
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-deposit"]').click());
  await page.waitForTimeout(500);
  r.depositOpen = await page.evaluate(() => !document.getElementById('deposit-modal').classList.contains('hidden'));
  await page.evaluate(() => document.querySelector('[data-act="close-deposit-modal"]').click());
  await page.waitForTimeout(300);
  r.depositClosed = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));

  // Balance + card visuals
  r.balanceColor = await page.evaluate(() => getComputedStyle(document.getElementById('user-balance')).color);
  r.cvv = await page.evaluate(() => document.getElementById('card-cvv-text')?.innerText);
  r.chip = await page.evaluate(() => !!document.querySelector('.card-visual .card-chip'));

  // Screenshot
  await page.screenshot({ path: 'final-check.png' });
  r.errors = errors;
  return r;
}
