export default async function run(page, ui) {
  return await page.evaluate(async () => {
    const t = await (await fetch('/app.js?v=probe2', { cache: 'no-store' })).text();
    // Prepend marker assignments interleaved: after every 50 lines insert window.__nX = true
    const lines = t.split('\n');
    const out = [];
    for (let i = 0; i < lines.length; i++) {
      out.push(lines[i]);
      if (i % 50 === 0) out.push('window.__prog[' + i + ']=1;');
    }
    window.__prog = {};
    const blob = new Blob([out.join('\n')], { type: 'text/javascript' });
    const s = document.createElement('script');
    s.src = URL.createObjectURL(blob);
    document.body.appendChild(s);
    await new Promise(r => setTimeout(r, 2500));
    const keys = Object.keys(window.__prog).map(Number).sort((a, b) => a - b);
    return { maxReached: keys[keys.length - 1], all: keys, setAuth: typeof window.setAuthMode, progExists: !!window.__prog };
  });
}
