export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push('PE: ' + String(e).slice(0, 250)));
  await page.goto('http://localhost:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForTimeout(3000);
  const r = {};
  r.deep = await page.evaluate(() => {
    const a = document.getElementById('auth-section');
    const d = document.getElementById('user-dashboard');
    const t = document.getElementById('tab-register');
    return JSON.stringify({
      authExists: !!a, authHidden: a ? a.classList.contains('hidden') : null,
      authDisplay: a ? getComputedStyle(a).display : null,
      dashExists: !!d, tabRegExists: !!t,
      navbarExists: !!document.querySelector('.navbar'),
      bodyFirst100: document.body.innerHTML.slice(0, 100),
      elemCount: document.querySelectorAll('*').length
    });
  });
  r.errors = errors;
  return r;
}
