const fs = require('fs');
let d = fs.readFileSync('public/admin.html', 'utf8');

// 1) HTML: telegram panel after wa-toggle, before SMTP
const old1 = `<button type="button" id="wa-toggle-btn" class="btn-sm btn-green" style="margin-top:8px;" onclick="toggleWaStatus()">🟢 AÇIK</button>
            <h3 style="margin-top:16px;">✉️ SMTP / SMS</h3>`;
const new1 = `<button type="button" id="wa-toggle-btn" class="btn-sm btn-green" style="margin-top:8px;" onclick="toggleWaStatus()">🟢 AÇIK</button>
            <h3 style="margin-top:16px;">📨 Telegram Bildirimleri</h3>
            <label class="fl">Bot Token (BotFather'dan)</label><input type="text" id="set-tg-token" class="input" style="margin-top:0;" placeholder="123456:ABC-DEF..." />
            <label class="fl">Chat ID</label><input type="text" id="set-tg-chat" class="input" style="margin-top:0;" placeholder="örn: 123456789" />
            <button type="button" class="btn-sm btn-blue" style="margin-top:8px;" onclick="testTelegram()">📨 Test Mesajı Gönder</button> <span id="tg-test-result" style="font-size:12px;font-weight:800;"></span>
            <h3 style="margin-top:16px;">✉️ SMTP / SMS</h3>`;
if (!d.includes(old1)) { console.log('T1 FAIL'); process.exit(1); }
d = d.replace(old1, new1);

// 2) JS: fill fields on settings load. Find where set-wa-num gets filled
const waFillIdx = d.indexOf('set-wa-num');
if (waFillIdx === -1) { console.log('WA FILL LOCATE FAIL'); process.exit(1); }
// show context to patch: add after the line that sets set-wa-text
const anchor2 = /(\n\s*document\.getElementById\('set-wa-text'\)\.value[^\n]*\n)/;
if (!anchor2.test(d)) { console.log('T2 FAIL'); process.exit(1); }
d = d.replace(anchor2, "$1            document.getElementById('set-tg-token').value = s.telegramBotToken || '';\n            document.getElementById('set-tg-chat').value = s.telegramChatId || '';\n");

// 3) saveSystemSettings: include tg fields. Find it
const idx3 = d.indexOf('async function saveSystemSettings');
if (idx3 === -1) { console.log('T3 LOCATE FAIL'); process.exit(1); }
const bodyStart = d.indexOf('{', idx3);
const bodyEnd = d.indexOf('\n  }', bodyStart);
const body = d.slice(bodyStart, bodyEnd);
if (!body.includes('set-wa-num')) { console.log('T3 WA NOT IN SAVE', body.slice(0, 400)); process.exit(1); }
// inject tg into the payload object: find "set-wa-text" occurrence within body and append after its line
const lines = body.split('\n');
const out = [];
let injected = false;
for (const ln of lines) {
  out.push(ln);
  if (!injected && ln.includes("set-wa-text")) {
    out.push("      telegramBotToken: (document.getElementById('set-tg-token')||{}).value || '',");
    out.push("      telegramChatId: (document.getElementById('set-tg-chat')||{}).value || '',");
    injected = true;
  }
}
if (!injected) { console.log('T3 INJECT FAIL'); process.exit(1); }
d = d.slice(0, bodyStart) + out.join('\n') + d.slice(bodyEnd);

// 4) testTelegram function — append near other admin helpers
const anchor4 = d.indexOf('async function toggleWaStatus');
if (anchor4 === -1) { console.log('T4 LOCATE FAIL'); process.exit(1); }
const tgFn = `async function testTelegram() {
    const token = document.getElementById('set-tg-token').value.trim();
    const chat = document.getElementById('set-tg-chat').value.trim();
    const el = document.getElementById('tg-test-result');
    el.innerHTML = '<span style="color:#FBBF24;">⏳ Gönderiliyor...</span>';
    await fetch('/api/admin-panel-action', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type: 'settings', settings: { telegramBotToken: token, telegramChatId: chat } }) });
    try {
      const r = await fetch('/api/admin-telegram-test', { method: 'POST' });
      const d = await r.json();
      el.innerHTML = d.ok ? '<span style="color:#34D399;">✅ Gönderildi! Telegramına bak.</span>' : '<span style="color:#F87171;">❌ ' + (d.error || 'Hata') + '</span>';
    } catch (e) { el.innerHTML = '<span style="color:#F87171;">❌ Bağlantı hatası</span>'; }
  }
  `;
d = d.slice(0, anchor4) + tgFn + d.slice(anchor4);

fs.writeFileSync('public/admin.html', d);
console.log('Telegram patch OK');
