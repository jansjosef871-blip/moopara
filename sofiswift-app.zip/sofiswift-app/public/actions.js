/* Mopara — Global Action Router
   Tüm butonlar document seviyesinde delegasyonla yakalanır.
   Bu dosya bağımsızdır: app.js içindeki global fonksiyonları çağırır. */
(function () {
  'use strict';
  function findFn(name) {
    try { return typeof window[name] === 'function' ? window[name] : (typeof eval(name) === 'function' ? eval(name) : null); }
    catch (e) { return null; }
  }
  function call(name, args) {
    let fn = null;
    try { fn = typeof window[name] === 'function' ? window[name] : (typeof eval(name) === 'function' ? eval(name) : null); } catch (e) { fn = null; }
    if (fn) { try { return fn.apply(null, args || []); } catch (e) { console.error('[' + name + ']', e); } }
    else console.warn('Missing fn:', name);
  }
  function run(act) {
    switch (act) {
      case 'register': call('setAuthMode', [true]); break;
      case 'login': call('setAuthMode', [false]); break;
      case 'toggle-pass': call('togglePassVisibility'); break;
      case 'drawer-open': call('toggleDrawer', [true]); break;
      case 'drawer-close': call('toggleDrawer', [false]); break;
      case 'dark-toggle': document.body.classList.toggle('dark-mode'); break;
      case 'copy-addr': call('copyAddress'); break;
      case 'menu-dashboard': case 'show-dashboard': call('toggleDrawer', [false]); call('showMainView', ['dashboard']); break;
      case 'menu-card': case 'show-card': call('toggleDrawer', [false]); call('showMainView', ['card']); break;
      case 'menu-deposit': case 'open-deposit': call('toggleDrawer', [false]); call('openModal', ['deposit-modal']); break;
      case 'open-send-money': call('toggleDrawer', [false]); call('openModal', ['send-money-modal']); break;
      case 'submit-send-money': call('doSendMoney'); break;
      case 'menu-withdraw': case 'open-withdraw': call('toggleDrawer', [false]); call('openWithdrawModal'); break;
      case 'menu-bills': case 'open-bill': call('toggleDrawer', [false]); call('openModal', ['bill-modal']); break;
      case 'menu-swap': case 'open-swap': call('toggleDrawer', [false]); call('openModal', ['swap-modal']); break;
      case 'menu-loan': case 'open-loan': call('toggleDrawer', [false]); call('openModal', ['loan-modal']); break;
      case 'menu-kyc': case 'open-kyc': call('toggleDrawer', [false]); call('openKycModal'); break;
      case 'menu-api': case 'open-api': call('toggleDrawer', [false]); call('showMainView', ['api']); break;
      case 'open-corporate-panel': call('toggleDrawer', [false]); call('showMainView', ['corporate']); break;
      case 'dep-tab-crypto': call('switchDepositTab', ['crypto']); break;
      case 'dep-tab-bank': call('switchDepositTab', ['bank']); break;
      case 'dep-tab-personal': call('switchDepositTab', ['personal']); break;
      case 'cc-type-virtual': try {
        var v = document.getElementById('cc-type-virtual'), ph = document.getElementById('cc-type-physical');
        if (v && ph) { v.classList.add('sel'); v.style.borderColor = '#00A2C7'; v.style.background = '#E0F7FA'; ph.classList.remove('sel'); ph.style.borderColor = '#E2E8F0'; ph.style.background = '#FFFFFF'; }
        if (typeof ccSelectType === 'function') ccSelectType('VIRTUAL');
      } catch (e) {} break;
      case 'cc-type-physical': try {
        var v = document.getElementById('cc-type-virtual'), ph = document.getElementById('cc-type-physical');
        if (v && ph) { ph.classList.add('sel'); ph.style.borderColor = '#00A2C7'; ph.style.background = '#E0F7FA'; v.classList.remove('sel'); v.style.borderColor = '#E2E8F0'; v.style.background = '#FFFFFF'; }
        if (typeof ccSelectType === 'function') ccSelectType('PHYSICAL');
      } catch (e) {} break;
      case 'copy-personal-iban': try { navigator.clipboard.writeText(document.getElementById('dep-personal-iban').innerText); alert('Kişisel IBAN kopyalandı!'); } catch(e) {} break;
      case 'menu-logout': case 'logout': call('logout'); break;
      case 'submit-auth': call('doAuth'); break;
      case 'submit-deposit': call('doDeposit'); break;
      case 'submit-withdraw': call('doWithdraw'); break;
      case 'submit-bill': call('submitBillPay'); break;
      case 'submit-swap': call('submitSwap'); break;
      case 'submit-loan': call('submitLoanRequest'); break;
      case 'submit-kyc': call('submitKycForm'); break;
      case 'submit-card-order': call('submitCardControlOrder'); break;
      default:
        if (act.indexOf('close-') === 0) call('closeModal', [act.slice(6) + '-modal']);
    }
  }
  document.addEventListener('click', function (e) {
    let el = e.target;
    while (el && el !== document) {
      if (el.getAttribute && el.getAttribute('data-act')) {
        e.preventDefault();
        run(el.getAttribute('data-act'));
        return;
      }
      el = el.parentNode;
    }
  }, true);
  document.addEventListener('submit', function (e) {
    if (e.target && e.target.id === 'auth-form') { e.preventDefault(); call('doAuth'); }
  }, true);
  // Overlay arkasına tıklayınca modal kapat
  document.addEventListener('click', function (e) {
    if (e.target && e.target.classList && e.target.classList.contains('modal-overlay')) {
      e.target.classList.add('hidden');
    }
  }, true);
  // ESC ile modal/drawer kapat
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay:not(.hidden)').forEach(function (m) { m.classList.add('hidden'); });
      call('toggleDrawer', [false]);
    }
  });
})();
