const fs = require('fs');
const path = 'public/index.html';
let text = fs.readFileSync(path, 'utf8');
const lines = text.split(/\r?\n/);

// 0-based: satır 225 => index 224. Eski blok 14 satır (225-238).
const newBlock = [
    '      <button type="button" id="tab-login" class="auth-tab active" data-act="login">Giriş Yap</button>',
    '      <button type="button" id="tab-register" class="auth-tab" data-act="register">Kayıt Ol</button>',
    '      </div>',
    '      <h2 id="auth-title" class="auth-title">Hesabına Giriş Yap</h2>',
    '      <p class="auth-desc">moopara Global Dijital Bankacılık Ağı\'na hoş geldin.</p>',
    '      <div id="auth-error" class="err-box hidden"></div>',
    '      <form id="auth-form">',
    '      <div id="name-field" class="hidden"><label class="form-label">Ad Soyad</label><input type="text" id="auth-name" placeholder="Örn. Ahmet Yılmaz" class="input" autocomplete="name" /></div>',
    '      <label class="form-label">E-Posta Adresi</label><input type="email" id="auth-email" placeholder="ornek@mail.com" class="input" autocomplete="email" required />',
    '      <label class="form-label">Şifre</label>',
    '      <div class="pass-wrap"><input type="password" id="auth-pass" placeholder="••••••••" class="input" autocomplete="current-password" required minlength="4" /><button type="button" id="toggle-pass" class="toggle-pass-btn" data-act="toggle-pass">👁</button></div>',
    '      <button type="submit" id="auth-btn-text" class="btn-main">Güvenli Giriş</button>',
    '      </form>',
    '      <div class="auth-secure-note">🔒 Bağlantınız SSL ile şifrelenir — bilgileriniz güvende.</div>'
];

// Doğrulama: index 224 tab-login içermeli
if (!lines[224].includes('tab-login')) { console.error('ANCHOR FAIL at 224: ' + lines[224].slice(0, 80)); process.exit(1); }
lines.splice(224, 14, ...newBlock);
fs.writeFileSync(path, lines.join('\n'), 'utf8');
console.log('auth block rewritten clean');
