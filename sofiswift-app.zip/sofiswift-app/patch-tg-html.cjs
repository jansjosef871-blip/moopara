const fs = require('fs');
let d = fs.readFileSync('public/admin.html', 'utf8');
const old = `<button type="button" id="wa-toggle-btn" class="btn-sm btn-green" style="margin-top:8px;" onclick="toggleWaStatus()">🟢 AÇIK</button>
            <h3 style="margin-top:16px;">✉️ SMTP / SMS</h3>`;
const nw = `<button type="button" id="wa-toggle-btn" class="btn-sm btn-green" style="margin-top:8px;" onclick="toggleWaStatus()">🟢 AÇIK</button>
            <h3 style="margin-top:16px;">📨 Telegram Bildirimleri</h3>
            <label class="fl">Bot Token (BotFather'dan)</label><input type="text" id="set-tg-token" class="input" style="margin-top:0;" placeholder="123456:ABC-DEF..." />
            <label class="fl">Chat ID</label><input type="text" id="set-tg-chat" class="input" style="margin-top:0;" placeholder="örn: 123456789" />
            <button type="button" class="btn-sm btn-blue" style="margin-top:8px;" onclick="testTelegram()">📨 Test Mesajı Gönder</button> <span id="tg-test-result" style="font-size:12px;font-weight:800;"></span>
            <h3 style="margin-top:16px;">✉️ SMTP / SMS</h3>`;
if (!d.includes(old)) { console.log('FAIL'); process.exit(1); }
d = d.replace(old, nw);
fs.writeFileSync('public/admin.html', d);
console.log('HTML telegram panel OK');
