const http = require('http');
http.get('http://localhost:3000/?noc=' + Date.now(), res => {
  let t = '';
  res.on('data', d => t += d);
  res.on('end', () => {
    console.log('served deposit-modal:', t.includes('id="deposit-modal"'));
    console.log('served withdraw-modal:', t.includes('id="withdraw-modal"'));
    console.log('served tab-register:', t.includes('tab-register'));
    console.log('served dep-tab-personal:', t.includes('dep-tab-personal'));
  });
});
