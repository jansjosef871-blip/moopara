export default async function run(page, ui) {
  const r = {};
  // open deposit via drawer
  await page.evaluate(() => { document.getElementById('menu-open-btn').click(); });
  await page.waitForTimeout(500);
  await page.evaluate(() => { document.querySelector('#side-drawer [data-act="menu-deposit"]').click(); });
  await page.waitForTimeout(600);
  r.depositOpen = await page.evaluate(() => !document.getElementById('deposit-modal').classList.contains('hidden'));
  // fit check
  r.modalFits = await page.evaluate(() => {
    const b = document.querySelector('#deposit-modal .modal-box');
    return b.getBoundingClientRect().height <= window.innerHeight;
  });
  r.scrollable = await page.evaluate(() => {
    const b = document.querySelector('#deposit-modal .modal-box');
    return b.scrollHeight > b.clientHeight;
  });
  // personal tab
  await page.evaluate(() => { document.querySelector('[data-act="dep-tab-personal"]').click(); });
  await page.waitForTimeout(400);
  r.personalTab = await page.evaluate(() => !document.getElementById('dep-pane-personal').classList.contains('hidden'));
  r.personalIban = await page.evaluate(() => document.getElementById('dep-personal-iban').innerText.slice(0, 35));
  r.personalTrc = await page.evaluate(() => document.getElementById('dep-personal-trc').innerText.slice(0, 12));
  await page.screenshot({ path: 'deposit-personal.png' });
  // close via X
  await page.evaluate(() => { document.querySelector('[data-act="close-deposit-modal"]').click(); });
  await page.waitForTimeout(400);
  r.depositClosed = await page.evaluate(() => document.getElementById('deposit-modal').classList.contains('hidden'));
  // withdraw open + close
  await page.evaluate(() => { document.querySelector('#side-drawer [data-act="menu-withdraw"]').click(); });
  await page.waitForTimeout(500);
  r.withdrawOpen = await page.evaluate(() => !document.getElementById('withdraw-modal').classList.contains('hidden'));
  await page.evaluate(() => { document.querySelector('[data-act="close-withdraw-modal"]').click(); });
  await page.waitForTimeout(400);
  r.withdrawClosed = await page.evaluate(() => document.getElementById('withdraw-modal').classList.contains('hidden'));
  // ESC test
  await page.evaluate(() => { document.querySelector('#side-drawer [data-act="menu-bills"]').click(); });
  await page.waitForTimeout(400);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  r.billEscClosed = await page.evaluate(() => document.getElementById('bill-modal').classList.contains('hidden'));
  // overlay click test
  await page.evaluate(() => { document.querySelector('#side-drawer [data-act="menu-swap"]').click(); });
  await page.waitForTimeout(400);
  await page.evaluate(() => { document.getElementById('swap-modal').click(); });
  await page.waitForTimeout(300);
  r.swapOverlayClosed = await page.evaluate(() => document.getElementById('swap-modal').classList.contains('hidden'));
  // card free flow
  await page.evaluate(() => { document.querySelector('#side-drawer [data-act="menu-card"]').click(); });
  await page.waitForTimeout(500);
  r.cardView = await page.evaluate(() => !document.getElementById('card-control-view').classList.contains('hidden'));
  r.freeBannerShown = await page.evaluate(() => {
    const b = document.getElementById('cc-free-banner');
    return b && b.style.display === 'block';
  });
  // API title
  await page.evaluate(() => { document.querySelector('#side-drawer [data-act="menu-api"]').click(); });
  await page.waitForTimeout(500);
  r.apiTitle = await page.evaluate(() => document.querySelector('#api-integration-view h3').innerText);
  r.dashApiBtnGone = await page.evaluate(() => !document.querySelector('#user-dashboard [data-act="menu-api"]'));
  await page.evaluate(() => { document.querySelector('[data-act="drawer-close"]').click(); });
  await page.waitForTimeout(300);
  await page.screenshot({ path: 'v12-final.png' });
  return r;
}
