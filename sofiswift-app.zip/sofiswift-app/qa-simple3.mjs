export default async function run(page, ui) {
  const out = await page.evaluate(async () => {
    const r = {};
    r.simple = window.__simple;
    r.onclick = window.__oc;
    r.blobScript = window.__simple2;
    r.href = location.href;
    return r;
  });
  return out;
}
