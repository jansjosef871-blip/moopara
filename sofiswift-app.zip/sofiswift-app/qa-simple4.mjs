export default async function run(page, ui) {
  const r = {};
  r.step1 = await page.evaluate(() => { const b = document.createElement('button'); b.setAttribute('onclick', 'window.__oc=1'); document.body.appendChild(b); b.click(); return window.__oc; });
  r.step2 = await page.evaluate(() => new Promise(res => { const s = document.createElement('script'); s.textContent = 'window.__it=7'; document.body.appendChild(s); setTimeout(() => res(window.__it), 300); }));
  r.step3 = await page.evaluate(() => new Promise(res => { const s = document.createElement('script'); s.src = '/sw.js'; s.onload = () => res('sw loaded'); s.onerror = () => res('sw error'); document.body.appendChild(s); setTimeout(() => res('timeout'), 2000); }));
  return r;
}
