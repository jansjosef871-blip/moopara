export default async function run(page, ui) {
  const r = await page.evaluate(() => {
    const scripts = [...document.querySelectorAll('script[src]')];
    const info = scripts.map(s => ({ src: s.src, type: s.type, defer: s.defer, async: s.async }));
    // Check whether app.js actually executed: look for side effect markers
    const executed = typeof window.setAuthMode;
    // check a let variable at top-level — not on window
    const probes = { setAuthMode: typeof window.setAuthMode, doAuth: typeof window.doAuth };
    return JSON.stringify({ info, probes });
  });
  return r;
}
