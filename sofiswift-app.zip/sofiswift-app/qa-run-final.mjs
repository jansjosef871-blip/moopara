import { chromium } from 'playwright';

const scripts = ['./qa-finish3.mjs'];
const browser = await chromium.launch();
const page = await browser.newPage();
for (const s of scripts) {
  try {
    const mod = await import(s);
    const out = await mod.default(page, {});
    console.log('=== ' + s + ' ===');
    console.log(out);
  } catch (e) { console.log('=== ' + s + ' FAILED ===', e.message); }
}
await browser.close();
