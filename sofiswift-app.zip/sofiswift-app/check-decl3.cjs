const d = require('fs').readFileSync('public/app.js', 'utf8');
// there must be two scripts concatenated or two currentUser vars — search ALL declarations
const all = [...d.matchAll(/(?:let|var|const)\s+currentUser/g)].map(m => ({ ln: d.slice(0, m.index).split('\n').length, txt: d.slice(m.index, m.index + 60) }));
console.log(all);
console.log('total length:', d.length);
