const fs = require('fs');
const t = fs.readFileSync('C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js', 'utf8');
console.log('len:', t.length);
console.log('first 100:', JSON.stringify(t.slice(0, 100)));
console.log('starts with (function:', t.trimStart().startsWith('(function'));
console.log('has export:', t.includes('export '));
console.log('has "use strict" alone:', t.trimStart().startsWith("'use strict'"));
console.log('last 100:', JSON.stringify(t.slice(-100)));
// check function declarations
console.log('function enterApp:', t.includes('function enterApp'));
console.log('window.enterApp:', t.includes('window.enterApp'));
