const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');
const oldCard = `  const logo = document.getElementById('card-brand-logo'); if (logo) logo.innerText = currentUser.hasCard ? currentUser.cardBrand : 'VISA';
  const num = document.getElementById('card-num-text'); if (num) num.innerText = currentUser.hasCard ? currentUser.cardNumber : '**** **** **** ****';`;
const newCard = oldCard + `
  const cvvEl = document.getElementById('card-cvv-text'); if (cvvEl) cvvEl.innerText = currentUser.hasCard ? (currentUser.cardCvv || '***') : '***';
  const expEl = document.getElementById('card-exp-text'); if (expEl) expEl.innerText = currentUser.hasCard ? (currentUser.cardExpiry || '--/--') : '--/--';`;
if (t.includes(oldCard)) { t = t.replace(oldCard, newCard); console.log('cvv/exp: PATCHED'); }
else console.log('still not found');
fs.writeFileSync(p, t);
