export default async function run(page, ui) {
  return await page.evaluate(async () => {
    // Try the simplest possible external script to see if ANY script src executes
    const blob = new Blob(['window.__simple = "yes";'], { type: 'text/javascript' });
    const s = document.createElement('script');
    s.src = URL.createObjectURL(blob);
    document.body.appendChild(s);
    await new Promise(r => setTimeout(r, 1000));
    const simple = window.__simple;
    // Also from server: tiny test file? create one dynamically impossible — use existing /logo.svg? Use /manifest.json with type? skip.
    // Try serving app.js text via XHR + new Function with global eval semantics:
    const t = await (await fetch('/app.js?v=fn1', { cache: 'no-store' })).text();
    new Function(t)();   // this is non-global scope! but function DECLARATIONS still local...
    // Actually Function scope means setAuthMode won't be on window. So test with:
    return { simple, viaFunctionScope: typeof window.setAuthMode, viaIndirect: (0, eval)('typeof setAuthMode') };
  });
}
