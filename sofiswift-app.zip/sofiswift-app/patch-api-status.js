const fs = require('fs');
const p = 'C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js';
let t = fs.readFileSync(p, 'utf8');

// Replace user-side api key fns with status renderer
const oldFns = `function generateApiKey() {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let key = 'ss_live_';
  for (let i = 0; i < 32; i++) key += chars[Math.floor(Math.random() * chars.length)];
  appSettings.apiKey = key;
  renderApiKey();
  showBanner('Yeni API anahtarı oluşturuldu! Güvenli bir yerde saklayın.', false);
}
function renderApiKey() {
  const box = document.getElementById('api-key-box');
  if (box) box.innerText = appSettings.apiKey || 'API anahtarı oluşturulmadı — butona basarak oluşturun.';
}
function copyApiKey() {
  if (appSettings.apiKey) { navigator.clipboard.writeText(appSettings.apiKey); alert('API anahtarı kopyalandı!'); }
  else alert('Önce API anahtarı oluşturun.');
}`;
const newFns = `function renderApiStatus() {
  const box = document.getElementById('api-status-box');
  if (!box) return;
  if (appSettings.corporateApiKey) {
    box.style.background = '#ECFDF5'; box.style.color = '#065F46';
    box.innerText = '✅ Kurumsal API erişimi aktif — entegrasyon dokümanı aşağıdadır.';
  } else {
    box.style.background = '#FEF3C7'; box.style.color = '#B45309';
    box.innerText = '⏳ API erişimi için kurumsal başvuru bekleniyor — destek ile iletişime geçin.';
  }
}`;
if (t.includes(oldFns)) { t = t.replace(oldFns, newFns); console.log('api fns replaced'); }
else console.log('api fns NOT FOUND — checking renderApiKey only');

// showMainView api case: renderApiKey -> renderApiStatus
t = t.replace(/if \(v === 'api'\) renderApiKey\(\);/, "if (v === 'api') renderApiStatus();");

fs.writeFileSync(p, t);
