export default async function run(page, ui) {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e).slice(0, 200)));
  await page.goto('http://localhost:3000/', { waitUntil: 'load' });
  await page.waitForTimeout(1000);
  // register a fresh user
  await page.click('#tab-register');
  await page.waitForTimeout(300);
  const em = 'green' + Date.now() + '@mail.com';
  await page.fill('#auth-name', 'Green Test');
  await page.fill('#auth-email', em);
  await page.fill('#auth-pass', '123456');
  await page.click('#auth-btn-text');
  await page.waitForTimeout(1500);
  const report = {};
  report.dashboard = await page.locator('#user-dashboard').isVisible().catch(() => false);
  // Give user a fake balance via admin api? Instead directly check computed balance color (0 => grey)
  report.balanceColor0 = await page.evaluate(() => getComputedStyle(document.getElementById('user-balance')).color);
  // Simulate a deposit notification to create a pending transaction
  await page.click('#menu-open-btn');
  await page.waitForTimeout(300);
  await page.evaluate(() => document.querySelector('#side-drawer [data-act="menu-deposit"]').click());
  await page.waitForTimeout(400);
  report.depositModalOpen = await page.evaluate(() => !document.getElementById('deposit-modal').classList.contains('hidden'));
  await page.fill('#deposit-input-amount', '22000000');
  await page.click('[data-act="submit-deposit"]');
  await page.waitForTimeout(1200);
  report.depositBanner = await page.evaluate(() => document.getElementById('alert-box')?.innerText || '');
  // coin rows: check any green
  report.rows = await page.evaluate(() => {
    return [...document.querySelectorAll('#live-crypto-list .list-item')].slice(0, 3).map(r => ({
      bg: getComputedStyle(r).backgroundColor,
      right: r.lastElementChild.innerText
    }));
  });
  return { report, errors };
}
