const fs = require('fs');
const t = fs.readFileSync('C:/Users/baran/OneDrive/Desktop/sofiswift-app/public/app.js', 'utf8');
// find the actual function declaration of enterApp
const re = /(?:function\s+enterApp|enterApp\s*[:=]\s*function|const\s+enterApp)/g;
let m;
while ((m = re.exec(t)) !== null) {
  console.log('found at', m.index, ':', t.slice(m.index, m.index + 80));
}
// also check module type or strict wrapper
console.log('---');
console.log('t.startsWith("(function", 0):', t.slice(0, 20));
console.log('last 200:', t.slice(-200));
