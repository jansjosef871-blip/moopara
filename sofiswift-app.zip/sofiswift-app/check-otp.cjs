const d = require('fs').readFileSync('public/app.js', 'utf8');
const lines = d.split('\n');
console.log(lines.slice(205, 216).map((l, i) => (i + 206) + ': ' + l).join('\n'));
